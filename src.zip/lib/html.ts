/* HTML 文字列ユーティリティ */

/** HTML エスケープ */
export function esc(value: string | number | undefined | null): string {
  if (value === undefined || value === null) return "";
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

/** 属性用エスケープ */
export const escAttr = esc;

/** 配列を結合(空要素を除去) */
export function join(parts: Array<string | false | undefined | null>): string {
  return parts.filter(Boolean).join("\n");
}

/** 条件付きレンダリング */
export function when(
  cond: unknown,
  render: () => string,
  fallback = ""
): string {
  return cond ? render() : fallback;
}

/** JSON-LD を安全に埋め込む */
export function jsonLd(data: object): string {
  const json = JSON.stringify(data).replaceAll("</", "<\\/");
  return `<script type="application/ld+json">${json}</script>`;
}

/** YYYY-MM-DD → YYYY年M月D日 */
export function formatDate(iso: string): string {
  const m = iso.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return iso;
  return `${m[1]}年${Number(m[2])}月${Number(m[3])}日`;
}

/** 金額表示(円) */
export function formatYen(amount: number | undefined): string {
  if (amount === undefined) return "未確認";
  return `${amount.toLocaleString("ja-JP")}円`;
}
