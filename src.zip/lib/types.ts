/* ============================================================
 * キャリコンことば図鑑 — 共通型定義
 * ============================================================ */

/** 出典データ */
export type SourceReference = {
  label: string;
  url: string;
  sourceType:
    | "official-school"
    | "mhlw"
    | "exam-organization"
    | "other-primary-source";
  checkedAt: string; // YYYY-MM-DD
};

/** 公式情報データ(学校ページの「公式情報」ラベル付き項目) */
export type OfficialFact = {
  label: string;
  value: string;
  sourceUrl: string;
  checkedAt: string; // YYYY-MM-DD
  note?: string;
};

/** 養成学校データ */
export type School = {
  id: string;
  slug: string;
  name: string;
  operatorName: string;
  officialUrl: string;
  approvalSourceUrl?: string;

  informationStatus: "verified" | "partially_verified" | "unverified";

  deliveryModes: Array<
    "online-live" | "online-on-demand" | "classroom" | "hybrid"
  >;

  courseDuration?: string;
  totalHours?: number;
  liveLessonHours?: number;
  selfStudyHours?: number;

  tuition?: number;
  admissionFee?: number;
  materialFee?: number;
  displayedTotalCost?: number;

  educationBenefitAvailable?: boolean;
  benefitNotes?: string;

  scheduleOptions?: string[];
  classSize?: string;
  makeupPolicy?: string;

  assignmentFormat?: string;
  completionRequirements?: string[];

  roleplayTraining?: string;
  examPreparationIncluded?: boolean;
  examPreparationNotes?: string;

  supportDuringCourse?: string[];
  postQualificationSupport?: string[];

  /** 「運営者の考察」ラベルで表示する(事実ではなく考察) */
  recommendedFor?: string[];
  cautions?: string[];

  officialFacts?: OfficialFact[];
  sources: SourceReference[];

  /** 一覧カード用の特徴(最大3つ) */
  highlights?: string[];
  /** 一覧の絞り込み用タグ */
  filterTags?: SchoolFilterTag[];
  /** 広告・PR表示(初期はすべて false) */
  isPr?: boolean;

  verifiedAt?: string;
  updatedAt: string; // YYYY-MM-DD
};

export type SchoolFilterTag =
  | "online"
  | "classroom"
  | "weekend"
  | "weekday"
  | "evening"
  | "short-term"
  | "benefit"
  | "makeup"
  | "after-support";

/** 受講体験の1セクション */
export type ReviewSection = {
  title: string;
  body: string; // 運営者本人のメモ。AIで創作しない。空欄・TODO可。
};

/** 受講体験データ(運営者本人の体験のみ) */
export type SchoolReview = {
  id: string;
  schoolSlug: string;

  authorName: string;
  relationship: "currently-enrolled" | "completed" | "passed-exam" | "other";

  attendancePeriod?: string;
  courseName?: string;
  reviewUpdatedAt: string;

  reasonForChoosing?: string;
  expectationsBeforeEnrollment?: string;
  firstImpression?: string;

  goodPoints?: ReviewSection[];
  concerns?: ReviewSection[];
  unexpectedPoints?: ReviewSection[];

  lessonStyle?: string;
  teacherImpression?: string;
  roleplayExperience?: string;
  assignmentExperience?: string;

  weeklyStudyLoad?: string;
  childcareCompatibility?: string;
  workCompatibility?: string;
  onlineLearningExperience?: string;

  examPreparationExperience?: string;
  communityExperience?: string;
  postQualificationSupportExperience?: string;

  recommendedFor?: string[];
  notRecommendedFor?: string[];

  adviceBeforeEnrollment?: string[];
  overallSummary?: string;

  disclosure: string;
  publicationStatus: "draft" | "review" | "published";
};

/** 1問1答 */
export type QuizItem = {
  question: string;
  answer: boolean; // ○×
  explanation: string;
};

/** 用語(ことば図鑑) */
export type Term = {
  slug: string;
  number: number; // TERM 001 など
  name: string;
  reading: string;
  category: string; // 例: キャリア理論 / カウンセリング
  /** 1. ひとことで説明 */
  oneLiner: string;
  /** 2-a. 小学生でもわかる説明 */
  kidsExplanation: string;
  /** 2-b. 身近なたとえ */
  analogy: string;
  /** 子育て・仕事で考えると */
  lifeExample?: string;
  /** 3. 試験で必要な正式な説明 */
  formalExplanation: string;
  /** 理論家との関係 */
  theoristSlugs?: string[];
  /** 似た言葉との違い */
  similarTerms?: { name: string; difference: string }[];
  quiz?: QuizItem;
  relatedTermSlugs?: string[];
  keywords: string[];
  updatedAt: string;
};

/** 理論家 */
export type Theorist = {
  slug: string;
  number: number;
  name: string;
  nameEn: string;
  field: string; // 例: キャリア発達理論
  oneLiner: string;
  kidsExplanation: string;
  analogy: string;
  keyConcepts: { name: string; description: string }[];
  examPoints: string[];
  confusableWith?: { theoristSlug: string; point: string }[];
  relatedTermSlugs?: string[];
  keywords: string[];
  /** 覚えるための豆知識・エピソード(記憶のフックになる小話) */
  episodes?: string[];
  /** 実際の写真・くわしい経歴が見られる外部ページ(著作権保護のため写真は転載せずリンクで案内) */
  profileLinks?: { label: string; url: string }[];
  updatedAt: string;
};

/** 記事メタ(ガイド・体験記など一覧表示用) */
export type ArticleMeta = {
  slug: string; // ルートパス(先頭スラッシュなし)。例: "school-guides/how-to-choose"
  title: string;
  description: string;
  category: string;
  categoryEn: string;
  publishedAt: string;
  updatedAt: string;
  infoCheckedAt?: string;
  isPr: boolean;
  beginnerFriendly?: boolean;
  readingMinutes?: number;
  /** 手動指定の「はじめに読みたい記事」フラグ */
  editorsPick?: boolean;
};

/** 検索インデックスの1件 */
export type SearchDoc = {
  type: "用語" | "理論家" | "学校" | "受講体験" | "ガイド" | "働き方" | "記事";
  title: string;
  reading?: string;
  description: string;
  url: string;
  keywords: string[];
};

/** パンくず */
export type Crumb = { name: string; url?: string };
