/* サイト共通設定 */

/** バージョン表記(リリースごとに更新。フッターとランチャーに表示) */
const VERSION = (() => {
  const d = new Date();
  const jst = new Date(d.getTime() + 9 * 60 * 60 * 1000);
  const p = (n: number) => String(n).padStart(2, "0");
  return `v${jst.getUTCFullYear()}.${p(jst.getUTCMonth() + 1)}${p(jst.getUTCDate())}.${p(jst.getUTCHours())}${p(jst.getUTCMinutes())}`;
})();

export const SITE = {
  name: "キャリコンことば図鑑",
  version: VERSION,
  nameEn: "CAREER CONSULTANT STUDY GUIDE",
  tagline:
    "小学生でもわかるほどやさしい国家資格キャリアコンサルタント試験対策",
  /** サイトの説明コピー(ヘッダー下・フッター・SEOに使用) */
  concept: "「ことば」から学べる、キャリアコンサルタント試験対策",
  /** 補助のあたたかいコピー */
  subConcept: "むずかしい専門用語を、いちばんやさしい入口から。",
  /** LPのメインコピー(世界観: 心=天気、転機によりそう)。配列の要素ごとに改行 */
  heroTitleLines: ["クライエントのこころは", "天気のよう"],
  /** サブコピー(配列の要素ごとに改行) */
  heroSubLines: [
    "晴れの日も、雨の日も。その空を静かに見つめ、転機によりそう——",
    "それがキャリアコンサルタント",
  ],
  /** キャラクターのキャッチコピー(配列の要素ごとに改行) */
  characterTaglineLines: [
    "もやもやモヤンとさんさんサニー先生からまなぶ",
    "小学生でもたのしいキャリアコンサルタント対策講座",
  ],
  /** ミニモヤンのひとこと */
  miniMoyanLine:
    "過去問の用語自体が難しい!と感じた人のための、キャリコンことば図鑑だよ。",
  description:
    "キャリアコンサルタント試験の「ことば」から学べる試験対策サイト。むずかしい専門用語を、暮らしの中の身近なたとえと、試験に必要な正式な説明の両方から学べます。",
  /** デプロイ先(canonical / OGP / sitemap に使用) */
  baseUrl: "https://asakojun-cmyk.github.io/sunny",
  author: {
    name: "このサイトの運営者",
    bio: "3児の母。国家資格キャリアコンサルタント養成講座を受講中。2026年11月の試験に向けて勉強中の初学者として、実際に分からなかった言葉を解説しています。",
  },
} as const;

/** ヘッダーの主要ナビ(増やしすぎない) */
export const NAV_ITEMS = [
  { label: "ことば図鑑", href: "/terms/" },
  { label: "理論家", href: "/theorists/" },
  { label: "試験対策", href: "/start/" },
  { label: "養成講座", href: "/schools/" },
  { label: "資格取得後", href: "/careers/" },
] as const;

/** スマホ下部ナビ */
export const BOTTOM_NAV = [
  { label: "ホーム", href: "/", icon: "home" },
  { label: "用語検索", href: "/search/", icon: "search" },
  { label: "今日の問題", href: "/#daily", icon: "quiz" },
  { label: "学校比較", href: "/schools/compare/", icon: "compare" },
  { label: "メニュー", href: "#menu", icon: "menu" },
] as const;

/** トップページ「カテゴリーから探す」(初期表示6カテゴリー) */
export const CATEGORIES = [
  {
    en: "WORDS",
    emoji: "🌥️",
    name: "キャリコンことば図鑑",
    description: "難しい専門用語を、やさしい言葉から理解する",
    href: "/terms/",
  },
  {
    en: "THEORISTS",
    emoji: "☀️",
    name: "理論家図鑑",
    description: "理論家と理論の「混ざる」を、違いで整理する",
    href: "/theorists/",
  },
  {
    en: "LAW & DATA",
    emoji: "☂️",
    name: "労働法・統計・制度",
    description: "苦手になりやすい分野を、一次資料への入口つきで読み解く",
    href: "/laws/",
  },
  {
    en: "EXAM",
    emoji: "🌈",
    name: "学科・論述・面接",
    description: "学科・論述・面接を、ばらばらでなく「つながり」で学ぶ",
    href: "/exam/",
  },
  {
    en: "SCHOOLS",
    emoji: "🌤️",
    name: "養成講座の選び方",
    description: "公式情報と受講者本人の体験を分けて、落ち着いて比較する",
    href: "/schools/",
  },
  {
    en: "FUTURE",
    emoji: "🌈",
    name: "資格取得後の働き方",
    description: "資格を取ったあとの仕事と暮らしを、現実的に知る",
    href: "/careers/",
  },
] as const;

/** よく検索される用語(トップの検索欄の下に表示) */
export const POPULAR_SEARCH_TERMS = [
  "自己概念",
  "転機",
  "感情の反映",
  "自己効力感",
  "ジョハリの窓",
  "キャリア・アンカー",
] as const;

/** 用語カテゴリーと天気アイコンの対応(天気=転機の世界観) */
export const CATEGORY_WEATHER: Record<string, string> = {
  キャリア理論: "☀️",
  カウンセリング理論: "🌈",
  カウンセリング技法: "🌤️",
  "制度・支援": "☂️",
};

/** 試験機関の公式過去問ページ(過去問本文は転載しない) */
export const PAST_EXAM_SOURCES = [
  {
    label: "キャリアコンサルティング協議会「過去問題/学習情報」",
    url: "https://www.career-shiken.org/about/learninfo/",
  },
  {
    label: "日本キャリア開発協会(JCDA)「過去問題」",
    url: "https://www.jcda-careerex.org/past/",
  },
] as const;
