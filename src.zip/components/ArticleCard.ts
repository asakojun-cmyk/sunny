import { esc, formatDate } from "../lib/html";
import type { ArticleMeta } from "../lib/types";
import { PrLabel } from "./PrLabel";

/** 記事カード(最新記事・注目記事) */
export function ArticleCard(a: ArticleMeta): string {
  return `<article class="article-card">
    <a href="/${esc(a.slug)}/" class="article-card__link">
      <p class="article-card__meta">
        <span class="article-card__category">${esc(a.category)}</span>
        <time datetime="${esc(a.updatedAt)}">${esc(formatDate(a.updatedAt))}</time>
        ${PrLabel(a.isPr)}
        ${a.beginnerFriendly ? '<span class="beginner-label">初心者向け</span>' : ""}
      </p>
      <h3 class="article-card__title">${esc(a.title)}</h3>
      <p class="article-card__desc">${esc(a.description)}</p>
      ${
        a.readingMinutes
          ? `<p class="article-card__minutes">読了目安 約${a.readingMinutes}分</p>`
          : ""
      }
    </a>
  </article>`;
}

/** 罫線区切りの記事リスト項目 */
export function ArticleListItem(a: ArticleMeta): string {
  return `<li class="article-list-item">
    <a href="/${esc(a.slug)}/">
      <span class="article-list-item__meta">
        <span class="article-list-item__category">${esc(a.category)}</span>
        <time datetime="${esc(a.updatedAt)}">${esc(formatDate(a.updatedAt))}</time>
        ${PrLabel(a.isPr)}
      </span>
      <span class="article-list-item__title">${esc(a.title)}</span>
    </a>
  </li>`;
}

/** 注目記事(編集部ピックアップ) */
export function FeaturedArticle(a: ArticleMeta): string {
  return `<article class="featured-article">
    <a href="/${esc(a.slug)}/">
      <p class="featured-article__meta">
        <span>${esc(a.categoryEn)}</span>
        ${PrLabel(a.isPr)}
      </p>
      <h3 class="featured-article__title">${esc(a.title)}</h3>
      <p class="featured-article__desc">${esc(a.description)}</p>
    </a>
  </article>`;
}
