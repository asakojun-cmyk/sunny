import { schools } from "../data/schools/index";
import { SchoolCard } from "./SchoolCard";

/**
 * ママが通いやすい養成講座(トップページ)。
 * 学校を最大4件表示。広告校だけを先頭に固定しない(データ順のまま表示)。
 */
export function SchoolComparisonFeature(): string {
  const shown = schools.slice(0, 4);
  return `<div class="school-feature">
    <p class="school-feature__desc">オンライン、曜日、振替制度、録画、試験対策など、子育てとの両立に関係する条件から比較します。</p>
    <div class="school-grid">
      ${shown.map((s) => SchoolCard(s)).join("")}
    </div>
    <p class="school-feature__cta"><a class="button button--primary" href="/schools/compare/">養成講座${shown.length}校を比較する</a></p>
  </div>`;
}
