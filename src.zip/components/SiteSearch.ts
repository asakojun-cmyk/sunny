import { esc } from "../lib/html";
import { POPULAR_SEARCH_TERMS } from "../lib/site";

/** 検索欄。/search/ に GET で飛ばす(静的サイトのためクライアント側で処理) */
export function SiteSearch(opts?: {
  heading?: string;
  large?: boolean;
  showPopular?: boolean;
}): string {
  const heading = opts?.heading ?? "今、わからない言葉は何ですか?";
  return `<section class="site-search${opts?.large ? " site-search--large" : ""}">
    <h2 class="site-search__heading">${esc(heading)}</h2>
    <form class="site-search__form" action="/search/" method="get" role="search">
      <label class="visually-hidden" for="site-search-input">サイト内検索</label>
      <input type="search" id="site-search-input" name="q" placeholder="例:自己概念、スーパー、感情の反映" autocomplete="off">
      <button type="submit" class="button button--primary">検索</button>
    </form>
    ${
      opts?.showPopular
        ? `<p class="site-search__popular">よく検索される言葉:
        ${POPULAR_SEARCH_TERMS.map(
          (t) => `<a href="/search/?q=${encodeURIComponent(t)}">${esc(t)}</a>`
        ).join("")}
      </p>`
        : ""
    }
  </section>`;
}
