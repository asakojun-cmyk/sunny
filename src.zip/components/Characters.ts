import { esc } from "../lib/html";

/**
 * サイトの案内キャラクター(インラインSVG・オリジナル)
 * - モヤン: 雲のキャラクター。読者と同じ「勉強中」の仲間。わからないことを代弁する。
 * - さんさんサニー先生: 太陽のキャラクター。モヤンに似た顔の先生役。やさしく教える。
 * 画像ファイルに依存しないので、差し替えたい場合はこの関数のSVGを変えるだけでよい。
 */

/** モヤン(雲の小学生)。teary=true で泣き顔になる。黄色い通学帽をかぶる。 */
export function MoyanSvg(size = 96, teary = false): string {
  // 幼い顔: 大きめのまん丸の目 + ハイライト、小さな口
  const face = teary
    ? `<!-- め(くりくりのおめめは開けたまま・ハイライトつき・すこし下に) -->
  <circle cx="48" cy="64.5" r="6" fill="#4a505c"/>
  <circle cx="72" cy="64.5" r="6" fill="#4a505c"/>
  <circle cx="50.4" cy="62.1" r="1.9" fill="#ffffff"/>
  <circle cx="74.4" cy="62.1" r="1.9" fill="#ffffff"/>
  <!-- なみだ(目じりの外側から、すーっと流れる) -->
  <path d="M39.5 71 q-3 8.5 0 12.5 q3 -3.8 0 -12.5 Z" fill="#8fd0e6"/>
  <path d="M80.5 71 q-3 8.5 0 12.5 q3 -3.8 0 -12.5 Z" fill="#8fd0e6"/>
  <!-- くち(ちいさな困り口・すこし下に) -->
  <path d="M55 79.5 q5 -4 10 0" fill="none" stroke="#4a505c" stroke-width="2.6" stroke-linecap="round"/>`
    : `<!-- め(まん丸・ハイライトつき) -->
  <circle cx="48" cy="62" r="6" fill="#4a505c"/>
  <circle cx="72" cy="62" r="6" fill="#4a505c"/>
  <circle cx="50.4" cy="59.6" r="1.9" fill="#ffffff"/>
  <circle cx="74.4" cy="59.6" r="1.9" fill="#ffffff"/>
  <!-- くち(ちいさな笑み) -->
  <path d="M56 73 q4 4 8 0" fill="none" stroke="#4a505c" stroke-width="2.6" stroke-linecap="round"/>`;
  return `<svg class="chara chara--moyan" width="${size}" height="${size}" viewBox="0 0 120 120" role="img" aria-label="モヤン(黄色い通学帽をかぶった小学生の雲)">
  <!-- からだ(白い雲・まるく幼い) -->
  <path d="M30 92
           C15 92 9 79 16 69 C7 60 14 46 27 47
           C30 34 47 30 56 38 C65 28 86 32 88 47
           C103 47 108 62 100 71 C108 81 99 92 87 92 Z"
        fill="#ffffff" stroke="#9fa9b6" stroke-width="3" stroke-linejoin="round"/>
  <!-- 黄色い通学帽 -->
  <path d="M30 44 q28 -26 60 0 Z" fill="#f4d64f" stroke="#d3b032" stroke-width="2.5" stroke-linejoin="round"/>
  <path d="M26 44 q34 -7 68 0 q0 4 -4 5 q-30 -5 -60 0 q-4 -1 -4 -5 Z" fill="#f4d64f" stroke="#d3b032" stroke-width="2.5" stroke-linejoin="round"/>
  <circle cx="60" cy="20" r="4" fill="#f4d64f" stroke="#d3b032" stroke-width="2.5"/>
  <!-- ほっぺ -->
  <circle cx="38" cy="70" r="5.5" fill="#f6b8ad" opacity="0.85"/>
  <circle cx="82" cy="70" r="5.5" fill="#f6b8ad" opacity="0.85"/>
  ${face}
</svg>`;
}

/** さんさんサニー先生(太陽・先生) */
export function SunnySvg(size = 96): string {
  return `<svg class="chara chara--sunny" width="${size}" height="${size}" viewBox="0 0 120 120" role="img" aria-label="さんさんサニー先生(太陽のキャラクター)">
  <!-- 光線 -->
  <g stroke="#e9dc4f" stroke-width="5" stroke-linecap="round">
    <line x1="60" y1="6" x2="60" y2="18"/>
    <line x1="60" y1="102" x2="60" y2="114"/>
    <line x1="6" y1="60" x2="18" y2="60"/>
    <line x1="102" y1="60" x2="114" y2="60"/>
    <line x1="22" y1="22" x2="30" y2="30"/>
    <line x1="90" y1="90" x2="98" y2="98"/>
    <line x1="90" y1="30" x2="98" y2="22"/>
    <line x1="22" y1="98" x2="30" y2="90"/>
  </g>
  <!-- かお(レモンイエローの太陽) -->
  <circle cx="60" cy="60" r="34" fill="#f9ef79" stroke="#cdbf3c" stroke-width="3"/>
  <!-- ほっぺ -->
  <circle cx="44" cy="68" r="5" fill="#f4b98a" opacity="0.8"/>
  <circle cx="76" cy="68" r="5" fill="#f4b98a" opacity="0.8"/>
  <!-- せんせいメガネ -->
  <g fill="none" stroke="#8a7a20" stroke-width="2.4">
    <circle cx="49" cy="58" r="8"/>
    <circle cx="71" cy="58" r="8"/>
    <path d="M57 58 h6"/>
  </g>
  <!-- め -->
  <circle cx="49" cy="58" r="3.2" fill="#4a3a20"/>
  <circle cx="71" cy="58" r="3.2" fill="#4a3a20"/>
  <!-- くち(にっこり) -->
  <path d="M52 72 q8 8 16 0" fill="none" stroke="#4a3a20" stroke-width="2.6" stroke-linecap="round"/>
</svg>`;
}


/** ひらめいたモヤン(目がかがやいて、口があいている。頭の上にひらめきの光) */
export function MoyanIdeaSvg(size = 96): string {
  return `<svg class="chara chara--moyan" width="${size}" height="${size}" viewBox="0 0 120 120" role="img" aria-label="ひらめいたモヤン">
  <!-- ひらめきの光 -->
  <g stroke="#f4b942" stroke-width="3.4" stroke-linecap="round">
    <line x1="97" y1="18" x2="104" y2="10"/>
    <line x1="102" y1="30" x2="112" y2="28"/>
    <line x1="90" y1="12" x2="92" y2="3"/>
  </g>
  <path d="M104 20 l1.7 4.3 4.3 1.7 -4.3 1.7 -1.7 4.3 -1.7 -4.3 -4.3 -1.7 4.3 -1.7 Z" fill="#f4d64f"/>
  <!-- からだ(白い雲) -->
  <path d="M30 92 C15 92 9 79 16 69 C7 60 14 46 27 47 C30 34 47 30 56 38 C65 28 86 32 88 47 C103 47 108 62 100 71 C108 81 99 92 87 92 Z"
        fill="#ffffff" stroke="#9fa9b6" stroke-width="3" stroke-linejoin="round"/>
  <!-- 黄色い通学帽 -->
  <path d="M30 44 q28 -26 60 0 Z" fill="#f4d64f" stroke="#d3b032" stroke-width="2.5" stroke-linejoin="round"/>
  <path d="M26 44 q34 -7 68 0 q0 4 -4 5 q-30 -5 -60 0 q-4 -1 -4 -5 Z" fill="#f4d64f" stroke="#d3b032" stroke-width="2.5" stroke-linejoin="round"/>
  <circle cx="60" cy="20" r="4" fill="#f4d64f" stroke="#d3b032" stroke-width="2.5"/>
  <!-- ほっぺ -->
  <circle cx="38" cy="70" r="5.5" fill="#f6b8ad" opacity="0.85"/>
  <circle cx="82" cy="70" r="5.5" fill="#f6b8ad" opacity="0.85"/>
  <!-- め(かがやく大きな目) -->
  <circle cx="48" cy="62" r="6.3" fill="#4a505c"/>
  <circle cx="72" cy="62" r="6.3" fill="#4a505c"/>
  <circle cx="50.6" cy="59.4" r="2.3" fill="#ffffff"/>
  <circle cx="74.6" cy="59.4" r="2.3" fill="#ffffff"/>
  <circle cx="46.2" cy="64.6" r="1.1" fill="#ffffff"/>
  <circle cx="70.2" cy="64.6" r="1.1" fill="#ffffff"/>
  <!-- くち(わあ!とあいた口) -->
  <path d="M55 73 q5 7 10 0 q-5 9 -10 0 Z" fill="#4a505c"/>
</svg>`;
}

/** 本を読んで学んでいるモヤン */
export function MoyanBookSvg(size = 96): string {
  return `<svg class="chara chara--moyan" width="${size}" height="${size}" viewBox="0 0 120 120" role="img" aria-label="本を読んで学んでいるモヤン">
  <!-- からだ(白い雲) -->
  <path d="M30 92 C15 92 9 79 16 69 C7 60 14 46 27 47 C30 34 47 30 56 38 C65 28 86 32 88 47 C103 47 108 62 100 71 C108 81 99 92 87 92 Z"
        fill="#ffffff" stroke="#9fa9b6" stroke-width="3" stroke-linejoin="round"/>
  <!-- 黄色い通学帽 -->
  <path d="M30 44 q28 -26 60 0 Z" fill="#f4d64f" stroke="#d3b032" stroke-width="2.5" stroke-linejoin="round"/>
  <path d="M26 44 q34 -7 68 0 q0 4 -4 5 q-30 -5 -60 0 q-4 -1 -4 -5 Z" fill="#f4d64f" stroke="#d3b032" stroke-width="2.5" stroke-linejoin="round"/>
  <circle cx="60" cy="20" r="4" fill="#f4d64f" stroke="#d3b032" stroke-width="2.5"/>
  <!-- ほっぺ -->
  <circle cx="38" cy="70" r="5.5" fill="#f6b8ad" opacity="0.85"/>
  <circle cx="82" cy="70" r="5.5" fill="#f6b8ad" opacity="0.85"/>
  <!-- め(本を見つめる、すこし下向き) -->
  <circle cx="48" cy="65" r="5.6" fill="#4a505c"/>
  <circle cx="72" cy="65" r="5.6" fill="#4a505c"/>
  <circle cx="49.8" cy="63" r="1.7" fill="#ffffff"/>
  <circle cx="73.8" cy="63" r="1.7" fill="#ffffff"/>
  <!-- くち(ふむふむ) -->
  <path d="M56 75 q4 3 8 0" fill="none" stroke="#4a505c" stroke-width="2.4" stroke-linecap="round"/>
  <!-- ひらいた本 -->
  <g stroke="#8d97a5" stroke-width="2.4" stroke-linejoin="round">
    <path d="M60 90 q-13 -8 -26 -3 l0 16 q13 -5 26 3 Z" fill="#fdfcf7"/>
    <path d="M60 90 q13 -8 26 -3 l0 16 q-13 -5 -26 3 Z" fill="#fdfcf7"/>
  </g>
  <g stroke="#c3cad3" stroke-width="1.6" stroke-linecap="round">
    <line x1="41" y1="93.5" x2="53" y2="95.5"/>
    <line x1="41" y1="98.5" x2="53" y2="100.5"/>
    <line x1="67" y1="95.5" x2="79" y2="93.5"/>
    <line x1="67" y1="100.5" x2="79" y2="98.5"/>
  </g>
</svg>`;
}

/** にっこり笑顔のサニー先生(目をとじて、ほほえむ) */
export function SunnyHappySvg(size = 96): string {
  return `<svg class="chara chara--sunny" width="${size}" height="${size}" viewBox="0 0 120 120" role="img" aria-label="笑顔のサニー先生">
  <g stroke="#e9dc4f" stroke-width="5" stroke-linecap="round">
    <line x1="60" y1="6" x2="60" y2="18"/>
    <line x1="60" y1="102" x2="60" y2="114"/>
    <line x1="6" y1="60" x2="18" y2="60"/>
    <line x1="102" y1="60" x2="114" y2="60"/>
    <line x1="22" y1="22" x2="30" y2="30"/>
    <line x1="90" y1="90" x2="98" y2="98"/>
    <line x1="90" y1="30" x2="98" y2="22"/>
    <line x1="22" y1="98" x2="30" y2="90"/>
  </g>
  <circle cx="60" cy="60" r="34" fill="#f9ef79" stroke="#cdbf3c" stroke-width="3"/>
  <circle cx="44" cy="68" r="5" fill="#f4b98a" opacity="0.8"/>
  <circle cx="76" cy="68" r="5" fill="#f4b98a" opacity="0.8"/>
  <!-- せんせいメガネ -->
  <g fill="none" stroke="#8a7a20" stroke-width="2.4">
    <circle cx="49" cy="58" r="8"/>
    <circle cx="71" cy="58" r="8"/>
    <path d="M57 58 h6"/>
  </g>
  <!-- め(にっこり とじ目) -->
  <path d="M45 58.5 q4 -4.5 8 0" fill="none" stroke="#4a3a20" stroke-width="2.6" stroke-linecap="round"/>
  <path d="M67 58.5 q4 -4.5 8 0" fill="none" stroke="#4a3a20" stroke-width="2.6" stroke-linecap="round"/>
  <!-- くち(おおきなにっこり) -->
  <path d="M50 71 q10 10 20 0" fill="none" stroke="#4a3a20" stroke-width="2.8" stroke-linecap="round"/>
</svg>`;
}

export type Speaker = "moyan" | "sunny";

const SPEAKER_NAME: Record<Speaker, string> = {
  moyan: "モヤン",
  sunny: "サニー先生",
};

/**
 * キャラクターの吹き出し。モヤン=左、サニー=右に立つ。
 * text は装飾なしのプレーン文。teary=true でモヤンが泣き顔になる。
 */
export function CharacterGuide(
  speaker: Speaker,
  text: string,
  size = 72,
  teary = false
): string {
  const svg = speaker === "moyan" ? MoyanSvg(size, teary) : SunnySvg(size);
  return `<div class="chara-guide chara-guide--${speaker}">
    <div class="chara-guide__figure">
      ${svg}
      <span class="chara-guide__name">${esc(SPEAKER_NAME[speaker])}</span>
    </div>
    <p class="chara-guide__bubble">${esc(text)}</p>
  </div>`;
}

/** モヤン→サニーの掛け合い(質問→こたえ) */
export function CharacterDialogue(question: string, answer: string): string {
  return `<div class="chara-dialogue">
    ${CharacterGuide("moyan", question)}
    ${CharacterGuide("sunny", answer)}
  </div>`;
}
