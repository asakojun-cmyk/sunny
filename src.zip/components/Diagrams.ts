import { esc } from "../lib/html";

/**
 * 理論の図解イラスト(オリジナルSVG)。
 * 人物写真・書籍の図の転載は著作権上できないため、
 * 各理論の考え方を基に当サイトが作成したイメージ図を掲載する。
 * 図の下に必ず「出典(何を基に作成したか)」を表示する。
 */

function figure(svg: string, caption: string, source: string): string {
  return `<figure class="diagram">
    ${svg}
    <figcaption>
      <span class="diagram__caption">${esc(caption)}</span>
      <span class="diagram__source">出典: ${esc(source)}</span>
    </figcaption>
  </figure>`;
}

const T = (
  x: number,
  y: number,
  text: string,
  size = 11,
  anchor = "middle",
  color = "#3f4652",
  bold = false
) =>
  `<text x="${x}" y="${y}" font-size="${size}" text-anchor="${anchor}" fill="${color}"${bold ? ' font-weight="700"' : ""}>${esc(text)}</text>`;

const BOX = (
  x: number,
  y: number,
  w: number,
  h: number,
  fill: string,
  stroke = "#9fa9b6"
) =>
  `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="8" fill="${fill}" stroke="${stroke}" stroke-width="1.5"/>`;

const ARROW = (x1: number, y1: number, x2: number, y2: number) =>
  `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#8a7a20" stroke-width="2" marker-end="url(#arw)"/>`;

const DEFS = `<defs><marker id="arw" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6 Z" fill="#8a7a20"/></marker></defs>`;

function svgWrap(inner: string, vb = "0 0 340 210", label = "図解"): string {
  return `<svg class="diagram__svg" viewBox="${vb}" role="img" aria-label="${esc(label)}">${DEFS}${inner}</svg>`;
}

/* ---------- 各図解 ---------- */

const DIAGRAMS: Record<string, () => string> = {
  "jiko-gainen": () =>
    figure(
      svgWrap(
        `${BOX(70, 20, 200, 170, "#fffdf8")}
        ${T(170, 45, "わたしの紹介カード", 13, "middle", "#3f4652", true)}
        <line x1="90" y1="55" x2="250" y2="55" stroke="#d8d2c7"/>
        ${T(95, 80, "🌟 得意なこと", 12, "start")}
        ${T(95, 110, "💛 大切にしたいこと", 12, "start")}
        ${T(95, 140, "🌧️ 苦手なこと", 12, "start")}
        ${T(95, 170, "…経験すると書き換わる", 11, "start", "#6f6b63")}`,
        "0 0 340 210",
        "自己概念のイメージ図(心の中の紹介カード)"
      ),
      "自己概念=心の中にある「自分の紹介カード」",
      "スーパー(D. E. Super)の自己概念の考え方を基に当サイト作成(イメージ図)"
    ),

  "life-career-rainbow": () =>
    figure(
      svgWrap(
        `<g fill="none" stroke-width="14">
          <path d="M40 190 A130 130 0 0 1 300 190" stroke="#f3b6a5"/>
          <path d="M56 190 A114 114 0 0 1 284 190" stroke="#f6d08b"/>
          <path d="M72 190 A98 98 0 0 1 268 190" stroke="#f9ef79"/>
          <path d="M88 190 A82 82 0 0 1 252 190" stroke="#bcd9a8"/>
          <path d="M104 190 A66 66 0 0 1 236 190" stroke="#a9cbd8"/>
          <path d="M120 190 A50 50 0 0 1 220 190" stroke="#c3b8dd"/>
        </g>
        ${T(170, 120, "子ども・学生・余暇人", 11)}
        ${T(170, 138, "市民・労働者・家庭人", 11)}
        ${T(170, 165, "役割の虹", 12, "middle", "#3f4652", true)}
        ${T(40, 205, "誕生", 11, "start")}
        ${T(300, 205, "人生の時間", 11, "end")}`,
        "0 0 340 215",
        "ライフ・キャリア・レインボーのイメージ図"
      ),
      "人生の役割を虹の帯にたとえた図。帯の太さは時期によって変わる",
      "スーパーのライフ・キャリア・レインボーの考え方を基に当サイト作成(イメージ図)"
    ),

  "jiko-koryokukan": () =>
    figure(
      svgWrap(
        `${BOX(10, 15, 130, 34, "#fffdf8")}${T(75, 37, "① 成功体験", 12)}
        ${BOX(10, 60, 130, 34, "#fffdf8")}${T(75, 82, "② 人のまね(代理的経験)", 11)}
        ${BOX(10, 105, 130, 34, "#fffdf8")}${T(75, 127, "③ 励まし(言語的説得)", 11)}
        ${BOX(10, 150, 130, 34, "#fffdf8")}${T(75, 172, "④ 体調・気分", 12)}
        ${ARROW(145, 32, 195, 85)}${ARROW(145, 77, 195, 95)}
        ${ARROW(145, 122, 195, 110)}${ARROW(145, 167, 195, 120)}
        ${BOX(200, 60, 130, 85, "#fbf6d8", "#cdbf3c")}
        ${T(265, 90, "できそう", 14, "middle", "#3f4652", true)}
        ${T(265, 110, "メーター", 14, "middle", "#3f4652", true)}
        ${T(265, 132, "= 自己効力感", 11)}`,
        "0 0 340 200",
        "自己効力感を高める4つの情報源の図"
      ),
      "4つの情報源が「できそうメーター」を上げ下げする",
      "バンデューラ(A. Bandura)の自己効力感の4つの情報源を基に当サイト作成(イメージ図)"
    ),

  "career-anchor": () =>
    figure(
      svgWrap(
        `<path d="M170 30 v90 M170 120 q-40 40 -70 20 M170 120 q40 40 70 20" fill="none" stroke="#8a7a20" stroke-width="6" stroke-linecap="round"/>
        <circle cx="170" cy="22" r="10" fill="none" stroke="#8a7a20" stroke-width="5"/>
        <line x1="130" y1="60" x2="210" y2="60" stroke="#8a7a20" stroke-width="5" stroke-linecap="round"/>
        ${T(60, 40, "専門・職能", 11)}${T(280, 40, "全般管理", 11)}
        ${T(45, 80, "自律・独立", 11)}${T(295, 80, "保障・安定", 11)}
        ${T(45, 120, "起業家的創造性", 10)}${T(295, 120, "奉仕・社会貢献", 10)}
        ${T(60, 160, "純粋な挑戦", 11)}${T(280, 160, "生活様式", 11)}
        ${T(170, 195, "ゆずれない8つの「いかり」", 12, "middle", "#3f4652", true)}`,
        "0 0 340 210",
        "キャリア・アンカー(8種類)のイメージ図"
      ),
      "船のいかりのように、自分を流されにくくする8つの軸",
      "シャイン(E. H. Schein)の8つのキャリア・アンカーを基に当サイト作成(イメージ図)"
    ),

  tenki: () =>
    figure(
      svgWrap(
        `${T(170, 26, "🌧️ 転機がきたら、4つのSで点検 ☂️", 13, "middle", "#3f4652", true)}
        ${BOX(15, 45, 150, 60, "#fffdf8")}
        ${T(90, 68, "Situation(状況)", 12, "middle", "#3f4652", true)}${T(90, 88, "何が起きてる?", 11)}
        ${BOX(175, 45, 150, 60, "#fffdf8")}
        ${T(250, 68, "Self(自分)", 12, "middle", "#3f4652", true)}${T(250, 88, "自分の強み・経験は?", 11)}
        ${BOX(15, 115, 150, 60, "#fffdf8")}
        ${T(90, 138, "Support(支え)", 12, "middle", "#3f4652", true)}${T(90, 158, "頼れる人・制度は?", 11)}
        ${BOX(175, 115, 150, 60, "#fffdf8")}
        ${T(250, 138, "Strategies(戦略)", 12, "middle", "#3f4652", true)}${T(250, 158, "どう乗り切る?", 11)}
        ${T(170, 198, "点検できたら、雨はやがて 🌈 に", 12)}`,
        "0 0 340 210",
        "シュロスバーグの4Sのイメージ図"
      ),
      "転機を乗り切るための4つの資源(4S)",
      "シュロスバーグ(N. K. Schlossberg)の4Sを基に当サイト作成(イメージ図)"
    ),

  "johari-window": () =>
    figure(
      svgWrap(
        `${T(105, 22, "自分は知っている", 11)}${T(255, 22, "自分は知らない", 11)}
        ${T(24, 75, "他人は", 10)}${T(24, 88, "知っている", 10)}
        ${T(24, 145, "他人は", 10)}${T(24, 158, "知らない", 10)}
        ${BOX(55, 32, 130, 75, "#fbf6d8", "#cdbf3c")}${T(120, 65, "開放の窓", 12, "middle", "#3f4652", true)}${T(120, 85, "みんな知ってる私", 10)}
        ${BOX(190, 32, 130, 75, "#fffdf8")}${T(255, 65, "盲点の窓", 12, "middle", "#3f4652", true)}${T(255, 85, "自分だけ気づいてない", 10)}
        ${BOX(55, 112, 130, 75, "#fffdf8")}${T(120, 145, "秘密の窓", 12, "middle", "#3f4652", true)}${T(120, 165, "自分だけが知ってる", 10)}
        ${BOX(190, 112, 130, 75, "#eef2f5")}${T(255, 145, "未知の窓", 12, "middle", "#3f4652", true)}${T(255, 165, "まだ誰も知らない", 10)}`,
        "0 0 340 200",
        "ジョハリの窓(4つの窓)の図"
      ),
      "自己開示とフィードバックで「開放の窓」を広げていく",
      "ルフト&インガム(Luft & Ingham)のジョハリの窓を基に当サイト作成(イメージ図)"
    ),

  "abc-riron": () =>
    figure(
      svgWrap(
        `${BOX(10, 70, 90, 60, "#fffdf8")}
        ${T(55, 93, "A", 16, "middle", "#8a7a20", true)}${T(55, 115, "出来事", 11)}
        ${ARROW(105, 100, 125, 100)}
        ${BOX(130, 70, 90, 60, "#fbf6d8", "#cdbf3c")}
        ${T(175, 93, "B", 16, "middle", "#8a7a20", true)}${T(175, 115, "受け取り方(信念)", 9.5)}
        ${ARROW(225, 100, 245, 100)}
        ${BOX(250, 70, 80, 60, "#fffdf8")}
        ${T(290, 93, "C", 16, "middle", "#8a7a20", true)}${T(290, 115, "感情・結果", 10)}
        ${T(175, 35, "気持ちを決めるのは出来事(A)ではなく", 11)}
        ${T(175, 52, "受け取り方(B)", 12, "middle", "#3f4652", true)}
        ${T(170, 165, "非合理的な信念(イラショナル・ビリーフ)に", 10.5)}
        ${T(170, 182, "気づいて反論(D)すると、効果(E)が生まれる", 10.5)}`,
        "0 0 340 200",
        "論理療法のABC理論の図"
      ),
      "A(出来事)→B(信念)→C(結果)。Bを見直すのが論理療法",
      "エリス(A. Ellis)の論理療法(ABC理論)を基に当サイト作成(イメージ図)"
    ),

  "coffee-cup-model": () =>
    figure(
      svgWrap(
        `<path d="M80 40 q90 150 90 150 q90 0 90 -150" fill="none" stroke="#8a7a20" stroke-width="4" stroke-linecap="round"/>
        <path d="M80 40 h180" stroke="#8a7a20" stroke-width="4" stroke-linecap="round"/>
        ${T(170, 70, "① リレーションをつくる", 12, "middle", "#3f4652", true)}
        ${T(170, 110, "② 問題の核心をつかむ", 12, "middle", "#3f4652", true)}
        ${T(170, 150, "③ 問題を解決する", 12, "middle", "#3f4652", true)}
        ${T(170, 195, "カップの断面のように、上から順に深めていく", 11)}`,
        "0 0 340 210",
        "コーヒーカップ・モデルの図"
      ),
      "面接の流れをコーヒーカップの断面にたとえたモデル",
      "國分康孝のコーヒーカップ・モデルを基に当サイト作成(イメージ図)"
    ),

  "systematic-approach": () =>
    figure(
      svgWrap(
        `${BOX(10, 20, 150, 40, "#fbf6d8", "#cdbf3c")}${T(85, 45, "① 関係をつくる", 12)}
        ${ARROW(85, 62, 85, 78)}
        ${BOX(10, 80, 150, 40, "#fffdf8")}${T(85, 105, "② 問題をつかむ", 12)}
        ${ARROW(85, 122, 85, 138)}
        ${BOX(10, 140, 150, 40, "#fffdf8")}${T(85, 165, "③ 目標を決める", 12)}
        ${ARROW(165, 160, 185, 160)}
        ${BOX(185, 140, 145, 40, "#fffdf8")}${T(257, 165, "④ 方策を実行する", 12)}
        ${ARROW(257, 138, 257, 122)}
        ${BOX(185, 80, 145, 40, "#fffdf8")}${T(257, 105, "⑤ 結果を評価する", 12)}
        ${ARROW(257, 78, 257, 62)}
        ${BOX(185, 20, 145, 40, "#eef2f5")}${T(257, 45, "⑥ ケースの終了", 12)}`,
        "0 0 340 195",
        "システマティック・アプローチの6段階の図"
      ),
      "相談を進める6つのステップ。土台は①の関係づくり",
      "システマティック・アプローチの一般的な段階整理を基に当サイト作成(イメージ図)"
    ),

  "career-adaptability": () =>
    figure(
      svgWrap(
        `<circle cx="170" cy="105" r="42" fill="#f9ef79" stroke="#cdbf3c" stroke-width="3"/>
        ${T(170, 100, "キャリア", 12, "middle", "#3f4652", true)}
        ${T(170, 118, "適応力", 12, "middle", "#3f4652", true)}
        ${BOX(15, 20, 120, 40, "#fffdf8")}${T(75, 45, "関心 Concern", 12)}
        ${BOX(205, 20, 120, 40, "#fffdf8")}${T(265, 45, "統制 Control", 12)}
        ${BOX(15, 150, 120, 40, "#fffdf8")}${T(75, 175, "好奇心 Curiosity", 12)}
        ${BOX(205, 150, 120, 40, "#fffdf8")}${T(265, 175, "自信 Confidence", 12)}
        ${ARROW(100, 62, 140, 82)}${ARROW(240, 62, 200, 82)}
        ${ARROW(100, 148, 140, 128)}${ARROW(240, 148, 200, 128)}`,
        "0 0 340 200",
        "キャリア・アダプタビリティの4次元の図"
      ),
      "変化に適応する力を支える4つのC",
      "サビカス(M. L. Savickas)のキャリア・アダプタビリティ4次元を基に当サイト作成(イメージ図)"
    ),

  microcounseling: () =>
    figure(
      svgWrap(
        `<polygon points="170,15 320,185 20,185" fill="#fffdf8" stroke="#9fa9b6" stroke-width="1.5"/>
        <line x1="105" y1="130" x2="235" y2="130" stroke="#d8d2c7"/>
        <line x1="130" y1="100" x2="210" y2="100" stroke="#d8d2c7"/>
        <line x1="82" y1="157" x2="258" y2="157" stroke="#d8d2c7"/>
        ${T(170, 92, "統合", 11)}
        ${T(170, 120, "積極技法", 11)}
        ${T(170, 148, "基本的傾聴の連鎖", 11)}
        ${T(170, 176, "かかわり行動(視線・身体言語・声・言語的追跡)", 10, "middle", "#3f4652", true)}`,
        "0 0 340 200",
        "マイクロカウンセリングの技法の階層のイメージ図"
      ),
      "土台は「かかわり行動」。積み上げ式の技法の階層",
      "アイビイ(A. E. Ivey)のマイクロカウンセリング技法階層を基に当サイト作成(イメージ図)"
    ),

  "tokusei-inshi": () =>
    figure(
      svgWrap(
        `<circle cx="85" cy="80" r="38" fill="#fbf6d8" stroke="#cdbf3c" stroke-width="2"/>
        ${T(85, 76, "自分", 13, "middle", "#3f4652", true)}${T(85, 94, "特性を知る", 10)}
        <rect x="215" y="42" width="80" height="76" rx="10" fill="#eef2f5" stroke="#9fa9b6" stroke-width="2"/>
        ${T(255, 76, "仕事", 13, "middle", "#3f4652", true)}${T(255, 94, "条件を知る", 10)}
        ${ARROW(130, 80, 208, 80)}
        ${T(170, 66, "合理的な推論", 10.5)}
        ${T(170, 150, "「丸い釘は丸い穴に」", 13, "middle", "#3f4652", true)}
        ${T(170, 175, "自分を知る × 仕事を知る × 2つを結ぶ", 11)}`,
        "0 0 340 195",
        "特性因子理論(マッチング)の図"
      ),
      "自己理解と職業理解をつなぐマッチングの考え方",
      "パーソンズ(F. Parsons)の特性因子理論を基に当サイト作成(イメージ図)"
    ),

  holland: () =>
    figure(
      svgWrap(
        `<polygon points="170,25 275,80 275,150 170,195 65,150 65,80" fill="#fffdf8" stroke="#9fa9b6" stroke-width="1.5"/>
        ${T(170, 18, "R 現実的", 11, "middle", "#3f4652", true)}
        ${T(292, 78, "I 研究的", 11, "start", "#3f4652", true)}
        ${T(292, 155, "A 芸術的", 11, "start", "#3f4652", true)}
        ${T(170, 209, "S 社会的", 11, "middle", "#3f4652", true)}
        ${T(48, 155, "E 企業的", 11, "end", "#3f4652", true)}
        ${T(48, 78, "C 慣習的", 11, "end", "#3f4652", true)}
        ${T(170, 105, "人も環境も", 11)}
        ${T(170, 122, "同じ6タイプで考える", 11)}`,
        "0 0 340 220",
        "ホランドの6角形(RIASEC)の図"
      ),
      "隣り合うタイプほど近い(一貫性)。人と環境の一致を見る",
      "ホランド(J. L. Holland)のRIASEC 6角形モデルを基に当サイト作成(イメージ図)"
    ),

  levinson: () =>
    figure(
      svgWrap(
        `${BOX(10, 60, 74, 50, "#e8f0f1")}${T(47, 82, "🌸 春", 12)}${T(47, 100, "児童期・青年期", 9)}
        ${BOX(94, 60, 74, 50, "#fbf6d8")}${T(131, 82, "☀️ 夏", 12)}${T(131, 100, "成人前期", 9.5)}
        ${BOX(178, 60, 74, 50, "#f5e3d3")}${T(215, 82, "🍁 秋", 12)}${T(215, 100, "中年期", 9.5)}
        ${BOX(262, 60, 68, 50, "#eef2f5")}${T(296, 82, "☃️ 冬", 12)}${T(296, 100, "老年期", 9.5)}
        ${T(170, 35, "人生は四季のように移りかわる", 12, "middle", "#3f4652", true)}
        ${T(170, 140, "季節の変わり目 = 過渡期(トランジション)", 11.5)}
        ${T(170, 160, "特に約40〜45歳の「人生半ばの過渡期」が重要", 10.5)}`,
        "0 0 340 180",
        "レビンソンの人生の四季の図"
      ),
      "安定期と過渡期が交互にやってくる「人生の四季」",
      "レビンソン(D. J. Levinson)のライフサイクル論を基に当サイト作成(イメージ図)"
    ),

  erikson: () =>
    figure(
      svgWrap(
        `${[
          ["乳児期", 8],
          ["幼児前期", 44],
          ["幼児後期", 80],
          ["児童期", 116],
          ["青年期", 152],
          ["成人前期", 188],
          ["成人期", 224],
          ["老年期", 260],
        ]
          .map(
            ([label, x], i) =>
              `${BOX(Number(x), 150 - i * 17, 70, 26, i === 4 ? "#fbf6d8" : "#fffdf8", i === 4 ? "#cdbf3c" : "#9fa9b6")}${T(Number(x) + 35, 167 - i * 17, String(label), 9.5)}`
          )
          .join("")}
        ${T(170, 200, "青年期の課題「アイデンティティの確立」が特に頻出", 10.5, "middle", "#3f4652", true)}`,
        "0 0 340 212",
        "エリクソンの8つの発達段階の階段の図"
      ),
      "生涯を8段階でとらえ、各段階に発達課題がある",
      "エリクソン(E. H. Erikson)の心理社会的発達理論を基に当サイト作成(イメージ図)"
    ),

  /* ---------- 相談過程の6フェーズ(親図解・図解ライブラリ用) ---------- */
  "sodan-katei-map": () =>
    figure(
      svgWrap(
        `${T(280, 22, "キャリアコンサルティングの相談過程", 15, "middle", "#3f4652", true)}
        ${BOX(20, 40, 160, 52, "#fdf9dc", "#ded263")}
        ${T(100, 62, "① 自己理解の支援", 12, "middle", "#3f4652", true)}
        ${T(100, 80, "興味・能力・価値観を知る", 9.5, "middle", "#6f6b63")}
        ${BOX(200, 40, 160, 52, "#fdf9dc", "#ded263")}
        ${T(280, 62, "② 仕事理解の支援", 12, "middle", "#3f4652", true)}
        ${T(280, 80, "職業・労働市場を知る", 9.5, "middle", "#6f6b63")}
        ${BOX(380, 40, 160, 52, "#fdf9dc", "#ded263")}
        ${T(460, 62, "③ 自己啓発の支援", 12, "middle", "#3f4652", true)}
        ${T(460, 80, "体験して確かめる", 9.5, "middle", "#6f6b63")}
        ${ARROW(180, 66, 196, 66)}
        ${ARROW(360, 66, 376, 66)}
        <path d="M 460 92 C 460 112 100 100 100 122" fill="none" stroke="#8a7a20" stroke-width="2" marker-end="url(#arw)"/>
        ${BOX(20, 126, 160, 52, "#fef4ec", "#ecc9ae")}
        ${T(100, 148, "④ 意思決定の支援", 12, "middle", "#3f4652", true)}
        ${T(100, 166, "目標と計画を決める", 9.5, "middle", "#6f6b63")}
        ${BOX(200, 126, 160, 52, "#fef4ec", "#ecc9ae")}
        ${T(280, 148, "⑤ 方策の実行の支援", 12, "middle", "#3f4652", true)}
        ${T(280, 166, "応募・訓練など行動する", 9.5, "middle", "#6f6b63")}
        ${BOX(380, 126, 160, 52, "#fef4ec", "#ecc9ae")}
        ${T(460, 148, "⑥ 適応の支援", 12, "middle", "#3f4652", true)}
        ${T(460, 166, "新しい仕事に定着する", 9.5, "middle", "#6f6b63")}
        ${ARROW(180, 152, 196, 152)}
        ${ARROW(360, 152, 376, 152)}
        ${BOX(20, 192, 520, 34, "#f2f4f0", "#b6c0cc")}
        ${T(280, 213, "土台: カウンセリング技能(関係構築・傾聴・場面設定) — すべてのフェーズを支える", 11, "middle", "#3f4652", true)}`,
        "0 0 560 240",
        "相談過程の6フェーズと土台のカウンセリング技能"
      ),
      "相談過程の全体地図 — ①〜⑥のどの場面の話かを意識すると、技法が整理できる",
      "キャリアコンサルティングの体系的な支援過程を基に当サイト作成(イメージ図)"
    ),

  /* ---------- ロジャーズ: 自己概念と経験の一致・不一致 ---------- */
  "jiko-icchi": () =>
    figure(
      svgWrap(
        `${T(90, 22, "不一致(なやみが大きい)", 12, "middle", "#3f4652", true)}
        <circle cx="60" cy="95" r="44" fill="#fdf9dc" stroke="#ded263" stroke-width="2" opacity="0.9"/>
        <circle cx="122" cy="95" r="44" fill="#e8f0f4" stroke="#9fb6c4" stroke-width="2" opacity="0.85"/>
        ${T(46, 92, "自己概念", 10.5, "middle", "#8a7a20", true)}
        ${T(46, 106, "(こう思いたい)", 8.5, "middle", "#8a7a20")}
        ${T(136, 92, "経験", 10.5, "middle", "#4a6b7d", true)}
        ${T(136, 106, "(実際の体験)", 8.5, "middle", "#4a6b7d")}
        ${T(90, 168, "重なりが小さい=苦しい", 10.5, "middle", "#c23b2a", true)}
        ${T(250, 22, "一致(こころが健康)", 12, "middle", "#3f4652", true)}
        <circle cx="232" cy="95" r="44" fill="#fdf9dc" stroke="#ded263" stroke-width="2" opacity="0.9"/>
        <circle cx="266" cy="95" r="44" fill="#e8f0f4" stroke="#9fb6c4" stroke-width="2" opacity="0.7"/>
        ${T(249, 92, "自己概念", 10.5, "middle", "#8a7a20", true)}
        ${T(249, 106, "≒ 経験", 10.5, "middle", "#4a6b7d", true)}
        ${T(250, 168, "重なりが大きい=自己一致", 10.5, "middle", "#3f4652", true)}
        ${T(170, 196, "カウンセリングは、この重なりを広げるお手伝い(ロジャーズ)", 10, "middle", "#6f6b63")}`,
        "0 0 340 210",
        "自己概念と経験の一致・不一致の図"
      ),
      "自己概念と経験のズレが大きいほど不適応に。重なりを広げるのが援助の方向",
      "ロジャーズ(C. R. Rogers)の自己理論を基に当サイト作成(イメージ図)"
    ),

  /* ---------- フロイト: 心の氷山(意識・前意識・無意識) ---------- */
  "seishin-bunseki": () =>
    figure(
      svgWrap(
        `<rect x="0" y="78" width="340" height="132" fill="#dce9f0"/>
        <path d="M 170 18 L 235 78 L 250 130 L 200 190 L 130 185 L 95 120 L 110 78 Z" fill="#f6fbfd" stroke="#9fb6c4" stroke-width="2"/>
        <line x1="0" y1="78" x2="340" y2="78" stroke="#4a6b7d" stroke-width="2" stroke-dasharray="6 4"/>
        ${T(38, 45, "意識", 12, "middle", "#3f4652", true)}
        ${T(38, 60, "気づいている", 9, "middle", "#6f6b63")}
        ${T(38, 100, "前意識", 11, "middle", "#3f4652", true)}
        ${T(38, 114, "思い出せる", 9, "middle", "#6f6b63")}
        ${T(38, 150, "無意識", 12, "middle", "#c23b2a", true)}
        ${T(38, 164, "気づけない・大部分", 9, "middle", "#6f6b63")}
        ${T(172, 52, "超自我", 11, "middle", "#3f4652", true)}
        ${T(172, 64, "(こうすべき)", 8.5, "middle", "#6f6b63")}
        ${T(172, 108, "自我", 11, "middle", "#3f4652", true)}
        ${T(172, 120, "(調整役)", 8.5, "middle", "#6f6b63")}
        ${T(172, 158, "エス(イド)", 11, "middle", "#3f4652", true)}
        ${T(172, 170, "(〜したい)", 8.5, "middle", "#6f6b63")}
        ${T(285, 196, "水面下が無意識", 9.5, "middle", "#4a6b7d")}`,
        "0 0 340 210",
        "フロイトの心の構造(氷山のイメージ)"
      ),
      "心は氷山。見えている意識はほんの一部で、水面下の無意識が行動に影響する",
      "フロイト(S. Freud)の局所論・構造論を基に当サイト作成(イメージ図)"
    ),

  /* ---------- 防衛機制マップ ---------- */
  "boei-kisei": () =>
    figure(
      svgWrap(
        `${T(170, 20, "代表的な防衛機制と例", 13, "middle", "#3f4652", true)}
        ${BOX(15, 32, 100, 48, "#fffdf8")}
        ${T(65, 50, "抑圧", 11, "middle", "#3f4652", true)}
        ${T(65, 66, "つらい記憶にフタ", 8.5, "middle", "#6f6b63")}
        ${BOX(120, 32, 100, 48, "#fffdf8")}
        ${T(170, 50, "合理化", 11, "middle", "#3f4652", true)}
        ${T(170, 66, "すっぱいブドウ", 8.5, "middle", "#6f6b63")}
        ${BOX(225, 32, 100, 48, "#fffdf8")}
        ${T(275, 50, "投影", 11, "middle", "#3f4652", true)}
        ${T(275, 66, "自分の感情を相手に", 8.5, "middle", "#6f6b63")}
        ${BOX(15, 88, 100, 48, "#fffdf8")}
        ${T(65, 106, "同一視", 11, "middle", "#3f4652", true)}
        ${T(65, 122, "憧れの人に重ねる", 8.5, "middle", "#6f6b63")}
        ${BOX(120, 88, 100, 48, "#fffdf8")}
        ${T(170, 106, "退行", 11, "middle", "#3f4652", true)}
        ${T(170, 122, "赤ちゃんがえり", 8.5, "middle", "#6f6b63")}
        ${BOX(225, 88, 100, 48, "#fdf9dc", "#ded263")}
        ${T(275, 106, "昇華", 11, "middle", "#8a7a20", true)}
        ${T(275, 122, "スポーツや創作で発散", 8.5, "middle", "#6f6b63")}
        ${T(170, 160, "どれも「不安から自我を守る」心の自動ガード(フロイト)", 10.5, "middle", "#3f4652")}
        ${T(170, 182, "昇華は社会的に認められる形 — 試験でよく出るよ", 10, "middle", "#c23b2a", true)}`,
        "0 0 340 200",
        "代表的な防衛機制のマップ"
      ),
      "防衛機制=不安から自我を守る自動ガード。名前と例のマッチングが試験頻出",
      "精神分析(S. フロイト、A. フロイト)の防衛機制論を基に当サイト作成(イメージ図)"
    ),

  /* ---------- アサーション3タイプ ---------- */
  assertion: () =>
    figure(
      svgWrap(
        `${BOX(15, 30, 100, 110, "#fef0ec", "#e0a898")}
        ${T(65, 52, "攻撃的", 12, "middle", "#3f4652", true)}
        ${T(65, 76, "自分 ◎", 11, "middle", "#3f4652")}
        ${T(65, 94, "相手 ×", 11, "middle", "#c23b2a")}
        ${T(65, 122, "言い負かす", 9, "middle", "#6f6b63")}
        ${BOX(120, 30, 100, 110, "#eef1f4", "#b6c0cc")}
        ${T(170, 52, "非主張的", 12, "middle", "#3f4652", true)}
        ${T(170, 76, "自分 ×", 11, "middle", "#c23b2a")}
        ${T(170, 94, "相手 ◎", 11, "middle", "#3f4652")}
        ${T(170, 122, "がまんする", 9, "middle", "#6f6b63")}
        ${BOX(225, 30, 100, 110, "#fdf9dc", "#ded263")}
        ${T(275, 52, "アサーティブ", 12, "middle", "#8a7a20", true)}
        ${T(275, 76, "自分 ◎", 11, "middle", "#3f4652")}
        ${T(275, 94, "相手 ◎", 11, "middle", "#3f4652")}
        ${T(275, 122, "率直+尊重", 9, "middle", "#6f6b63")}
        ${T(170, 168, "アサーション=自分も相手も大切にする自己表現", 11, "middle", "#3f4652", true)}
        ${T(170, 188, "「必ず意見を通す技術」ではない点に注意", 9.5, "middle", "#c23b2a")}`,
        "0 0 340 200",
        "3つの自己表現タイプの比較図"
      ),
      "アサーション=「自分も◎、相手も◎」の伝え方。3タイプの分類問題が定番",
      "アサーション・トレーニング(ウォルピらの主張訓練を起源)の考え方を基に当サイト作成"
    ),

  /* ---------- ベックの認知療法 ---------- */
  "ninchi-ryoho": () =>
    figure(
      svgWrap(
        `${BOX(15, 60, 88, 54, "#fffdf8")}
        ${T(59, 82, "出来事", 12, "middle", "#3f4652", true)}
        ${T(59, 100, "あいさつを返して", 8.5, "middle", "#6f6b63")}
        ${T(59, 110, "もらえなかった", 8.5, "middle", "#6f6b63")}
        ${ARROW(103, 87, 122, 87)}
        ${BOX(126, 48, 96, 78, "#fdf9dc", "#ded263")}
        ${T(174, 68, "自動思考", 12, "middle", "#8a7a20", true)}
        ${T(174, 86, "「嫌われた!」", 10, "middle", "#c23b2a", true)}
        ${T(174, 104, "瞬間的に浮かぶ", 8.5, "middle", "#6f6b63")}
        ${T(174, 116, "考えのクセ", 8.5, "middle", "#6f6b63")}
        ${ARROW(222, 87, 241, 87)}
        ${BOX(245, 60, 80, 54, "#fef0ec", "#e0a898")}
        ${T(285, 84, "気持ち", 12, "middle", "#3f4652", true)}
        ${T(285, 102, "落ちこむ", 9.5, "middle", "#6f6b63")}
        ${T(170, 152, "出来事そのものではなく「自動思考」が気持ちをつくる", 10.5, "middle", "#3f4652", true)}
        ${T(170, 172, "自動思考に気づき、現実的な考えに整えるのが認知療法(ベック)", 9.5, "middle", "#6f6b63")}
        ${T(170, 192, "エリス(論理療法)との人名入れ替えに注意!", 9.5, "middle", "#c23b2a", true)}`,
        "0 0 340 205",
        "認知療法のしくみ(出来事→自動思考→気持ち)"
      ),
      "気持ちをつくるのは出来事ではなく「自動思考」。ベックの認知療法の基本図",
      "ベック(A. T. Beck)の認知療法の考え方を基に当サイト作成(イメージ図)"
    ),

  /* ---------- 行動療法・系統的脱感作 ---------- */
  "kodo-ryoho": () =>
    figure(
      svgWrap(
        `${T(170, 20, "系統的脱感作: 不安の階段を1段ずつ", 12.5, "middle", "#3f4652", true)}
        ${BOX(20, 150, 70, 30, "#fdf9dc", "#ded263")}
        ${T(55, 169, "電話で話す", 9, "middle")}
        ${BOX(95, 120, 70, 30, "#fdf9dc", "#ded263")}
        ${T(130, 139, "1対1で話す", 9, "middle")}
        ${BOX(170, 90, 70, 30, "#fdf9dc", "#ded263")}
        ${T(205, 109, "会議で発言", 9, "middle")}
        ${BOX(245, 60, 70, 30, "#fdf9dc", "#ded263")}
        ${T(280, 79, "大勢の前で発表", 8.5, "middle")}
        ${ARROW(90, 158, 105, 145)}
        ${ARROW(165, 128, 180, 115)}
        ${ARROW(240, 98, 255, 85)}
        ${T(55, 196, "弱い不安", 9.5, "middle", "#6f6b63")}
        ${T(280, 48, "強い不安", 9.5, "middle", "#6f6b63")}
        ${T(170, 196, "各段でリラックス法とセット→不安を少しずつ消していく(ウォルピ)", 9.5, "middle", "#3f4652")}`,
        "0 0 340 205",
        "系統的脱感作の階段図"
      ),
      "リラックスと組み合わせ、弱い不安から段階的に慣らす(学習理論に基づく行動療法)",
      "ウォルピ(J. Wolpe)の系統的脱感作の考え方を基に当サイト作成(イメージ図)"
    ),

  /* ---------- 交流分析: 5つの自我状態 ---------- */
  "koryu-bunseki": () =>
    figure(
      svgWrap(
        `${T(170, 20, "5つの自我状態(エゴグラムのもと)", 12.5, "middle", "#3f4652", true)}
        ${BOX(15, 34, 140, 64, "#fef0ec", "#e0a898")}
        ${T(85, 52, "P: 親の心", 11, "middle", "#3f4652", true)}
        ${T(85, 70, "CP きびしい親(〜すべき)", 9, "middle", "#6f6b63")}
        ${T(85, 86, "NP やさしい親(大丈夫?)", 9, "middle", "#6f6b63")}
        ${BOX(185, 34, 140, 40, "#eef1f4", "#b6c0cc")}
        ${T(255, 52, "A: 大人の心", 11, "middle", "#3f4652", true)}
        ${T(255, 66, "冷静・事実で判断", 9, "middle", "#6f6b63")}
        ${BOX(185, 82, 140, 64, "#fdf9dc", "#ded263")}
        ${T(255, 100, "C: 子どもの心", 11, "middle", "#3f4652", true)}
        ${T(255, 118, "FC 自由な子(わーい!)", 9, "middle", "#6f6b63")}
        ${T(255, 134, "AC 順応する子(いい子に)", 9, "middle", "#6f6b63")}
        ${T(170, 172, "バーンの交流分析(TA)。やりとり(ストローク)や人生脚本も分析する", 9.5, "middle", "#3f4652")}
        ${T(170, 192, "エゴグラム(デュセイ)はこの5つの強さをグラフにした検査", 9.5, "middle", "#c23b2a")}`,
        "0 0 340 205",
        "交流分析の5つの自我状態(CP・NP・A・FC・AC)"
      ),
      "人の心の中には「親・大人・子ども」の5つの状態がある(バーンの交流分析)",
      "バーン(E. Berne)の交流分析を基に当サイト作成(イメージ図)"
    ),

  /* ---------- ジェラット: 連続的意思決定プロセス ---------- */
  "renzokuteki-ishikettei": () =>
    figure(
      svgWrap(
        `${BOX(15, 55, 92, 62, "#fdf9dc", "#ded263")}
        ${T(61, 76, "予測システム", 10.5, "middle", "#3f4652", true)}
        ${T(61, 94, "どうなりそう?", 9, "middle", "#6f6b63")}
        ${T(61, 106, "結果を予想", 9, "middle", "#6f6b63")}
        ${ARROW(107, 86, 126, 86)}
        ${BOX(130, 55, 92, 62, "#fdf9dc", "#ded263")}
        ${T(176, 76, "価値システム", 10.5, "middle", "#3f4652", true)}
        ${T(176, 94, "どれが大事?", 9, "middle", "#6f6b63")}
        ${T(176, 106, "望ましさを評価", 9, "middle", "#6f6b63")}
        ${ARROW(222, 86, 241, 86)}
        ${BOX(245, 55, 82, 62, "#fef4ec", "#ecc9ae")}
        ${T(286, 76, "決定システム", 10.5, "middle", "#3f4652", true)}
        ${T(286, 94, "基準に照らして", 9, "middle", "#6f6b63")}
        ${T(286, 106, "選ぶ", 9, "middle", "#6f6b63")}
        <path d="M 286 117 C 286 160 61 160 61 121" fill="none" stroke="#8a7a20" stroke-width="2" stroke-dasharray="5 4" marker-end="url(#arw)"/>
        ${T(170, 150, "探索的決定をくり返して → 最終的決定へ", 10.5, "middle", "#3f4652", true)}
        ${T(170, 186, "後年は「肯定的不確実性」へ発展(前期・後期の対比が試験に出るよ)", 9.5, "middle", "#c23b2a")}`,
        "0 0 340 205",
        "ジェラットの連続的意思決定プロセス"
      ),
      "予測→価値→決定の3システムをくり返しながら、少しずつ決めていく",
      "ジェラット(H. B. Gelatt)の意思決定モデルを基に当サイト作成(イメージ図)"
    ),

  /* ---------- ブリッジス: トランジション3段階 ---------- */
  "transition-riron": () =>
    figure(
      svgWrap(
        `${BOX(15, 60, 92, 66, "#eef1f4", "#b6c0cc")}
        ${T(61, 82, "終焉", 13, "middle", "#3f4652", true)}
        ${T(61, 100, "なにかが終わる", 9, "middle", "#6f6b63")}
        ${T(61, 114, "手放す・お別れ", 9, "middle", "#6f6b63")}
        ${ARROW(107, 92, 126, 92)}
        ${BOX(130, 60, 92, 66, "#fef4ec", "#ecc9ae")}
        ${T(176, 82, "中立圏", 13, "middle", "#3f4652", true)}
        ${T(176, 100, "どっちつかずの", 9, "middle", "#6f6b63")}
        ${T(176, 114, "モヤモヤ期間", 9, "middle", "#6f6b63")}
        ${ARROW(222, 92, 241, 92)}
        ${BOX(245, 60, 82, 66, "#fdf9dc", "#ded263")}
        ${T(286, 82, "開始", 13, "middle", "#8a7a20", true)}
        ${T(286, 100, "新しいことが", 9, "middle", "#6f6b63")}
        ${T(286, 114, "始まる", 9, "middle", "#6f6b63")}
        ${T(170, 40, "転機は「終わり」から始まる(ブリッジス)", 12, "middle", "#3f4652", true)}
        ${T(170, 156, "順番の入れ替えひっかけに注意! 終焉→中立圏→開始", 10, "middle", "#c23b2a", true)}
        ${T(170, 178, "モヤモヤの中立圏は、次の一歩を育てる大切な時間", 9.5, "middle", "#6f6b63")}`,
        "0 0 340 195",
        "ブリッジスのトランジション3段階"
      ),
      "終焉 → 中立圏(ニュートラルゾーン) → 開始。転機は「終わり」から始まる",
      "ブリッジス(W. Bridges)のトランジション理論を基に当サイト作成(イメージ図)"
    ),

};

/** slug に対応する図解(なければ空文字) */
export function TermDiagram(slug: string): string {
  const d = DIAGRAMS[slug];
  return d ? d() : "";
}

/* ---------- 理論家の似顔絵(オリジナルイラスト) ---------- */

type AvatarStyle = {
  /** 髪型: bald=つるり+サイド / side=横分け / short=短髪 / wave=ふんわり /
   *  swept=後ろに流す(エリクソン風) / center=真ん中分け(19世紀風) */
  hair: "short" | "side" | "bald" | "wave" | "swept" | "center";
  hairColor: string;
  glasses?: boolean;
  /** メガネの形: round=丸 / rect=四角 */
  glassShape?: "round" | "rect";
  beard?: boolean;
  mustache?: boolean;
  /** 女性らしい要素(イヤリング・ネックレス) */
  feminine?: boolean;
  /** 服装: suit=スーツ+ネクタイ / bow=蝶ネクタイ(クラシック) / plain=ふつう */
  outfit?: "suit" | "bow" | "plain";
};

/**
 * 実在の理論家の一般によく知られた特徴(髪型・メガネ・ヒゲなど)を反映した
 * 当サイト作成のイラスト。特定の写真の模写ではない。
 */
const AVATARS: Record<string, AvatarStyle> = {
  // スーパー: 横分けの白髪・メガネ・スーツの紳士
  super: { hair: "side", hairColor: "#d9d2c8", glasses: true, glassShape: "rect", outfit: "suit" },
  // ロジャーズ: 頭頂部がつるりとした白髪・大きめの丸メガネ・穏やかな笑顔
  rogers: { hair: "bald", hairColor: "#e0dcd2", glasses: true, glassShape: "round", outfit: "plain" },
  // クランボルツ: 白髪・白いあごひげ・メガネ・にこやか
  krumboltz: { hair: "short", hairColor: "#e3ded6", glasses: true, glassShape: "rect", beard: true, outfit: "plain" },
  // シャイン: 白髪サイド・メガネ・長寿の研究者らしい柔和さ
  schein: { hair: "bald", hairColor: "#ddd7cd", glasses: true, glassShape: "rect", outfit: "suit" },
  // バンデューラ: 高い額・白髪サイド・メガネなしの写真が有名
  bandura: { hair: "bald", hairColor: "#d5cfc5", outfit: "suit" },
  // ホランド: 横分けのグレーヘア・メガネ
  holland: { hair: "side", hairColor: "#c2bab0", glasses: true, glassShape: "rect", outfit: "plain" },
  // シュロスバーグ: 明るいショートヘアの女性・イヤリング・華やかな笑顔
  schlossberg: { hair: "wave", hairColor: "#e2cfa4", glasses: true, glassShape: "round", feminine: true, outfit: "plain" },
  // サビカス: つるりとした頭・口ひげ・メガネが特徴
  savickas: { hair: "bald", hairColor: "#c9c2b8", glasses: true, glassShape: "rect", mustache: true, outfit: "suit" },
  // ジェラット: グレーの横分け・にこやか
  gelatt: { hair: "side", hairColor: "#cfc8bd", glasses: true, glassShape: "round", outfit: "plain" },
  // パーソンズ: 19世紀の人。真ん中寄りの分け目・立派な口ひげ・クラシックな装い
  parsons: { hair: "center", hairColor: "#5d564c", mustache: true, outfit: "bow" },
  // ホール: グレーの短髪・四角メガネ・スーツの経営学者
  hall: { hair: "short", hairColor: "#b8b0a4", glasses: true, glassShape: "rect", outfit: "suit" },
  // ブリッジス: 白髪のふんわりヘア・あごひげ・穏やかな笑顔
  bridges: { hair: "wave", hairColor: "#ddd7cd", beard: true, outfit: "plain" },
  // アイビイ: 白髪サイド・丸メガネ・教育者らしい柔らかさ
  ivey: { hair: "side", hairColor: "#d9d2c8", glasses: true, glassShape: "round", outfit: "plain" },
  // 國分康孝: 黒髪まじりのグレー横分け・四角メガネ・スーツの日本の先生
  kokubu: { hair: "side", hairColor: "#6b6258", glasses: true, glassShape: "rect", outfit: "suit" },
  // エリス: 頭頂部つるり・大きな黒ぶちメガネがトレードマーク
  ellis: { hair: "bald", hairColor: "#c9c2b8", glasses: true, glassShape: "rect", outfit: "suit" },
  // ハンセン: ふんわりショートの女性・丸メガネ・イヤリング
  hansen: { hair: "wave", hairColor: "#d8c49e", glasses: true, glassShape: "round", feminine: true, outfit: "plain" },
  // エリクソン: 後ろに流した白髪と白い口ひげが象徴的
  erikson: { hair: "swept", hairColor: "#eceae4", mustache: true, outfit: "plain" },
  // レビンソン: 短めのグレーヘア・メガネ
  levinson: { hair: "short", hairColor: "#b8b0a4", glasses: true, glassShape: "rect", outfit: "suit" },
};

/** 理論家の似顔絵イラスト(写真は著作権のため使用せず、特徴を基に当サイト作成) */
export function TheoristAvatar(slug: string, size = 110): string {
  const s: AvatarStyle = AVATARS[slug] ?? { hair: "short", hairColor: "#c0b8aa" };
  const hc = s.hairColor;
  const hs = "#8d8578"; // 髪の線色

  const hair =
    s.hair === "bald"
      ? // つるりとした頭頂+両サイドの髪
        `<path d="M28 62 q-2 -12 8 -14 l2 12 Z" fill="${hc}" stroke="${hs}" stroke-width="1.5"/>
         <path d="M92 62 q2 -12 -8 -14 l-2 12 Z" fill="${hc}" stroke="${hs}" stroke-width="1.5"/>
         <path d="M36 42 q24 -18 48 0" fill="none" stroke="${hc}" stroke-width="4" stroke-linecap="round" opacity="0.55"/>`
      : s.hair === "side"
        ? `<path d="M30 56 q0 -30 30 -30 q30 0 30 30 l-7 2 q-1 -18 -18 -21 q-16 4 -28 21 Z" fill="${hc}" stroke="${hs}" stroke-width="1.5"/>`
        : s.hair === "wave"
          ? `<path d="M28 60 q-4 -36 32 -38 q36 2 32 38 q-7 -12 -13 -9 q-5 -14 -19 -13 q-14 -1 -19 13 q-6 -3 -13 9 Z" fill="${hc}" stroke="${hs}" stroke-width="1.5"/>`
          : s.hair === "swept"
            ? // 後ろに流す白髪(ボリュームあり)
              `<path d="M26 58 q-6 -34 34 -36 q40 2 34 36 q-4 -10 -10 -12 q4 -10 -6 -14 q-2 8 -8 6 q0 -8 -10 -8 q-10 0 -10 8 q-6 2 -8 -6 q-10 4 -6 14 q-6 2 -10 12 Z" fill="${hc}" stroke="${hs}" stroke-width="1.5"/>`
            : s.hair === "center"
              ? // 真ん中分け(クラシック)
                `<path d="M32 52 q2 -26 28 -26 q26 0 28 26 l-6 2 q-2 -18 -22 -20 l0 6 l0 -6 q-20 2 -22 20 Z" fill="${hc}" stroke="${hs}" stroke-width="1.5"/>
                 <path d="M60 26 v10" stroke="${hs}" stroke-width="1.2"/>`
              : `<path d="M34 50 q2 -28 26 -28 q24 0 26 28 q-12 -14 -26 -14 q-14 0 -26 14 Z" fill="${hc}" stroke="${hs}" stroke-width="1.5"/>`;

  const glasses = s.glasses
    ? s.glassShape === "rect"
      ? `<g fill="none" stroke="#6f675a" stroke-width="2"><rect x="40" y="55" width="17" height="13" rx="4"/><rect x="63" y="55" width="17" height="13" rx="4"/><path d="M57 61 h6"/></g>`
      : `<g fill="none" stroke="#6f675a" stroke-width="2"><circle cx="49" cy="62" r="8"/><circle cx="71" cy="62" r="8"/><path d="M57 62 h6"/></g>`
    : "";

  const mustache = s.mustache
    ? `<path d="M48 77 q6 -5 12 -1 q6 -4 12 1 q-6 6 -12 4 q-6 2 -12 -4 Z" fill="${hc}" stroke="${hs}" stroke-width="1.2"/>`
    : "";

  const beard = s.beard
    ? `<path d="M44 82 q16 14 32 0 q-2 14 -16 14 q-14 0 -16 -14 Z" fill="${hc}" stroke="${hs}" stroke-width="1.2"/>`
    : "";

  const feminine = s.feminine
    ? `<circle cx="30" cy="72" r="3" fill="#d8a24a"/>
       <circle cx="90" cy="72" r="3" fill="#d8a24a"/>`
    : "";

  const outfit =
    s.outfit === "suit"
      ? `<path d="M28 108 q6 -14 20 -16 l12 10 l12 -10 q14 2 20 16 Z" fill="#7a838f" stroke="#5d6570" stroke-width="1.5"/>
         <path d="M56 100 l4 -0 l4 0 l-4 10 Z" fill="#a8514a"/>`
      : s.outfit === "bow"
        ? `<path d="M28 108 q6 -14 20 -16 l12 10 l12 -10 q14 2 20 16 Z" fill="#4f4a42" stroke="#3a362f" stroke-width="1.5"/>
           <path d="M52 98 l8 4 l8 -4 l-3 6 l3 6 l-8 -4 l-8 4 l3 -6 Z" fill="#7d3f36"/>`
        : `<path d="M28 108 q6 -14 20 -16 l12 10 l12 -10 q14 2 20 16 Z" fill="#9aab9f" stroke="#7c8d81" stroke-width="1.5"/>`;

  const mouth = s.mustache
    ? ""
    : `<path d="M53 80 q7 6 14 0" fill="none" stroke="#4a505c" stroke-width="2.4" stroke-linecap="round"/>`;

  return `<svg class="theorist-avatar" width="${size}" height="${size}" viewBox="0 0 120 120" role="img" aria-label="理論家の似顔絵イラスト(特徴を基に当サイト作成)">
    <circle cx="60" cy="60" r="54" fill="#eef2f5" stroke="#c8d2da" stroke-width="2"/>
    <clipPath id="av-${esc(slug)}"><circle cx="60" cy="60" r="54"/></clipPath>
    <g clip-path="url(#av-${esc(slug)})">
      ${outfit}
      <circle cx="60" cy="64" r="34" fill="#f7e8d8" stroke="#c9b8a2" stroke-width="2"/>
      ${hair}
      <circle cx="49" cy="62" r="3" fill="#4a505c"/>
      <circle cx="71" cy="62" r="3" fill="#4a505c"/>
      ${glasses}
      <circle cx="41" cy="73" r="4.5" fill="#f6c1b8" opacity="0.7"/>
      <circle cx="79" cy="73" r="4.5" fill="#f6c1b8" opacity="0.7"/>
      ${mouth}
      ${mustache}
      ${beard}
      ${feminine}
    </g>
  </svg>`;
}
