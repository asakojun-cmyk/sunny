import { esc, join, jsonLd } from "../lib/html";
import { SITE, NAV_ITEMS, BOTTOM_NAV } from "../lib/site";
import type { Crumb } from "../lib/types";
import { Breadcrumbs, breadcrumbJsonLd } from "./Breadcrumbs";
import { SunnySvg } from "./Characters";

export type PageOptions = {
  /** ページの h1 相当タイトル(<title> には サイト名が付く) */
  title: string;
  description: string;
  /** ルートからのパス。例: "/terms/jiko-gainen/" */
  path: string;
  body: string;
  crumbs?: Crumb[];
  /** 追加の JSON-LD オブジェクト */
  structuredData?: object[];
  activeNav?: string;
  /** トップページなど、タイトルをそのまま使う場合 true */
  isHome?: boolean;
  /** 404ページ: どの階層で表示されてもリンク・CSSが壊れないよう <base> を挿入 */
  useAbsoluteBase?: boolean;
  ogType?: "website" | "article";
};

function header(): string {
  return `
<header class="site-header">
  <div class="site-header__inner">
    <div class="site-header__brand">
      <a href="/" class="site-logo">
        <span class="site-logo__ja"><span aria-hidden="true">⛅</span>${esc(SITE.name)}</span>
        <span class="site-logo__en">${esc(SITE.nameEn)}</span>
      </a>
      <p class="site-header__tagline">${esc(SITE.concept)}</p>
    </div>
    <div class="header-search" id="search-fab">
      <a class="search-fab__toggle" href="/search/" aria-expanded="false" aria-controls="search-fab-panel">
        <span class="header-search__label" aria-hidden="true">＼ 用語検索 ／</span>
        <span class="header-search__chara">${SunnySvg(42)}</span>
        <span class="header-search__click" aria-hidden="true">⇑クリック⇑</span>
        <span class="visually-hidden">わからない言葉を検索する</span>
      </a>
      <div class="search-fab__panel" id="search-fab-panel" hidden>
        <p class="search-fab__lead">わからない言葉をここに書いてね</p>
        <form class="search-fab__form" action="/search/" method="get" role="search">
          <label class="visually-hidden" for="search-fab-input">わからない言葉を検索</label>
          <input type="search" id="search-fab-input" name="q" placeholder="例:自己概念、ラポール" autocomplete="off">
          <button type="submit" class="button button--primary">検索</button>
        </form>
        <button type="button" class="search-fab__close" aria-label="検索ボックスをとじる">×</button>
      </div>
    </div>
  </div>
</header>`;
}

function footer(activeNav?: string): string {
  const items = NAV_ITEMS.map(
    (item) =>
      `<li><a href="${item.href}"${
        activeNav === item.href ? ' aria-current="page"' : ""
      }>${esc(item.label)}</a></li>`
  ).join("");
  return `
<footer class="site-footer" id="sitemap">
  <div class="site-footer__inner">
    <div class="site-footer__brand">
      <p class="site-logo__ja"><span aria-hidden="true">⛅</span>${esc(SITE.name)}</p>
      <p class="site-logo__en">${esc(SITE.nameEn)}</p>
      <p class="site-footer__desc">${esc(SITE.tagline)}</p>
    </div>
    <nav class="site-footer__sitemap" aria-label="サイト全体のメニュー">
      <p class="drawer__label">MENU</p>
      <ul class="drawer__list drawer__list--main">
        <li><a href="/">ホーム</a></li>
        ${items}
        <li><a href="/search/">サイト内検索</a></li>
      </ul>
      <p class="drawer__label">ALL PAGES</p>
      <ul class="drawer__list">
        <li><a href="/terms/">キャリコンことば図鑑(用語一覧)</a></li>
        <li><a href="/theorists/">理論家図鑑</a></li>
        <li><a href="/laws/">労働法・統計・制度</a></li>
        <li><a href="/exam/">学科・論述・面接(過去問リンク)</a></li>
        <li><a href="/start/">はじめての学習ルート</a></li>
        <li><a href="/shikaku-guide/">資格まるわかりガイド(検討中の方へ)</a></li>
        <li><a href="/schools/">養成学校一覧</a></li>
        <li><a href="/schools/compare/">養成学校を比較する</a></li>
        <li><a href="/school-guides/how-to-choose/">養成学校の選び方</a></li>
        <li><a href="/school-guides/online/">オンライン講座の選び方</a></li>
        <li><a href="/school-guides/working-mothers/">子育て中の学校選び</a></li>
        <li><a href="/school-guides/training-and-exam-preparation/">養成講習と試験対策講座の違い</a></li>
        <li><a href="/school-reviews/chiiki-renkei-platform/">運営者の受講記録</a></li>
        <li><a href="/diagrams/">図解ライブラリ(フローチャート)</a></li>
        <li><a href="/games/">3分ミニゲーム</a></li>
        <li><a href="/omamori/">お守りページ(カウントダウン&待ち受け)</a></li>
        <li><a href="/column/">もやもやモヤンの中の人コラム</a></li>
        <li><a href="/careers/">資格取得後の働き方</a></li>
        <li><a href="/about/">このサイトについて</a></li>
      </ul>
    </nav>
    <div class="site-footer__note">
      <p>掲載している学校の料金・日程・給付金などの情報は変更される可能性があります。申込み前に必ず各校の公式サイトで最新情報をご確認ください。</p>
      <p>法律・統計・試験制度に関する記述は、一次資料で確認できた範囲で掲載しています。</p>
    </div>
    <p class="site-footer__copy">&copy; 2026 ${esc(SITE.name)} <span class="site-footer__version">${esc(SITE.version)}</span></p>
  </div>
</footer>`;
}

function bottomNavigation(path: string): string {
  const items = BOTTOM_NAV.map((item) => {
    const isActive =
      item.href === path ||
      (item.href !== "/" && !item.href.startsWith("#") && path.startsWith(item.href));
    // 「メニュー」はページ最後のサイトマップ(フッター)へ案内する
    const href = item.href === "#menu" ? "#sitemap" : item.href;
    return `<a class="bottom-nav__item${isActive ? " is-active" : ""}" href="${href}">
      <span class="bottom-nav__icon bottom-nav__icon--${item.icon}" aria-hidden="true"></span>
      <span class="bottom-nav__label">${esc(item.label)}</span>
    </a>`;
  }).join("");
  return `<nav class="bottom-nav" aria-label="モバイルナビゲーション">${items}</nav>`;
}

export function renderPage(opts: PageOptions): string {
  const fullTitle = opts.isHome
    ? `${SITE.name}|${SITE.tagline}`
    : `${opts.title}|${SITE.name}`;
  const canonical = `${SITE.baseUrl}${opts.path}`;
  const ld: object[] = [...(opts.structuredData ?? [])];
  if (opts.crumbs && opts.crumbs.length > 0) {
    ld.push(breadcrumbJsonLd(opts.crumbs));
  }

  return `<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
${opts.useAbsoluteBase ? `<base href="${esc(SITE.baseUrl)}/">` : ""}
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(fullTitle)}</title>
<meta name="description" content="${esc(opts.description)}">
<link rel="canonical" href="${esc(canonical)}">
<meta property="og:site_name" content="${esc(SITE.name)}">
<meta property="og:title" content="${esc(fullTitle)}">
<meta property="og:description" content="${esc(opts.description)}">
<meta property="og:type" content="${opts.ogType ?? "website"}">
<meta property="og:url" content="${esc(canonical)}">
<meta property="og:locale" content="ja_JP">
<meta name="twitter:card" content="summary">
<link rel="icon" type="image/png" href="/img/favicon.png">
<link rel="apple-touch-icon" href="/img/sunny-icon.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Zen+Maru+Gothic:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/css/style.css?v=${esc(SITE.version)}">
${ld.map((d) => jsonLd(d)).join("\n")}
</head>
<body>
<a class="skip-link" href="#main">本文へ移動</a>
${header()}
<main id="main" class="site-main">
${opts.crumbs ? Breadcrumbs(opts.crumbs) : ""}
${opts.body}
</main>
${footer(opts.activeNav)}
${bottomNavigation(opts.path)}
<script src="/js/reveal.js?v=${esc(SITE.version)}" defer></script>
<script src="/js/search-fab.js?v=${esc(SITE.version)}" defer></script>
</body>
</html>`;
}

export { join };
