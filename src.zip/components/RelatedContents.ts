import { esc } from "../lib/html";

export type RelatedItem = {
  type: string; // 例: 用語 / 理論家 / ガイド / 学校
  title: string;
  url: string;
  description?: string;
};

/** 関連コンテンツ(記事下部) */
export function RelatedContents(items: RelatedItem[], title = "関連コンテンツ"): string {
  if (items.length === 0) return "";
  return `<section class="related">
    <h2 class="related__title">${esc(title)}</h2>
    <ul class="related__list">
      ${items
        .map(
          (i) => `<li>
        <a href="${esc(i.url)}">
          <span class="related__type">${esc(i.type)}</span>
          <span class="related__item-title">${esc(i.title)}</span>
          ${i.description ? `<span class="related__desc">${esc(i.description)}</span>` : ""}
        </a>
      </li>`
        )
        .join("")}
    </ul>
  </section>`;
}
