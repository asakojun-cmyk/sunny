import { esc } from "../lib/html";
import { SITE } from "../lib/site";
import type { Crumb } from "../lib/types";

export function Breadcrumbs(crumbs: Crumb[]): string {
  const items = crumbs
    .map((c, i) => {
      const isLast = i === crumbs.length - 1;
      if (isLast || !c.url) {
        return `<li aria-current="page">${esc(c.name)}</li>`;
      }
      return `<li><a href="${esc(c.url)}">${esc(c.name)}</a></li>`;
    })
    .join("");
  return `<nav class="breadcrumbs" aria-label="パンくずリスト"><ol>${items}</ol></nav>`;
}

export function breadcrumbJsonLd(crumbs: Crumb[]): object {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: crumbs.map((c, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: c.name,
      ...(c.url ? { item: `${SITE.baseUrl}${c.url}` } : {}),
    })),
  };
}
