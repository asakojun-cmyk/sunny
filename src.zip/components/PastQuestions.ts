import { esc } from "../lib/html";
import { PAST_EXAM_SOURCES } from "../lib/site";

/**
 * 過去問への案内ボックス。
 * 過去問の本文は試験機関に著作権があるため転載せず、
 * 公式の過去問公開ページへのリンクと探し方を示す。
 */
export function PastQuestions(keyword: string): string {
  return `<section class="past-questions">
    <h2 class="term-section-title">🌈 過去問で確認する</h2>
    <p>国家資格キャリアコンサルタント試験の過去問題は、2つの試験機関の公式サイトで公開されています(学科試験は両機関共通)。公式ページの過去問PDFで「<strong>${esc(keyword)}</strong>」が出てくる問題を探して、実際の問われ方を確認してみましょう。</p>
    <ul class="past-questions__links">
      ${PAST_EXAM_SOURCES.map(
        (s) =>
          `<li><a href="${esc(s.url)}" rel="noopener nofollow" target="_blank">${esc(s.label)}</a></li>`
      ).join("")}
    </ul>
    <p class="past-questions__note">※過去問の本文は試験機関に著作権があるため、当サイトには転載していません。このページの○×問題は当サイトのオリジナルです。</p>
  </section>`;
}
