import { esc, formatDate } from "../lib/html";
import type { SourceReference } from "../lib/types";

const SOURCE_TYPE_LABEL: Record<SourceReference["sourceType"], string> = {
  "official-school": "学校公式",
  mhlw: "厚生労働省",
  "exam-organization": "試験機関",
  "other-primary-source": "一次資料",
};

/** 出典一覧 */
export function SourceList(sources: SourceReference[]): string {
  if (sources.length === 0) return "";
  return `<section class="source-list">
    <h2 class="source-list__title">参考・出典</h2>
    <ul>
      ${sources
        .map(
          (s) => `<li>
        <span class="source-list__type">${esc(SOURCE_TYPE_LABEL[s.sourceType])}</span>
        <a href="${esc(s.url)}" rel="noopener nofollow" target="_blank">${esc(s.label)}</a>
        <span class="source-list__checked">(確認日: ${esc(formatDate(s.checkedAt))})</span>
      </li>`
        )
        .join("")}
    </ul>
  </section>`;
}
