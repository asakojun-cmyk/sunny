import { esc } from "../lib/html";

const STEPS = [
  { step: 1, title: "試験の全体像を知る", href: "/start/" },
  { step: 2, title: "よく出る用語を知る", href: "/terms/" },
  { step: 3, title: "理論家同士の違いを知る", href: "/theorists/" },
  { step: 4, title: "1問1答で確認する", href: "/#daily" },
  { step: 5, title: "論述と面接につなげる", href: "/start/#exam-links" },
];

/** はじめての方へ(学習ルート) */
export function LearningPath(): string {
  return `<ol class="learning-path">
    ${STEPS.map(
      (s) => `<li class="learning-path__step">
      <a href="${esc(s.href)}">
        <span class="learning-path__number" aria-hidden="true">${s.step}</span>
        <span class="learning-path__title">${esc(s.title)}</span>
      </a>
    </li>`
    ).join("")}
  </ol>
  <p class="learning-path__cta"><a class="button button--secondary" href="/start/">初学者の学習ルートを見る</a></p>`;
}
