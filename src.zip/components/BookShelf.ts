import { esc } from "../lib/html";
import { AFFILIATE_TAG, AFFILIATE_DISCLOSURE, bookUrl, type Book } from "../data/books";

/**
 * さらに学べる本棚。
 * AFFILIATE_TAG 未設定の間はただの紹介(PR表記なし)。
 * タグ設定後は自動で PR ラベル + 開示文 + rel="sponsored" が付く。
 */

export function BookCard(b: Book): string {
  const rel = AFFILIATE_TAG ? "sponsored nofollow noopener" : "noopener";
  return `<li class="book-card">
    <span class="book-card__icon" aria-hidden="true">📚</span>
    <div class="book-card__body">
      <p class="book-card__meta"><span class="book-card__audience">${esc(b.audience)}</span>${
        AFFILIATE_TAG ? '<span class="book-card__pr">PR</span>' : ""
      }</p>
      <p class="book-card__title">${esc(b.title)}</p>
      <p class="book-card__author">${esc(b.author)}${b.publisher ? `(${esc(b.publisher)})` : ""}</p>
      <p class="book-card__note">☀️ ${esc(b.note)}</p>
      <p class="book-card__link"><a href="${esc(bookUrl(b))}" target="_blank" rel="${rel}">Amazonで見る →</a></p>
    </div>
  </li>`;
}

export function BookShelf(list: Book[], heading = "さらに学べる本棚"): string {
  if (list.length === 0) return "";
  return `<section class="book-shelf">
    <h2 class="term-section-title">${esc(heading)}</h2>
    <ul class="book-shelf__list">
      ${list.map((b) => BookCard(b)).join("")}
    </ul>
    <p class="book-shelf__note">※ 書籍は版が改まることがあります。リンク先で最新の版・発行年をご確認ください。${
      AFFILIATE_TAG ? esc(AFFILIATE_DISCLOSURE) : ""
    }</p>
  </section>`;
}
