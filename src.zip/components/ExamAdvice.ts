import { esc } from "../lib/html";
import { SunnySvg } from "./Characters";
import { CharacterGuide } from "./Characters";

/**
 * サニー先生の「試験ではこう出るよ」ボックス。
 * 出題パターン・ひっかけどころ・覚え方のコツを、サニー先生の声で伝える。
 */
export function ExamAdviceBox(items: string[] | undefined): string {
  if (!items || items.length === 0) return "";
  return `<section class="term-exam-advice">
    <h2 class="term-section-title">試験ではこう出るよ</h2>
    ${CharacterGuide("moyan", "これって、試験ではどんなふうに出るの?")}
    <div class="exam-advice">
      <div class="exam-advice__chara">
        ${SunnySvg(72)}
        <p class="hero__chara-name">サニー先生</p>
      </div>
      <div class="exam-advice__box">
        <p class="exam-advice__lead">☀️ サニー先生の試験アドバイス</p>
        <ul class="exam-advice__list">
          ${items.map((i) => `<li>${esc(i)}</li>`).join("")}
        </ul>
      </div>
    </div>
  </section>`;
}
