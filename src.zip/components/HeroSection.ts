import { esc } from "../lib/html";
import { SITE } from "../lib/site";
import { MoyanSvg, SunnySvg } from "./Characters";

/**
 * トップページのファーストビュー。
 *
 * 台本:
 *  1. 中央にモヤンが出現
 *     「キャリアコンサルタントの勉強中なんだけど」「ことばの意味から難しいよ〜」
 *  2. 右にサニー先生が出現
 *     「大丈夫だよ〜」「見慣れない言葉ってだけ。」「ここでは言葉の意味から学べるよ」
 *  3. ふたりの上に、虹がかかるようなアーチ状のテキストが出現
 *     「もやもやモヤンとさんさんサニー先生の たのしいキャリアコンサルタント試験対策室」
 *  4. モヤンとサニー先生が下に移動
 *  5. 中央に「こころは天気のよう。…」→「キャリコンことば図鑑」→サイト説明が出現
 *  6. 「はじめての学習ルートを見る」ボタン出現
 *  7. その下で、ふたりの会話(6往復)がゆっくり流れつづける(ループ)
 *
 * つくりのポイント:
 *  - 吹き出しは conv-area(高さ固定)内の絶対配置 → 表示/非表示で他要素が動かない
 *  - 文字エリアは最初から場所を確保し opacity だけで現れる → シフトなし
 *  - ふたりの舞台はレイアウト上「一番下」にあり、開幕は transform で中央に
 *    持ち上げておき、アーチ出現後にゆっくり下りてくる
 *  - prefers-reduced-motion では移動・会話を再生せず、最終状態を即表示
 */
export function HeroSection(): string {
  return `<section class="hero hero--story">
    <div class="hero__bg" aria-hidden="true"></div>
    <div class="hero__veil" aria-hidden="true"></div>
    <div class="hero__inner">

      <!-- 虹がかかるようなアーチ状のテキスト(ふたりの上に出現) -->
      <div class="hero__head">
        <div class="hero-lockup story-step step-t1">
          <svg viewBox="0 0 560 190" class="hero-lockup__svg" role="img" aria-label="もやもやモヤンとさんさんサニー先生の たのしいキャリアコンサルタント試験対策室">
            <defs>
              <path id="ribbon-arc-1" d="M 36 128 Q 280 26 524 128" fill="none"/>
              <path id="ribbon-arc-2" d="M 36 155 Q 280 53 524 155" fill="none"/>
            </defs>
            <g fill="none" stroke="#3f4652" stroke-width="2" stroke-linecap="round">
              <path d="M 30 96 Q 280 -6 530 96"/>
              <path d="M 30 175 Q 280 73 530 175"/>
            </g>
            <text class="stage-ribbon__text">
              <textPath href="#ribbon-arc-1" startOffset="50%" text-anchor="middle">もやもやモヤンとさんさんサニー先生の</textPath>
            </text>
            <text class="stage-ribbon__text">
              <textPath href="#ribbon-arc-2" startOffset="50%" text-anchor="middle">たのしいキャリアコンサルタント試験対策室</textPath>
            </text>
          </svg>
        </div>
      </div>

      <!-- 中央に出現する文字たち(ふたりが下りたあと) -->
      <div class="hero__text">
        <p class="hero__weather story-step step-t2" aria-hidden="true">🌥️</p>
        <p class="hero__worldview">
          <span class="wv-line story-step step-t3">こころは天気のよう。</span>
          <span class="wv-line story-step step-t4">晴れの日も、雨の日も、</span>
          <span class="wv-line story-step step-t5">その空をじっとみつめ、よりそう。</span>
        </p>
        <p class="hero__en story-step step-t6" aria-hidden="true">${esc(SITE.nameEn)}</p>
        <h1 class="hero__title story-step step-t7">${esc(SITE.name)}</h1>
        <p class="hero__lede story-step step-t8">キャリアコンサルタント試験の「ことば」の意味からわかる試験対策サイト。<br>むずかしい専門用語を、暮らしの中の身近なたとえと、試験に必要な正式な説明の両方から学べます。</p>
        <div class="hero__actions story-step step-t9">
          <a class="button button--secondary" href="/start/">はじめての学習ルートを見る</a>
        </div>
      </div>

      <!-- ふたりの舞台。開幕は中央、アーチ出現後に下へ移動 -->
      <div class="story-stage">
        <div class="conv-area" aria-hidden="false">
          <!-- オープニング(1回だけ) -->
          <p class="stage-balloon stage-balloon--moyan intro-balloon intro-m1">キャリアコンサルタントの勉強中なんだけど</p>
          <p class="stage-balloon stage-balloon--moyan intro-balloon intro-m2">ことばの意味から難しいよ〜</p>
          <p class="stage-balloon stage-balloon--sunny intro-balloon intro-s1">大丈夫だよ〜</p>
          <p class="stage-balloon stage-balloon--sunny intro-balloon intro-s2">見慣れない言葉ってだけ。</p>
          <p class="stage-balloon stage-balloon--sunny intro-balloon intro-s3">ここでは言葉の意味から学べるよ</p>
          <!-- 読者の気持ちを代弁する6往復(ループ再生) -->
          <p class="stage-balloon stage-balloon--moyan loop-balloon conv-1">シャインとスーパーって、<br>何をした人……?</p>
          <p class="stage-balloon stage-balloon--sunny loop-balloon conv-2">大丈夫だよ。</p>
          <p class="stage-balloon stage-balloon--moyan loop-balloon conv-3">過去問を読んでいたら、<br>眠くなってきた……</p>
          <p class="stage-balloon stage-balloon--sunny loop-balloon conv-4">ここで、いっしょに<br>試験対策をしようね。</p>
          <p class="stage-balloon stage-balloon--moyan loop-balloon conv-5">労働政策? 労働法令?<br>そんな知識も必要なの……?</p>
          <p class="stage-balloon stage-balloon--sunny loop-balloon conv-6">まずは「ことば」の意味から、<br>イメージしてみようね。</p>
        </div>
        <div class="stage-charas">
          <div class="stage-chara story-step step-c1">
            ${MoyanSvg(104, true)}
            <p class="hero__chara-name">モヤン</p>
          </div>
          <div class="stage-chara story-step step-c2">
            ${SunnySvg(104)}
            <p class="hero__chara-name">サニー先生</p>
          </div>
        </div>
      </div>

    </div>
  </section>`;
}
