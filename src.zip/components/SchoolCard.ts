import { esc, formatDate, formatYen } from "../lib/html";
import type { School } from "../lib/types";
import { PrLabel } from "./PrLabel";

const MODE_LABEL: Record<School["deliveryModes"][number], string> = {
  "online-live": "オンライン(ライブ)",
  "online-on-demand": "オンライン(録画)",
  classroom: "通学",
  hybrid: "通学+オンライン",
};

export function deliveryModesLabel(s: School): string {
  if (s.deliveryModes.length === 0) return "調査中";
  return s.deliveryModes.map((m) => MODE_LABEL[m]).join(" / ");
}

export function onlineOnly(s: School): string {
  if (s.deliveryModes.length === 0) return "調査中";
  const hasOnline = s.deliveryModes.some((m) => m.startsWith("online"));
  const hasClassroomOnlyPath = s.deliveryModes.includes("online-live") || s.deliveryModes.includes("online-on-demand");
  return hasOnline && hasClassroomOnlyPath ? "可(コースによる)" : "要確認";
}

/** 学校一覧カード */
export function SchoolCard(s: School): string {
  const tags = (s.filterTags ?? []).join(" ");
  return `<article class="school-card" data-filter-tags="${esc(tags)}" data-school-slug="${esc(s.slug)}">
    <div class="school-card__head">
      <p class="school-card__meta">
        ${PrLabel(s.isPr ?? false)}
        ${
          s.informationStatus === "unverified"
            ? '<span class="info-label info-label--unverified">未確認・調査中</span>'
            : `<span class="updated-date__checked">情報確認日: ${esc(
                formatDate(s.verifiedAt ?? s.updatedAt)
              )}</span>`
        }
      </p>
      <h3 class="school-card__name"><a href="/schools/${esc(s.slug)}/">${esc(s.name)}</a></h3>
    </div>
    <dl class="school-card__facts">
      <div><dt>受講形式</dt><dd>${esc(deliveryModesLabel(s))}</dd></div>
      <div><dt>受講期間</dt><dd>${esc(s.courseDuration ?? "調査中")}</dd></div>
      <div><dt>基本料金</dt><dd>${
        s.tuition !== undefined ? esc(formatYen(s.tuition)) : "調査中"
      }</dd></div>
      <div><dt>給付金</dt><dd>${
        s.educationBenefitAvailable === undefined
          ? "調査中"
          : s.educationBenefitAvailable
            ? "対象講座あり(条件は要確認)"
            : "対象外"
      }</dd></div>
      <div><dt>オンライン完結</dt><dd>${esc(onlineOnly(s))}</dd></div>
    </dl>
    ${
      (s.highlights ?? []).length > 0
        ? `<ul class="school-card__highlights">${(s.highlights ?? [])
            .slice(0, 3)
            .map((h) => `<li>${esc(h)}</li>`)
            .join("")}</ul>`
        : ""
    }
    <div class="school-card__actions">
      <a class="button button--secondary" href="/schools/${esc(s.slug)}/">詳細を見る</a>
      <button type="button" class="button button--ghost" data-compare-add="${esc(s.slug)}" data-school-name="${esc(s.name)}">比較に追加</button>
    </div>
  </article>`;
}
