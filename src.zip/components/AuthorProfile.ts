import { esc } from "../lib/html";
import { SITE } from "../lib/site";

/** 運営者プロフィール(トップ・記事下部) */
export function AuthorProfile(compact = false): string {
  const points = [
    "3児の母",
    "国家資格キャリアコンサルタント養成講座を受講中",
    "2026年11月の試験に向けて勉強中",
    "勉強が得意ではない初学者として発信",
    "キャリア理論を子育てや母親の働き方に生かしたい",
  ];
  if (compact) {
    return `<aside class="author-profile author-profile--compact">
      <p class="author-profile__name">${esc(SITE.author.name)}</p>
      <p class="author-profile__bio">${esc(SITE.author.bio)}</p>
      <p><a href="/about/">このサイトについて →</a></p>
    </aside>`;
  }
  return `<div class="author-profile">
    <div class="author-profile__avatar" aria-hidden="true"></div>
    <div class="author-profile__body">
      <p class="author-profile__name">${esc(SITE.author.name)}</p>
      <ul class="author-profile__points">
        ${points.map((p) => `<li>${esc(p)}</li>`).join("")}
      </ul>
      <p class="author-profile__note">実際に分からなかった言葉を、初学者の目線で解説しています。</p>
      <p><a class="button button--secondary" href="/about/">このサイトについて</a></p>
    </div>
  </div>`;
}
