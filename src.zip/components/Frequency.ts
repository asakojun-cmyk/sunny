import type { FrequencyLevel } from "../data/frequency";

/**
 * 出題ひんど(めやす)の表示。
 * カプセルやボックスは使わず、番号(TERM 000 / No.00)の横に
 * 🌥️アイコンの数だけで示すシンプル方式。
 * 🌥️🌥️🌥️=よく出る / 🌥️🌥️=ときどき出る / 🌥️=おさえて安心
 */

const LABEL: Record<FrequencyLevel, string> = {
  3: "よく出る",
  2: "ときどき出る",
  1: "おさえて安心",
};

export function FrequencyMarks(level: FrequencyLevel | undefined): string {
  if (!level) return "";
  const marks = "🌥️".repeat(level);
  return `<span class="freq-marks" role="img" aria-label="出題ひんどのめやす: ${LABEL[level]}" title="出題ひんど(めやす): ${LABEL[level]}">${marks}</span>`;
}

/** 一覧ページ先頭に置く小さな凡例 */
export function FrequencyLegend(): string {
  return `<p class="freq-legend">出題ひんどのめやす: <span>🌥️🌥️🌥️ よく出る</span><span>🌥️🌥️ ときどき出る</span><span>🌥️ おさえて安心</span><br><span class="freq-legend__note">※ 受験対策で定番とされる度合いをもとにした運営者調べの目安です</span></p>`;
}
