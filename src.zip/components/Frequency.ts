import type { FrequencyLevel } from "../data/frequency";

/**
 * 出題ひんど(めやす)の表示。
 * 一覧: 小さなバッジ / 詳細ページ: サニー先生のひとこと付きボックス。
 */

const LABELS: Record<FrequencyLevel, { suns: string; label: string; cls: string }> = {
  3: { suns: "☀️☀️☀️", label: "よく出る", cls: "freq--3" },
  2: { suns: "☀️☀️", label: "ときどき出る", cls: "freq--2" },
  1: { suns: "☀️", label: "おさえて安心", cls: "freq--1" },
};

const COMMENTS: Record<FrequencyLevel, string> = {
  3: "受験対策の定番中の定番。ここは必ずおさえておこう!",
  2: "数回に一度は顔を出すテーマ。余裕のあるうちに一度読んでおくと安心だよ。",
  1: "出題は多くないけれど、知っていると差がつくテーマ。さらっとでOK!",
};

/** 一覧用の小さなバッジ */
export function FrequencyBadge(level: FrequencyLevel | undefined): string {
  if (!level) return "";
  const f = LABELS[level];
  return `<span class="freq-badge ${f.cls}"><span aria-hidden="true">${f.suns}</span> ${f.label}</span>`;
}

/** 詳細ページ用のボックス */
export function FrequencyBox(level: FrequencyLevel | undefined): string {
  if (!level) return "";
  const f = LABELS[level];
  return `<section class="freq-box">
    <h2 class="term-section-title">出題ひんど(めやす)</h2>
    <p class="freq-box__level ${f.cls}"><span aria-hidden="true">${f.suns}</span> ${f.label}</p>
    <p class="freq-box__comment">${COMMENTS[level]}</p>
    <p class="freq-box__note">※ 市販の過去問題集や受験対策で定番とされる度合いをもとにした、運営者調べの目安です。出題を保証するものではありません。</p>
  </section>`;
}
