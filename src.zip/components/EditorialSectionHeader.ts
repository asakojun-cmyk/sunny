import { esc } from "../lib/html";

/** 英字ラベル + 日本語見出しのセクションヘッダー(雑誌的な情報整理) */
export function EditorialSectionHeader(opts: {
  en: string;
  title: string;
  lede?: string;
  headingLevel?: 1 | 2;
}): string {
  const level = opts.headingLevel ?? 2;
  const tag = `h${level}`;
  return `<header class="section-header">
    <p class="section-header__en" aria-hidden="true">${esc(opts.en)}</p>
    <${tag} class="section-header__title">${esc(opts.title)}</${tag}>
    ${opts.lede ? `<p class="section-header__lede">${esc(opts.lede)}</p>` : ""}
  </header>`;
}
