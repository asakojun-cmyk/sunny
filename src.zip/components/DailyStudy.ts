import { esc } from "../lib/html";
import { terms } from "../data/terms";
import { theorists } from "../data/theorists";

/**
 * 今日の3分学習(今日の用語・今日の理論家・今日の1問)。
 * 登録済みデータを HTML に埋め込み、クライアント側 JS (daily.js) が
 * 日付に応じてローテーション表示する。編集者が固定したい場合は
 * data-fixed-index 属性を設定すればよい。
 */
export function TermOfTheDay(): string {
  const payload = terms.map((t) => ({
    name: t.name,
    reading: t.reading,
    oneLiner: t.oneLiner,
    url: `/terms/${t.slug}/`,
  }));
  return `<div class="daily-card" data-daily="term" data-items="${esc(
    JSON.stringify(payload)
  )}">
    <p class="daily-card__label">🌥️ 今日の用語</p>
    <div class="daily-card__body" data-daily-body>
      <p class="daily-card__title"><a href="/terms/${esc(terms[0]?.slug ?? "")}/">${esc(
        terms[0]?.name ?? ""
      )}</a></p>
      <p class="daily-card__desc">${esc(terms[0]?.oneLiner ?? "")}</p>
    </div>
  </div>`;
}

export function TheoristOfTheDay(): string {
  const payload = theorists.map((t) => ({
    name: t.name,
    reading: t.nameEn,
    oneLiner: t.oneLiner,
    url: `/theorists/${t.slug}/`,
  }));
  return `<div class="daily-card" data-daily="theorist" data-items="${esc(
    JSON.stringify(payload)
  )}">
    <p class="daily-card__label">☀️ 今日の理論家</p>
    <div class="daily-card__body" data-daily-body>
      <p class="daily-card__title"><a href="/theorists/${esc(theorists[0]?.slug ?? "")}/">${esc(
        theorists[0]?.name ?? ""
      )}</a></p>
      <p class="daily-card__desc">${esc(theorists[0]?.oneLiner ?? "")}</p>
    </div>
  </div>`;
}

export function QuestionOfTheDay(): string {
  const quizzes = terms
    .filter((t) => t.quiz)
    .map((t) => ({
      question: t.quiz!.question,
      answer: t.quiz!.answer,
      explanation: t.quiz!.explanation,
      url: `/terms/${t.slug}/`,
      termName: t.name,
    }));
  const first = quizzes[0];
  return `<div class="daily-card daily-card--quiz" data-daily="quiz" data-items="${esc(
    JSON.stringify(quizzes)
  )}">
    <p class="daily-card__label">🌈 今日の1問</p>
    <div class="daily-card__body" data-daily-body>
      <p class="daily-card__question">${esc(first?.question ?? "")}</p>
      <div class="daily-card__quiz-actions">
        <button type="button" class="button button--ghost" data-quiz-answer="true">○</button>
        <button type="button" class="button button--ghost" data-quiz-answer="false">×</button>
      </div>
      <p class="daily-card__result" data-quiz-result hidden></p>
    </div>
  </div>`;
}

export function DailyStudySection(): string {
  return `<div class="daily-grid">
    ${TermOfTheDay()}
    ${TheoristOfTheDay()}
    ${QuestionOfTheDay()}
  </div>`;
}
