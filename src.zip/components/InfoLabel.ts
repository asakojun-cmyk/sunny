import { esc } from "../lib/html";

/**
 * 情報の種類ラベル。
 * 色だけで判断させず、必ず文字でも表示する(spec準拠)。
 * - official  : 青系「公式情報」
 * - experience: 緑系「受講者本人の体験」
 * - editorial : 黄系「運営者の考察」
 * - unverified: グレー「未確認・調査中」
 */
export type InfoLabelKind =
  | "official"
  | "experience"
  | "editorial"
  | "unverified";

const LABEL_TEXT: Record<InfoLabelKind, string> = {
  official: "公式情報",
  experience: "受講者本人の体験",
  editorial: "運営者の考察",
  unverified: "未確認・調査中",
};

export function InfoLabel(kind: InfoLabelKind, text?: string): string {
  return `<span class="info-label info-label--${kind}">${esc(
    text ?? LABEL_TEXT[kind]
  )}</span>`;
}

/** ラベル付きのブロック(セクションまるごと種類を示す) */
export function InfoBlock(kind: InfoLabelKind, inner: string): string {
  return `<div class="info-block info-block--${kind}">
    <p class="info-block__label">${InfoLabel(kind)}</p>
    <div class="info-block__body">${inner}</div>
  </div>`;
}
