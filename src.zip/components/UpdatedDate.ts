import { esc, formatDate } from "../lib/html";

/** 更新日・情報確認日の表示 */
export function UpdatedDate(opts: {
  publishedAt?: string;
  updatedAt?: string;
  infoCheckedAt?: string;
}): string {
  const parts: string[] = [];
  if (opts.publishedAt)
    parts.push(`<span>公開日: ${esc(formatDate(opts.publishedAt))}</span>`);
  if (opts.updatedAt)
    parts.push(`<span>更新日: ${esc(formatDate(opts.updatedAt))}</span>`);
  if (opts.infoCheckedAt)
    parts.push(
      `<span class="updated-date__checked">情報確認日: ${esc(
        formatDate(opts.infoCheckedAt)
      )}</span>`
    );
  if (parts.length === 0) return "";
  return `<p class="updated-date">${parts.join("")}</p>`;
}
