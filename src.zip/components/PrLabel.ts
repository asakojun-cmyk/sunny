import { esc } from "../lib/html";

/** PR・広告ラベル。広告記事には冒頭の分かりやすい場所に表示する。 */
export function PrLabel(isPr: boolean): string {
  if (!isPr) return "";
  return `<span class="pr-label">PR</span>`;
}

/** 記事ごとの広告・提供関係の開示欄 */
export type DisclosureInfo = {
  isPr: boolean;
  receivedCompensation: boolean;
  containsAffiliateLinks: boolean;
  paidByAuthor: boolean;
  note?: string;
};

export function DisclosureBox(info: DisclosureInfo): string {
  const rows: Array<[string, string]> = [
    ["広告・PR", info.isPr ? "あり(この記事は広告を含みます)" : "なし"],
    [
      "学校からの報酬・無償提供",
      info.receivedCompensation ? "あり" : "受けていません",
    ],
    ["紹介リンク", info.containsAffiliateLinks ? "含みます" : "含みません"],
    [
      "受講料",
      info.paidByAuthor
        ? "運営者自身が支払っています"
        : "運営者は支払っていません",
    ],
  ];
  return `<aside class="disclosure" aria-label="広告・提供関係の開示">
    ${info.isPr ? '<p class="disclosure__pr">PR(この記事は広告を含みます)</p>' : ""}
    <p class="disclosure__title">この記事の広告・提供関係について</p>
    <dl class="disclosure__list">
      ${rows
        .map(
          ([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`
        )
        .join("")}
    </dl>
    ${info.note ? `<p class="disclosure__note">${esc(info.note)}</p>` : ""}
  </aside>`;
}
