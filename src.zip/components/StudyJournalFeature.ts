/** 養成講座に通いながら学んでいます(受講記録への導線) */
export function StudyJournalFeature(): string {
  return `<section class="study-journal">
    <p class="section-header__en" aria-hidden="true">MY STUDY JOURNAL</p>
    <h2 class="section-header__title">3児の母が、養成講座に通いながら学んでいます</h2>
    <p class="study-journal__desc">運営者自身も、国家資格キャリアコンサルタント養成講座で勉強中です。授業でつまずいた言葉、子育てと勉強を両立して感じたことを、初学者の目線で記録します。</p>
    <div class="study-journal__actions">
      <a class="button button--primary" href="/school-reviews/chiiki-renkei-platform/">受講記録を見る</a>
      <a class="button button--secondary" href="/schools/compare/">養成講座を比較する</a>
      <a class="button button--secondary" href="/school-guides/how-to-choose/">養成学校の選び方を見る</a>
    </div>
  </section>`;
}
