import { esc } from "../lib/html";
import { lawWatch } from "../data/law-watch";

/** 法律・制度・統計の用語ページに出す「確認日+一次資料」ボックス */
export function LawNotice(slug: string): string {
  const info = lawWatch[slug];
  if (!info) return "";
  const [y, m] = info.checkedAt.split("-");
  return `<aside class="law-notice">
    <p class="law-notice__lead">⚠️ この内容は<strong>${esc(y)}年${esc(String(Number(m)))}月時点</strong>で確認したものだよ。法律や制度は改正されることがあるから、大事な判断の前は一次資料も見てね。</p>
    <ul class="law-notice__links">
      ${info.sources
        .map(
          (s) =>
            `<li><a href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.label)} →</a></li>`
        )
        .join("")}
    </ul>
  </aside>`;
}
