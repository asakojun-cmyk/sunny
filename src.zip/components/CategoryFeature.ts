import { esc } from "../lib/html";
import { CATEGORIES } from "../lib/site";

/** カテゴリーから探す(初期表示6カテゴリー) */
export function CategoryFeature(): string {
  return `<div class="category-grid">
    ${CATEGORIES.map(
      (c) => `<div class="category-item">
      <p class="category-item__en" aria-hidden="true">${esc(c.en)}</p>
      <h3 class="category-item__name"><a href="${esc(c.href)}"><span aria-hidden="true">${esc(c.emoji)}</span> ${esc(c.name)}</a></h3>
      <p class="category-item__desc">${esc(c.description)}</p>
      <p class="category-item__more"><a href="${esc(c.href)}">一覧を見る →</a></p>
    </div>`
    ).join("")}
  </div>`;
}
