import { renderPage } from "../components/Layout";
import { EditorialSectionHeader } from "../components/EditorialSectionHeader";
import { RelatedContents, type RelatedItem } from "../components/RelatedContents";
import { UpdatedDate } from "../components/UpdatedDate";
import { AuthorProfile } from "../components/AuthorProfile";
import { CharacterGuide } from "../components/Characters";
import { TermDiagram } from "../components/Diagrams";
import { PastQuestions } from "../components/PastQuestions";
import { ExamAdviceBox } from "../components/ExamAdvice";
import { LawNotice } from "../components/LawNotice";
import { FrequencyMarks, FrequencyLegend } from "../components/Frequency";
import { termFrequency } from "../data/frequency";
import { termExamAdvice } from "../data/exam-advice";
import { esc } from "../lib/html";
import { SITE, CATEGORY_WEATHER } from "../lib/site";
import { terms, getTerm } from "../data/terms";
import { getTheorist } from "../data/theorists";
import type { Term } from "../lib/types";

function weatherIcon(category: string): string {
  return CATEGORY_WEATHER[category] ?? "🌥️";
}

/** 用語一覧 */
export function termsIndexPage(): string {
  const categories = [...new Set(terms.map((t) => t.category))];
  const body = `
<div class="container">
  ${EditorialSectionHeader({
    en: "WORDS",
    title: "キャリコンことば図鑑",
    lede: "テキストでつまずいた言葉を、モヤンとサニー先生の掛け合いで理解します。ひとこと→たとえ→試験用の説明の3段階です。",
    headingLevel: 1,
  })}
  ${CharacterGuide(
    "sunny",
    "気になる言葉をタップしてね。ぜんぶ、モヤンと一緒にやさしく解説しているよ。"
  )}
  <p class="page-guide">はじめての人は <a href="/terms/jiko-gainen/">「自己概念」</a> から読むのがおすすめです。</p>
  ${FrequencyLegend()}
  ${categories
    .map(
      (cat) => `
  <section class="term-category">
    <h2 class="term-category__title"><span aria-hidden="true">${weatherIcon(cat)}</span> ${esc(cat)}</h2>
    <ul class="term-list">
      ${terms
        .filter((t) => t.category === cat)
        .map(
          (t) => `<li class="term-list__item">
        <a href="/terms/${esc(t.slug)}/">
          <span class="term-list__number">TERM ${String(t.number).padStart(3, "0")} ${FrequencyMarks(termFrequency[t.slug])}</span>
          <span class="term-list__name">${esc(t.name)}</span>
          <span class="term-list__reading">${esc(t.reading)}</span>
          <span class="term-list__oneliner">${esc(t.oneLiner)}</span>
        </a>
      </li>`
        )
        .join("")}
    </ul>
  </section>`
    )
    .join("")}
</div>`;
  return renderPage({
    title: "キャリコンことば図鑑(用語一覧)",
    description:
      "キャリアコンサルタント試験の用語を、キャラクターの掛け合いと3段階のやさしい解説で学べる用語一覧です。図解イラストと公式過去問への案内つき。",
    path: "/terms/",
    activeNav: "/terms/",
    crumbs: [{ name: "ホーム", url: "/" }, { name: "ことば図鑑" }],
    body,
  });
}

/** 用語詳細(モヤン&サニー先生の掛け合い形式) */
export function termDetailPage(term: Term): string {
  const theoristLinks = (term.theoristSlugs ?? [])
    .map((slug) => getTheorist(slug))
    .filter((t) => t !== undefined);

  const related: RelatedItem[] = [
    ...(term.relatedTermSlugs ?? [])
      .map((slug) => getTerm(slug))
      .filter((t) => t !== undefined)
      .map((t) => ({
        type: "用語",
        title: t.name,
        url: `/terms/${t.slug}/`,
        description: t.oneLiner,
      })),
    ...theoristLinks.map((t) => ({
      type: "理論家",
      title: t.name,
      url: `/theorists/${t.slug}/`,
      description: t.oneLiner,
    })),
  ];

  const diagram = TermDiagram(term.slug);

  const body = `
<article class="container container--article term-article">
  <header class="term-header">
    <p class="term-header__number">TERM ${String(term.number).padStart(3, "0")} ${FrequencyMarks(termFrequency[term.slug])}</p>
    <h1 class="term-header__name">${esc(term.name)}</h1>
    <p class="term-header__reading">${esc(term.reading)}</p>
    <p class="term-header__category"><span aria-hidden="true">${weatherIcon(term.category)}</span> ${esc(term.category)}</p>
    ${UpdatedDate({ updatedAt: term.updatedAt })}
  </header>

  <section class="term-oneliner">
    <h2 class="term-section-title">ひとことでいうと</h2>
    ${CharacterGuide("moyan", `ねえサニー先生、「${term.name}」ってなあに?`)}
    ${CharacterGuide("sunny", term.oneLiner)}
  </section>

  ${
    diagram
      ? `<section class="term-diagram-section">
    <h2 class="term-section-title">図でイメージする</h2>
    ${diagram}
  </section>`
      : ""
  }

  <section class="term-kids">
    <h2 class="term-section-title">小学生でもわかる説明</h2>
    ${CharacterGuide("moyan", "うーん…もうすこしやさしく教えて!")}
    ${CharacterGuide("sunny", term.kidsExplanation)}
  </section>

  <section class="term-analogy">
    <h2 class="term-section-title">身近なたとえ</h2>
    ${CharacterGuide("moyan", "たとえば、どんな感じ?")}
    ${CharacterGuide("sunny", term.analogy)}
  </section>

  ${
    term.lifeExample
      ? `<section class="term-life">
    <h2 class="term-section-title">子育て・仕事で考えると</h2>
    ${CharacterGuide("moyan", "暮らしの中でも役に立つ?")}
    ${CharacterGuide("sunny", term.lifeExample)}
  </section>`
      : ""
  }

  <section class="term-formal">
    <h2 class="term-section-title">試験で必要な正式な説明</h2>
    ${CharacterGuide(
      "sunny",
      "ここからは先生モード。試験ではこう説明されるよ。ゆっくりでいいから読んでみてね。"
    )}
    <div class="term-formal__box">
      <p>${esc(term.formalExplanation)}</p>
    </div>
  </section>

  ${LawNotice(term.slug)}

  ${ExamAdviceBox(termExamAdvice[term.slug])}

  ${
    theoristLinks.length > 0
      ? `<section class="term-theorists">
    <h2 class="term-section-title">理論家との関係</h2>
    ${CharacterGuide("moyan", "この言葉って、だれの理論なの?")}
    <ul>
      ${theoristLinks
        .map(
          (t) =>
            `<li><a href="/theorists/${esc(t.slug)}/">${esc(t.name)}(${esc(
              t.nameEn
            )})</a> — ${esc(t.oneLiner)}</li>`
        )
        .join("")}
    </ul>
  </section>`
      : ""
  }

  ${
    (term.similarTerms ?? []).length > 0
      ? `<section class="term-similar">
    <h2 class="term-section-title">似た言葉との違い</h2>
    ${CharacterGuide(
      "moyan",
      `「${(term.similarTerms ?? [])[0]?.name ?? ""}」と、なにがちがうの?`
    )}
    <dl>
      ${(term.similarTerms ?? [])
        .map(
          (s) => `<div><dt>${esc(s.name)}</dt><dd>${esc(s.difference)}</dd></div>`
        )
        .join("")}
    </dl>
  </section>`
      : ""
  }

  ${
    term.quiz
      ? `<section class="term-quiz">
    <h2 class="term-section-title">1問1答(当サイトオリジナル)</h2>
    ${CharacterGuide("sunny", "それじゃあ、たしかめテスト!○か×か、選んでみてね。")}
    <div class="quiz-box" data-quiz data-answer="${term.quiz.answer}">
      <p class="quiz-box__question">${esc(term.quiz.question)}</p>
      <div class="quiz-box__actions">
        <button type="button" class="button button--ghost" data-quiz-answer="true">○</button>
        <button type="button" class="button button--ghost" data-quiz-answer="false">×</button>
      </div>
      <p class="quiz-box__result" data-quiz-result hidden>${esc(
        `${term.quiz.answer ? "正解は ○" : "正解は ×"} — ${term.quiz.explanation}`
      )}</p>
    </div>
  </section>`
      : ""
  }

  ${PastQuestions(term.name)}

  ${RelatedContents(related, "関連用語・関連する理論家")}
  ${AuthorProfile(true)}
</article>
<script src="/js/quiz.js" defer></script>`;

  return renderPage({
    title: `${term.name}(${term.reading})とは`,
    description: `${term.name}とは — ${term.oneLiner}。キャラクターの掛け合いと図解で、小学生でもわかる説明から試験で必要な正式な説明までやさしく解説します。`,
    path: `/terms/${term.slug}/`,
    activeNav: "/terms/",
    ogType: "article",
    crumbs: [
      { name: "ホーム", url: "/" },
      { name: "ことば図鑑", url: "/terms/" },
      { name: term.name },
    ],
    structuredData: [
      {
        "@context": "https://schema.org",
        "@type": "Article",
        headline: `${term.name}(${term.reading})とは`,
        description: term.oneLiner,
        dateModified: term.updatedAt,
        author: { "@type": "Person", name: SITE.author.name },
        mainEntityOfPage: `${SITE.baseUrl}/terms/${term.slug}/`,
      },
    ],
    body,
  });
}
