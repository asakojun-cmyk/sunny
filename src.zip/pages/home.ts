import { renderPage } from "../components/Layout";
import { HeroSection } from "../components/HeroSection";
import { SiteSearch } from "../components/SiteSearch";
import { EditorialSectionHeader } from "../components/EditorialSectionHeader";
import { LearningPath } from "../components/LearningPath";
import { CategoryFeature } from "../components/CategoryFeature";
import { DailyStudySection } from "../components/DailyStudy";
import { StudyJournalFeature } from "../components/StudyJournalFeature";
import { SchoolComparisonFeature } from "../components/SchoolComparisonFeature";
import { AuthorProfile } from "../components/AuthorProfile";
import { FeaturedArticle, ArticleListItem } from "../components/ArticleCard";
import { CharacterGuide, MoyanIdeaSvg, MoyanBookSvg, SunnyHappySvg } from "../components/Characters";
import { editorsPicks, latestArticles, articles } from "../data/articles";
import { SITE } from "../lib/site";

export function homePage(): string {
  const featured = editorsPicks.slice(0, 3);
  const latest = latestArticles.slice(0, 6);
  const mostRead = articles.filter((a) => a.editorsPick).slice(0, 3);

  const body = `
${HeroSection()}

<section class="section section--surface">
  <div class="container container--narrow">
    ${SiteSearch({ large: true, showPopular: true })}
  </div>
</section>

<section class="section">
  <div class="container">
    ${EditorialSectionHeader({
      en: "ABOUT",
      title: "このサイトで学べること",
    })}
    <div class="three-pillars">
      <a class="pillar" href="/terms/">
        <span class="pillar__chara">${MoyanIdeaSvg(92)}</span>
        <span class="pillar__en" aria-hidden="true">WORDS</span>
        <span class="pillar__title">ことばが、わかる</span>
        <span class="pillar__text">むずかしい専門用語を、やさしい言葉と身近なたとえで「そういうことか!」に変える</span>
        <span class="pillar__cta">ことば図鑑をひらく →</span>
      </a>
      <a class="pillar" href="/exam/">
        <span class="pillar__chara">${MoyanBookSvg(92)}</span>
        <span class="pillar__en" aria-hidden="true">EXAM</span>
        <span class="pillar__title">試験に、つよくなる</span>
        <span class="pillar__text">学科・論述・面接をばらばらにせず、「つながり」で対策する</span>
        <span class="pillar__cta">試験対策を見る →</span>
      </a>
      <a class="pillar" href="/schools/">
        <span class="pillar__chara">${SunnyHappySvg(92)}</span>
        <span class="pillar__en" aria-hidden="true">FUTURE</span>
        <span class="pillar__title">未来が、えがける</span>
        <span class="pillar__text">養成講座選びから、資格取得後の働き方まで見通せる</span>
        <span class="pillar__cta">講座選びと未来を見る →</span>
      </a>
    </div>
  </div>
</section>

<section class="section section--surface">
  <div class="container container--narrow">
    <a class="game-banner" href="/games/">
      <span class="game-banner__cards" aria-hidden="true">
        <span class="game-banner__card game-banner__card--1">🌥️</span>
        <span class="game-banner__card game-banner__card--2">☀️</span>
        <span class="game-banner__card game-banner__card--3">⭐</span>
      </span>
      <span class="game-banner__body">
        <span class="game-banner__badge">NEW</span>
        <span class="game-banner__title">🎮 3分ミニゲームで覚える</span>
        <span class="game-banner__desc">理論家カードあわせ — あそびながら、試験に出るポイントが身につくよ</span>
      </span>
      <span class="game-banner__cta">あそんでみる →</span>
    </a>
    <p class="omamori-link-row"><a href="/diagrams/">🗺️ 図解ライブラリ(キャリア形成とカウンセリングの流れ) →</a><br><a href="/omamori/">🌥️ 試験日カウントダウン&お守り待ち受けの配布はこちら →</a></p>
  </div>
</section>

<section class="section section--sky">
  <div class="container container--narrow">
    ${EditorialSectionHeader({
      en: "FIRST STEP",
      title: "どこから勉強すればいいかわからない方へ",
      lede: "この順番で進めると、知らない言葉に出会っても止まりにくくなります。",
    })}
    ${CharacterGuide(
      "sunny",
      "順番どおりじゃなくても大丈夫。気になったところから始めてOKだよ。"
    )}
    ${LearningPath()}
  </div>
</section>

<section class="section">
  <div class="container">
    ${EditorialSectionHeader({
      en: "CATEGORY",
      title: "カテゴリーから探す",
    })}
    ${CategoryFeature()}
  </div>
</section>

<section class="section section--surface" id="daily">
  <div class="container">
    ${EditorialSectionHeader({
      en: "3 MINUTES",
      title: "今日の3分学習",
      lede: "今日の用語・理論家・1問。すきま時間にひとつだけでも。",
    })}
    ${CharacterGuide("moyan", "きょうはこの3つだけでいいの? …それならできそう!")}
    ${DailyStudySection()}
    <p class="section__more"><a class="button button--secondary" href="/games/">🎮 3分ミニゲームであそびながら覚える</a></p>
  </div>
</section>

<section class="section">
  <div class="container container--narrow">
    ${StudyJournalFeature()}
  </div>
</section>

<section class="section section--sky">
  <div class="container">
    ${EditorialSectionHeader({
      en: "SCHOOLS",
      title: "暮らしに合う養成講座を探す",
    })}
    <p class="schools-entry-link">🔰 検討をはじめたばかりの方は、まず<a href="/shikaku-guide/">資格まるわかりガイド</a>へ。費用・給付金・難易度がこの1ページでわかるよ。</p>
    ${SchoolComparisonFeature()}
  </div>
</section>

<section class="section">
  <div class="container">
    ${EditorialSectionHeader({
      en: "PICK UP",
      title: "注目の記事",
    })}
    <div class="featured-grid">
      ${featured.map((a) => FeaturedArticle(a)).join("")}
    </div>
  </div>
</section>

<section class="section section--surface">
  <div class="container container--narrow">
    ${EditorialSectionHeader({
      en: "NEW ARTICLES",
      title: "最新の記事",
    })}
    <ul class="article-list">
      ${latest.map((a) => ArticleListItem(a)).join("")}
    </ul>
    <p class="section__more"><a href="/terms/">もっと見る →</a></p>
  </div>
</section>

<section class="section">
  <div class="container container--narrow">
    ${EditorialSectionHeader({
      en: "MOST READ",
      title: "はじめに読みたい記事",
      lede: "閲覧数データが集まるまでは、運営者が選んだ記事を紹介しています。",
    })}
    <ul class="article-list">
      ${mostRead.map((a) => ArticleListItem(a)).join("")}
    </ul>
  </div>
</section>

<section class="section section--yellow">
  <div class="container container--narrow">
    ${EditorialSectionHeader({
      en: "LIFE & THEORY",
      title: "⛅ キャリア理論を暮らしに使う",
      lede: "このサイトの道しるべは天気のアイコン。くもり(もやもや)は、晴れ(わかった!)に必ず変わります。人生の転機も、天気と同じです。",
    })}
    <ul class="life-theory-list">
      <li><a href="/terms/tenki/">🌧️ 転機は天気に似ている — シュロスバーグの4Sで点検する</a></li>
      <li><a href="/theorists/rogers/">🌈 ロジャーズの受容は、子どもを何でも許すこと?</a></li>
      <li><a href="/terms/life-career-rainbow/">☀️ スーパーのライフロールで、母親の役割を考える</a></li>
      <li><a href="/terms/jiko-koryokukan/">🌤️ 自己効力感を下げない声のかけ方</a></li>
      <li><a href="/terms/planned-happenstance/">⛅ クランボルツから考える、子どもの偶然との出会い</a></li>
    </ul>
    <p class="section__more"><a class="button button--secondary" href="/column/">☁️ モヤンの中の人コラムを読む</a></p>
  </div>
</section>

<section class="section section--surface">
  <div class="container container--narrow">
    ${EditorialSectionHeader({
      en: "FUTURE",
      title: "資格を取った後の未来",
      lede: "キャリアコンサルタントの仕事、資格を生かせる職場、在宅や副業での働き方、更新講習、子育て支援への活用まで。",
    })}
    <p class="section__more"><a class="button button--secondary" href="/careers/">資格取得後の働き方を見る</a></p>
  </div>
</section>

<section class="section">
  <div class="container container--narrow">
    ${EditorialSectionHeader({
      en: "PROFILE",
      title: "運営者プロフィール",
    })}
    ${AuthorProfile()}
  </div>
</section>

<section class="section section--surface section--last">
  <div class="container container--narrow">
    ${EditorialSectionHeader({
      en: "UPDATES",
      title: "更新情報",
    })}
    <p class="updates__text">新しい用語や記事は、このサイトの<a href="/terms/">一覧ページ</a>から確認できます。</p>
  </div>
</section>
<script src="/js/daily.js?v=${SITE.version}" defer></script>
<script src="/js/compare.js?v=${SITE.version}" defer></script>
`;

  return renderPage({
    title: SITE.name,
    description: `${SITE.description} ${SITE.tagline}。`,
    path: "/",
    body,
    isHome: true,
    structuredData: [
      {
        "@context": "https://schema.org",
        "@type": "WebSite",
        name: SITE.name,
        alternateName: SITE.nameEn,
        url: SITE.baseUrl,
        description: SITE.description,
      },
    ],
  });
}
