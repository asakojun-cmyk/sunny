import { renderPage } from "../components/Layout";
import { EditorialSectionHeader } from "../components/EditorialSectionHeader";
import { RelatedContents, type RelatedItem } from "../components/RelatedContents";
import { UpdatedDate } from "../components/UpdatedDate";
import { AuthorProfile } from "../components/AuthorProfile";
import { CharacterGuide } from "../components/Characters";
import { ExamAdviceBox } from "../components/ExamAdvice";
import { theoristExamAdvice } from "../data/exam-advice";
import { BookShelf } from "../components/BookShelf";
import { booksForTheorist } from "../data/books";
import { FrequencyMarks, FrequencyLegend } from "../components/Frequency";
import { theoristFrequency } from "../data/frequency";
import { TermDiagram, TheoristAvatar } from "../components/Diagrams";
import { PastQuestions } from "../components/PastQuestions";
import { esc } from "../lib/html";
import { SITE } from "../lib/site";
import { theorists, getTheorist } from "../data/theorists";
import { getTerm } from "../data/terms";
import type { Theorist } from "../lib/types";

/** 理論家一覧 */
export function theoristsIndexPage(): string {
  const body = `
<div class="container">
  ${EditorialSectionHeader({
    en: "THEORISTS",
    title: "理論家図鑑",
    lede: "「誰が何を言ったか」が混ざってしまう人のために、似顔絵イラストと掛け合いで理論家ごとの違いを整理します。",
    headingLevel: 1,
  })}
  ${CharacterGuide(
    "moyan",
    "スーパーとシャイン、どっちがどっちか、いつも混ざっちゃう…"
  )}
  ${CharacterGuide(
    "sunny",
    "だいじょうぶ。各ページに「混同しやすい理論家」の見分け方をのせているよ。"
  )}
  ${FrequencyLegend()}
  <ul class="theorist-list">
    ${theorists
      .map(
        (t) => `<li class="theorist-list__item">
      <a href="/theorists/${esc(t.slug)}/">
        <span class="theorist-list__avatar" aria-hidden="true">${TheoristAvatar(t.slug, 64)}</span>
        <span class="theorist-list__number">No.${String(t.number).padStart(2, "0")} ${FrequencyMarks(theoristFrequency[t.slug])}</span>
        <span class="theorist-list__name">${esc(t.name)}</span>
        <span class="theorist-list__en">${esc(t.nameEn)}</span>
        <span class="theorist-list__field">${esc(t.field)}</span>
        <span class="theorist-list__oneliner">${esc(t.oneLiner)}</span>
      </a>
    </li>`
      )
      .join("")}
  </ul>
  <p class="page-guide">※似顔絵は当サイト作成のイメージイラストです(実際の写真は著作権保護のため掲載していません)。</p>
</div>`;
  return renderPage({
    title: "理論家図鑑(一覧)",
    description:
      "キャリアコンサルタント試験に出る理論家12人を、似顔絵イラスト・ひとこと紹介・混同しやすいポイントで整理した一覧です。",
    path: "/theorists/",
    activeNav: "/theorists/",
    crumbs: [{ name: "ホーム", url: "/" }, { name: "理論家図鑑" }],
    body,
  });
}

/** 理論家詳細(掛け合い形式+似顔絵+図解+過去問案内) */
export function theoristDetailPage(theorist: Theorist): string {
  const related: RelatedItem[] = [
    ...(theorist.relatedTermSlugs ?? [])
      .map((slug) => getTerm(slug))
      .filter((t) => t !== undefined)
      .map((t) => ({
        type: "用語",
        title: t.name,
        url: `/terms/${t.slug}/`,
        description: t.oneLiner,
      })),
  ];

  const diagram = TermDiagram(theorist.slug);
  const ytSearch = `https://www.youtube.com/results?search_query=${encodeURIComponent(
    `キャリアコンサルタント ${theorist.name} ${theorist.field}`
  )}`;

  const body = `
<article class="container container--article theorist-article">
  <header class="term-header term-header--theorist">
    <a class="term-header__portrait" href="#episode" aria-label="エピソードへ移動">${TheoristAvatar(theorist.slug, 120)}</a>
    <div>
      <p class="term-header__number">THEORIST ${String(theorist.number).padStart(2, "0")} ${FrequencyMarks(theoristFrequency[theorist.slug])}</p>
      <h1 class="term-header__name">${esc(theorist.name)}</h1>
      <p class="term-header__reading">${esc(theorist.nameEn)}</p>
      <p class="term-header__category">☀️ ${esc(theorist.field)}</p>
      ${UpdatedDate({ updatedAt: theorist.updatedAt })}
      <p class="term-header__portrait-cta"><a href="#episode">👀 写真・エピソード・動画を見る →</a></p>
    </div>
  </header>
  <p class="term-header__portrait-note">似顔絵は当サイト作成のイメージイラストです(実際の写真は下の「もっと知る」からご覧いただけます)。</p>

  <section class="term-oneliner">
    <h2 class="term-section-title">ひとことでいうと</h2>
    ${CharacterGuide("moyan", `${theorist.name}先生って、どんな人?`)}
    ${CharacterGuide("sunny", theorist.oneLiner)}
  </section>

  <section class="term-kids">
    <h2 class="term-section-title">小学生でもわかる説明</h2>
    ${CharacterGuide("moyan", "やさしく教えて!")}
    ${CharacterGuide("sunny", theorist.kidsExplanation)}
  </section>

  <section class="term-analogy">
    <h2 class="term-section-title">身近なたとえ</h2>
    ${CharacterGuide("moyan", "イメージできる、たとえある?")}
    ${CharacterGuide("sunny", theorist.analogy)}
  </section>

  ${
    diagram
      ? `<section class="term-diagram-section">
    <h2 class="term-section-title">図でイメージする</h2>
    ${diagram}
  </section>`
      : ""
  }

  <section class="term-formal">
    <h2 class="term-section-title">おもな理論・キーワード</h2>
    ${CharacterGuide("sunny", "先生モードでまとめるよ。太字の用語は試験にそのまま出るからね。")}
    <div class="term-formal__box">
      <dl>
        ${theorist.keyConcepts
          .map(
            (c) => `<div><dt>${esc(c.name)}</dt><dd>${esc(c.description)}</dd></div>`
          )
          .join("")}
      </dl>
    </div>
  </section>

  <section class="term-exam-points">
    <h2 class="term-section-title">試験でのポイント</h2>
    ${CharacterGuide("moyan", "テストでは、どこに気をつければいい?")}
    <ul>
      ${theorist.examPoints.map((p) => `<li>${esc(p)}</li>`).join("")}
    </ul>
  </section>

  ${ExamAdviceBox(theoristExamAdvice[theorist.slug])}

  ${BookShelf(booksForTheorist(theorist.slug), `${theorist.name}をもっと知る本`)}

  ${
    (theorist.confusableWith ?? []).length > 0
      ? `<section class="term-similar">
    <h2 class="term-section-title">混同しやすい理論家</h2>
    ${CharacterGuide("moyan", "ほかの先生と混ざりそう…見分け方は?")}
    <dl>
      ${(theorist.confusableWith ?? [])
        .map((c) => {
          const other = getTheorist(c.theoristSlug);
          const name = other
            ? `<a href="/theorists/${esc(other.slug)}/">${esc(other.name)}</a>`
            : esc(c.theoristSlug);
          return `<div><dt>${name}</dt><dd>${esc(c.point)}</dd></div>`;
        })
        .join("")}
    </dl>
  </section>`
      : ""
  }

  ${
    (theorist.episodes ?? []).length > 0
      ? `<section class="term-episode" id="episode">
    <h2 class="term-section-title">☀️ 覚えるためのエピソード</h2>
    ${CharacterGuide("moyan", `${theorist.name}先生って、どんな人だったの?`)}
    ${CharacterGuide("sunny", "理論だけだと覚えにくいよね。人となりを知ると、ぐっと記憶に残るよ!")}
    <ul class="episode-list">
      ${(theorist.episodes ?? []).map((e) => `<li>${esc(e)}</li>`).join("")}
    </ul>
  </section>`
      : ""
  }

  <section class="term-more">
    <h2 class="term-section-title">🔎 もっと知る(写真・動画)</h2>
    ${CharacterGuide(
      "sunny",
      "実際の写真や、くわしい経歴・解説動画は、下のリンクから見られるよ。イラストと本物の顔、両方見ると覚えやすいね。"
    )}
    <ul class="more-links">
      ${(theorist.profileLinks ?? [])
        .map(
          (l) =>
            `<li><span class="more-links__icon" aria-hidden="true">📷</span><a href="${esc(l.url)}" rel="noopener nofollow" target="_blank">${esc(l.label)}</a></li>`
        )
        .join("")}
      <li><span class="more-links__icon" aria-hidden="true">▶️</span><a href="${esc(ytSearch)}" rel="noopener nofollow" target="_blank">YouTubeで解説動画を探す(${esc(theorist.name)})</a></li>
    </ul>
    <p class="more-links__note">外部サイト(Wikipedia・YouTube)が開きます。写真・動画の内容は各サイトの提供者に権利があります。当サイトは内容を保証するものではありません。</p>
  </section>

  ${PastQuestions(theorist.name)}

  ${RelatedContents(related, "関連用語")}
  ${AuthorProfile(true)}
</article>`;

  return renderPage({
    title: `${theorist.name}(${theorist.nameEn})の理論`,
    description: `${theorist.name} — ${theorist.oneLiner}。似顔絵イラストと掛け合いで、おもな理論と試験でのポイント、混同しやすい理論家との違いをやさしく解説します。`,
    path: `/theorists/${theorist.slug}/`,
    activeNav: "/theorists/",
    ogType: "article",
    crumbs: [
      { name: "ホーム", url: "/" },
      { name: "理論家図鑑", url: "/theorists/" },
      { name: theorist.name },
    ],
    structuredData: [
      {
        "@context": "https://schema.org",
        "@type": "Article",
        headline: `${theorist.name}(${theorist.nameEn})の理論`,
        description: theorist.oneLiner,
        dateModified: theorist.updatedAt,
        author: { "@type": "Person", name: SITE.author.name },
        mainEntityOfPage: `${SITE.baseUrl}/theorists/${theorist.slug}/`,
      },
    ],
    body,
  });
}
