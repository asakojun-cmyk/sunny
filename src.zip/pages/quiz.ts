import { renderPage } from "../components/Layout";
import { EditorialSectionHeader } from "../components/EditorialSectionHeader";
import { CharacterGuide } from "../components/Characters";
import { esc } from "../lib/html";
import { SITE, CATEGORY_WEATHER } from "../lib/site";
import { terms } from "../data/terms";
import { termFrequency } from "../data/frequency";

/**
 * ○×クイズドリル: 各用語ページの1問1答(オリジナル)だけを集めて連続でとける専用モード。
 */
export function quizDrillPage(): string {
  const items = terms
    .filter((t) => t.quiz)
    .map((t) => ({
      q: t.quiz!.question,
      a: t.quiz!.answer,
      e: t.quiz!.explanation,
      n: t.name,
      u: `/terms/${t.slug}/`,
      c: t.category,
      f: termFrequency[t.slug] ?? 0,
    }));

  const cats = Object.keys(CATEGORY_WEATHER);
  const chips = [
    `<button type="button" class="filter-chip" data-quiz-filter="all" aria-pressed="true">ぜんぶ(${items.length}問)</button>`,
    `<button type="button" class="filter-chip" data-quiz-filter="freq3" aria-pressed="false">🌥️🌥️🌥️よく出るだけ</button>`,
    ...cats.map(
      (c) =>
        `<button type="button" class="filter-chip" data-quiz-filter="cat:${esc(c)}" aria-pressed="false">${CATEGORY_WEATHER[c]}${esc(c)}</button>`
    ),
  ].join("");

  const body = `
<div class="container container--narrow">
  ${EditorialSectionHeader({
    en: "QUIZ DRILL",
    title: "🌈 ○×クイズドリル",
    lede: "各用語ページの1問1答(当サイトオリジナル)だけを集めました。すきま時間に、テンポよく。まちがえた問題は解説からそのまま用語ページへ飛べます。",
    headingLevel: 1,
  })}
  ${CharacterGuide("sunny", "範囲を選んでスタート!順番は毎回シャッフルされるよ。まちがえても大丈夫、まちがいの数だけ強くなるからね。")}
  <div class="school-filters" role="group" aria-label="出題範囲を選ぶ">
    <p class="school-filters__label">出題範囲:</p>
    ${chips}
  </div>
  <div class="quiz-drill" data-quiz-drill>
    <div class="quiz-drill__start" data-quiz-start>
      <p class="quiz-drill__count"><span data-quiz-pool>${items.length}</span>問が出題されます</p>
      <button type="button" class="button button--primary" data-quiz-begin>スタート!</button>
    </div>
    <div class="quiz-drill__card" data-quiz-card hidden>
      <p class="quiz-drill__progress"><span data-quiz-no>1</span> / <span data-quiz-total>0</span>問 <span class="quiz-drill__score">正解 <span data-quiz-score>0</span></span></p>
      <p class="quiz-drill__cat" data-quiz-cat></p>
      <p class="quiz-drill__q" data-quiz-q></p>
      <div class="quiz-drill__actions">
        <button type="button" class="button button--ghost quiz-drill__btn" data-quiz-ans="true">○</button>
        <button type="button" class="button button--ghost quiz-drill__btn" data-quiz-ans="false">×</button>
      </div>
      <div class="quiz-drill__result" data-quiz-result hidden>
        <p class="quiz-drill__verdict" data-quiz-verdict></p>
        <p class="quiz-drill__exp" data-quiz-exp></p>
        <p class="quiz-drill__link"><a data-quiz-link href="#">用語ページで復習する →</a></p>
        <button type="button" class="button button--primary" data-quiz-next>次の問題へ</button>
      </div>
    </div>
    <div class="quiz-drill__end" data-quiz-end hidden>
      <p class="quiz-drill__endtitle">おつかれさま!</p>
      <p class="quiz-drill__endscore"><span data-quiz-final></span></p>
      <p class="quiz-drill__endnote" data-quiz-endnote></p>
      <button type="button" class="button button--primary" data-quiz-retry>もう一回(シャッフル)</button>
    </div>
  </div>
  <p class="quiz-drill__foot">※ 問題はすべて当サイトのオリジナルです(実際の過去問の転載ではありません)。</p>
</div>
<script type="application/json" id="quiz-data">${JSON.stringify(items).replace(/</g, "\\u003c")}</script>
<script src="/js/quiz-drill.js?v=${esc(SITE.version)}" defer></script>`;

  return renderPage({
    title: `○×クイズドリル(全${items.length}問・オリジナル1問1答)`,
    description:
      "キャリアコンサルタント学科試験対策のオリジナル○×問題を連続で解けるドリルモード。カテゴリ別・頻出だけの絞り込みつき。まちがえたらそのまま用語解説へ。",
    path: "/games/quiz/",
    body,
    crumbs: [
      { name: "ホーム", url: "/" },
      { name: "3分ミニゲーム", url: "/games/" },
      { name: "○×クイズドリル" },
    ],
  });
}
