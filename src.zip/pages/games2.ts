import { renderPage } from "../components/Layout";
import { EditorialSectionHeader } from "../components/EditorialSectionHeader";
import { CharacterGuide } from "../components/Characters";
import { TheoristAvatar } from "../components/Diagrams";
import { esc } from "../lib/html";

/* ============================================================
 * 学習ゲーム第2弾:
 * 1. 傾聴のつみきブロック(人間観→基本的態度→技法)
 * 2. 理論家の流派仕分け(5つの流派)
 * 3. 穴埋めゲーム4種(マズロー/アーチ/ブロンフェンブレナー/キャリアコーン)
 * ============================================================ */

/** 1. 傾聴のつみきブロック */
export function tsumikiGamePage(): string {
  const body = `
<section class="section">
  <div class="container container--narrow">
    ${EditorialSectionHeader({
      en: "MINI GAME 02",
      title: "🧱 傾聴のつみきブロック",
      lede: "カウンセリングは「積む順番」が命。正しい順番でつみきを積んで、崩れないカウンセリングタワーを建てよう。",
    })}
    ${CharacterGuide("moyan", "技法をいっぱい覚えたから、まず技法から使えばいいんだよね?")}
    ${CharacterGuide("sunny", "ふふ、ほんとにそうかな? 積んでみればわかるよ。下から順番にタップしてね。")}

    <div class="tsumiki" id="tsumiki-game">
      <div class="tsumiki__stage">
        <div class="tsumiki__stack" data-stack aria-live="polite"></div>
        <div class="tsumiki__ground"></div>
      </div>
      <p class="tsumiki__feedback" data-feedback>👇 土台にするブロックからタップしてね</p>
      <div class="tsumiki__bank" data-bank>
        <button type="button" class="tsumiki-block tsumiki-block--giho" data-block="giho">技法<span>質問・感情の反映・要約…</span></button>
        <button type="button" class="tsumiki-block tsumiki-block--ningen" data-block="ningen">人間観<span>人は自ら成長する力を持つ</span></button>
        <button type="button" class="tsumiki-block tsumiki-block--taido" data-block="taido">基本的態度<span>受容・共感・自己一致</span></button>
      </div>
      <div class="tsumiki__clear" data-clear hidden>
        <p class="tsumiki__clear-title">🎉 崩れないタワーが建ったね!</p>
        <dl class="tsumiki__lesson">
          <div><dt>🟫 土台: 人間観</dt><dd>「人は自ら成長する力(実現傾向)を持つ」という信頼。ここが無いと、どんな技法も相手を操作する道具になってしまう。</dd></div>
          <div><dt>🟨 2段目: 基本的態度</dt><dd>受容(無条件の肯定的配慮)・共感的理解・自己一致。ロジャーズの3条件。人間観の上にはじめて成り立つ。</dd></div>
          <div><dt>🟦 3段目: 技法</dt><dd>質問技法・感情の反映・要約など。態度という土台の上で使うから効果が出る。順番を逆にすると「技法だけの冷たい面接」に。</dd></div>
        </dl>
        <p class="tsumiki__exam">✏️ 試験では「技法が土台」とする記述は×。<strong>人間観・態度が先、技法があと</strong>だよ。</p>
        <div class="match-game__clear-actions">
          <button type="button" class="button button--primary" data-retry>もう一回つむ</button>
          <a class="button button--secondary" href="/terms/keicho/">傾聴のページでおさらい</a>
        </div>
      </div>
    </div>
  </div>
</section>
<script src="/js/game-tsumiki.js" defer></script>`;
  return renderPage({
    title: "傾聴のつみきブロック(3分ミニゲーム)",
    description:
      "カウンセリングの土台は人間観→基本的態度→技法の順。積む順番を体で覚えるミニゲーム。",
    path: "/games/tsumiki/",
    body,
    crumbs: [
      { name: "ホーム", url: "/" },
      { name: "ミニゲーム", url: "/games/" },
      { name: "傾聴のつみきブロック" },
    ],
  });
}

/** 2. 理論家の流派仕分けゲーム */
type RyuhaCard = { slug: string; name: string; school: string; fact: string };
const SCHOOLS: { id: string; name: string; blurb: string; derived: string }[] = [
  {
    id: "tokusei",
    name: "特性因子論",
    blurb: "人の特性と職業の条件をマッチングする、いちばん古い流れ。「丸いくぎは丸い穴に」。",
    derived: "パーソンズの職業指導 → ホランドのRIASECへ発展",
  },
  {
    id: "seishin",
    name: "精神力動論",
    blurb: "心の奥(無意識や幼少期の経験)が行動を動かすと考える、フロイト発の流れ。",
    derived: "ローの早期決定論、ボーディンの理論、エリクソンの自我発達へ",
  },
  {
    id: "jikoseichō",
    name: "自己成長論",
    blurb: "人には自ら成長する力があると信じる流れ(人間性心理学)。自己概念を大切にする。",
    derived: "ロジャーズの来談者中心療法、スーパーの自己概念理論、マズローの欲求階層説",
  },
  {
    id: "ninchi",
    name: "認知行動論",
    blurb: "「考え方のクセ」と「学習された行動」を変えれば気持ちと行動が変わる、という流れ。",
    derived: "エリスの論理療法、ベックの認知療法、バンデューラ・クランボルツの社会的学習理論",
  },
  {
    id: "soshiki",
    name: "組織心理論",
    blurb: "組織の中で人のキャリアがどう育つかに注目する流れ。",
    derived: "シャインのキャリア・アンカー、ホールのプロティアン・キャリア",
  },
];
const RYUHA_CARDS: RyuhaCard[] = [
  { slug: "parsons", name: "パーソンズ", school: "tokusei", fact: "職業指導の父。自己理解×職業理解×合理的推論。" },
  { slug: "holland", name: "ホランド", school: "tokusei", fact: "RIASECの6類型。特性因子論の現代版。" },
  { slug: "freud", name: "フロイト", school: "seishin", fact: "無意識・防衛機制・自由連想。精神力動の源流。" },
  { slug: "roe", name: "ロー", school: "seishin", fact: "幼少期の親子関係が職業選択に影響(早期決定論)。" },
  { slug: "erikson", name: "エリクソン", school: "seishin", fact: "自我の発達を8段階で説明。精神分析の流れをくむ。" },
  { slug: "rogers", name: "ロジャーズ", school: "jikoseichō", fact: "実現傾向を信じる来談者中心療法。" },
  { slug: "maslow", name: "マズロー", school: "jikoseichō", fact: "欲求5段階と自己実現。人間性心理学の代表。" },
  { slug: "super", name: "スーパー", school: "jikoseichō", fact: "自己概念を職業で実現していく、が中心テーマ。" },
  { slug: "ellis", name: "エリス", school: "ninchi", fact: "ABC理論。考え方(ビリーフ)を変える論理療法。" },
  { slug: "beck", name: "ベック", school: "ninchi", fact: "自動思考に気づく認知療法。" },
  { slug: "bandura", name: "バンデューラ", school: "ninchi", fact: "観察学習と自己効力感。社会的学習理論。" },
  { slug: "krumboltz", name: "クランボルツ", school: "ninchi", fact: "社会的学習理論をキャリアに応用。計画された偶発性。" },
  { slug: "schein", name: "シャイン", school: "soshiki", fact: "キャリア・アンカーと組織内キャリア発達。" },
  { slug: "hall", name: "ホール", school: "soshiki", fact: "組織との関係の中で提唱したプロティアン・キャリア。" },
];

export function ryuhaGamePage(): string {
  const cards = RYUHA_CARDS.map(
    (c, i) => `<div class="ryuha-card" data-card="${i}" data-school="${esc(c.school)}" hidden>
      <span class="ryuha-card__avatar">${TheoristAvatar(c.slug, 72)}</span>
      <span class="ryuha-card__name">${esc(c.name)}</span>
      <span class="ryuha-card__fact" data-fact>${esc(c.fact)}</span>
    </div>`
  ).join("");
  const buckets = SCHOOLS.map(
    (s) => `<button type="button" class="ryuha-bucket" data-bucket="${esc(s.id)}">
      <span class="ryuha-bucket__name">${esc(s.name)}</span>
    </button>`
  ).join("");
  const summary = SCHOOLS.map(
    (s) => `<div class="ryuha-summary__item">
      <h3>${esc(s.name)}</h3>
      <p>${esc(s.blurb)}</p>
      <p class="ryuha-summary__derived">🌱 ここから: ${esc(s.derived)}</p>
    </div>`
  ).join("");

  const body = `
<section class="section">
  <div class="container container--narrow">
    ${EditorialSectionHeader({
      en: "MINI GAME 03",
      title: "🗃️ 理論家の流派仕分け",
      lede: "理論家カードを5つの流派の棚に仕分けよう。仕分けるたびに、その流派の考え方がわかっていくよ。",
    })}
    ${CharacterGuide("moyan", "理論家がいっぱいいて、だれがどのグループか混ざっちゃう〜!")}
    ${CharacterGuide("sunny", "「どの流派の人か」がわかると、理論の中身も推測できるようになるんだよ。")}

    <div class="ryuha" id="ryuha-game">
      <div class="ryuha__status"><span data-progress>1 / ${RYUHA_CARDS.length}</span><span data-miss>ミス: 0</span></div>
      <div class="ryuha__card-area">${cards}</div>
      <p class="ryuha__feedback" data-feedback>この理論家は、どの流派の棚に入る?</p>
      <div class="ryuha__buckets">${buckets}</div>
      <div class="ryuha__clear" data-clear hidden>
        <p class="tsumiki__clear-title">🎉 ぜんぶ仕分けられたね!</p>
        <p data-result></p>
        <div class="ryuha-summary">${summary}</div>
        <div class="match-game__clear-actions">
          <button type="button" class="button button--primary" data-retry>もう一回仕分ける</button>
          <a class="button button--secondary" href="/theorists/">理論家図鑑でおさらい</a>
        </div>
      </div>
    </div>
  </div>
</section>
<script src="/js/game-ryuha.js" defer></script>`;
  return renderPage({
    title: "理論家の流派仕分けゲーム(3分ミニゲーム)",
    description:
      "特性因子論・精神力動論・自己成長論・認知行動論・組織心理論の5つの流派に理論家を仕分けて、理論の系譜を楽しく覚えるミニゲーム。",
    path: "/games/ryuha/",
    body,
    crumbs: [
      { name: "ホーム", url: "/" },
      { name: "ミニゲーム", url: "/games/" },
      { name: "理論家の流派仕分け" },
    ],
  });
}

/** 3. 穴埋めゲーム(4つの図) */
type Puzzle = {
  id: string;
  title: string;
  tabEmoji: string;
  intro: string;
  layout: "pyramid" | "arch" | "rings" | "cone";
  slots: { id: string; answer: string; note?: string }[];
  usage: string;
};
const PUZZLES: Puzzle[] = [
  {
    id: "maslow",
    title: "マズローの欲求5段階",
    tabEmoji: "🔺",
    intro: "下から順に、5つの欲求をピラミッドにはめてみよう。",
    layout: "pyramid",
    slots: [
      { id: "m5", answer: "自己実現の欲求", note: "唯一の成長欲求" },
      { id: "m4", answer: "承認の欲求" },
      { id: "m3", answer: "所属と愛の欲求" },
      { id: "m2", answer: "安全の欲求" },
      { id: "m1", answer: "生理的欲求" },
    ],
    usage:
      "【いつ使う?】人の「やる気」の土台を考えるとき。下位の欲求がある程度満たされると上位へ進む。試験では順番の並べ替えと「自己実現だけが成長欲求」が頻出。",
  },
  {
    id: "arch",
    title: "スーパーのアーチモデル",
    tabEmoji: "🌉",
    intro: "キャリアを支える2本の柱と、てっぺんのかなめ石をはめよう。",
    layout: "arch",
    slots: [
      { id: "a3", answer: "自己概念", note: "かなめ石" },
      { id: "a1", answer: "個人(心理的特性)", note: "左の柱: 欲求・興味・価値観・能力" },
      { id: "a2", answer: "社会(経済・環境)", note: "右の柱: 労働市場・地域・家庭" },
    ],
    usage:
      "【いつ使う?】「キャリアは個人と社会の相互作用でつくられる」ことを説明するとき。柱が個人と社会、アーチのかなめ石が自己概念。ライフキャリアレインボーとセットで覚える。",
  },
  {
    id: "bronfen",
    title: "ブロンフェンブレナーの生態学的システム",
    tabEmoji: "🎯",
    intro: "内側から順に、4つのシステムをはめてみよう。",
    layout: "rings",
    slots: [
      { id: "b1", answer: "マイクロシステム", note: "家庭・学校など直接の環境" },
      { id: "b2", answer: "メゾシステム", note: "マイクロ同士のつながり" },
      { id: "b3", answer: "エクソシステム", note: "親の職場など間接的な環境" },
      { id: "b4", answer: "マクロシステム", note: "文化・制度・価値観" },
    ],
    usage:
      "【いつ使う?】人の発達を「環境との相互作用」で見るとき。子どもの発達やキャリア教育の文脈で登場。内→外(マイクロ→メゾ→エクソ→マクロ)の順番が試験ポイント(時間の流れはクロノシステム)。",
  },
  {
    id: "cone",
    title: "シャインのキャリア・コーン(組織の3次元)",
    tabEmoji: "🎪",
    intro: "組織の中の3つの移動方向をはめてみよう。",
    layout: "cone",
    slots: [
      { id: "c1", answer: "垂直方向(階層)", note: "昇進・昇格で上へ" },
      { id: "c2", answer: "水平方向(職能)", note: "営業→人事など部門間の移動" },
      { id: "c3", answer: "中心方向(部内者化)", note: "中枢・コアメンバーへ近づく" },
    ],
    usage:
      "【いつ使う?】組織の中のキャリアの動きを説明するとき。昇進(上)だけがキャリアではなく、横の異動や「中心に近づく」動きもキャリア発達。シャインの組織内キャリア発達の代表図。",
  },
];

export function anaumeGamePage(): string {
  const tabs = PUZZLES.map(
    (p, i) => `<button type="button" class="anaume-tab${i === 0 ? " is-active" : ""}" data-anaume-tab="${esc(p.id)}">${p.tabEmoji} ${esc(p.title)}</button>`
  ).join("");

  const boards = PUZZLES.map((p, i) => {
    const slots = p.slots
      .map(
        (s) => `<button type="button" class="anaume-slot" data-slot data-answer="${esc(s.answer)}">
          <span class="anaume-slot__q">?</span>
          ${s.note ? `<span class="anaume-slot__note">${esc(s.note)}</span>` : ""}
        </button>`
      )
      .join("");
    const chips = [...p.slots]
      .map((s) => s.answer)
      .sort()
      .map((a) => `<button type="button" class="anaume-chip" data-chip="${esc(a)}">${esc(a)}</button>`)
      .join("");
    return `<div class="anaume-board anaume-board--${esc(p.layout)}"${i === 0 ? "" : " hidden"} data-anaume-board="${esc(p.id)}">
      <p class="anaume-board__intro">${esc(p.intro)}</p>
      <div class="anaume-board__slots">${slots}</div>
      <div class="anaume-board__chips">${chips}</div>
      <p class="anaume-board__feedback" data-feedback>まず「?」の枠をタップ → 入る言葉をタップしてね</p>
      <div class="anaume-board__usage" data-usage hidden>
        <p>🎉 完成! ${esc(p.usage)}</p>
      </div>
    </div>`;
  }).join("");

  const body = `
<section class="section">
  <div class="container container--narrow">
    ${EditorialSectionHeader({
      en: "MINI GAME 04",
      title: "🧩 理論の図 あなうめゲーム",
      lede: "試験に出る4つの図を、穴埋めで完成させよう。完成すると「この図はいつ使うのか」の解説が読めるよ。",
    })}
    ${CharacterGuide("sunny", "図は「自分ではめた」ものほど忘れないの。まちがえても大丈夫、何回でもどうぞ。")}
    <div class="anaume" id="anaume-game">
      <div class="anaume__tabs">${tabs}</div>
      ${boards}
    </div>
  </div>
</section>
<script src="/js/game-anaume.js" defer></script>`;
  return renderPage({
    title: "理論の図あなうめゲーム(マズロー・アーチモデルなど)",
    description:
      "マズローの欲求5段階、スーパーのアーチモデル、ブロンフェンブレナーの生態学的システム、シャインのキャリア・コーンを穴埋めで覚えるミニゲーム。",
    path: "/games/anaume/",
    body,
    crumbs: [
      { name: "ホーム", url: "/" },
      { name: "ミニゲーム", url: "/games/" },
      { name: "あなうめゲーム" },
    ],
  });
}
