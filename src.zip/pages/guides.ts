import { renderPage } from "../components/Layout";
import { DisclosureBox } from "../components/PrLabel";
import { UpdatedDate } from "../components/UpdatedDate";
import { RelatedContents, type RelatedItem } from "../components/RelatedContents";
import { AuthorProfile } from "../components/AuthorProfile";
import { esc } from "../lib/html";
import { SITE } from "../lib/site";

type GuideSection = { heading: string; paragraphs: string[]; list?: string[] };

type Guide = {
  path: string;
  title: string;
  description: string;
  lede: string;
  updatedAt: string;
  infoCheckedAt?: string;
  sections: GuideSection[];
  related: RelatedItem[];
};

function guidePage(g: Guide): string {
  const body = `
<article class="container container--article guide-article">
  <header class="article-header">
    <p class="article-header__meta"><span class="article-card__category">養成講座ガイド</span></p>
    <h1>${esc(g.title)}</h1>
    <p class="article-header__lede">${esc(g.lede)}</p>
    ${UpdatedDate({ updatedAt: g.updatedAt, infoCheckedAt: g.infoCheckedAt })}
  </header>

  ${DisclosureBox({
    isPr: false,
    receivedCompensation: false,
    containsAffiliateLinks: false,
    paidByAuthor: true,
  })}

  <nav class="review-toc" aria-label="この記事の目次">
    <h2>この記事でわかること</h2>
    <ol>
      ${g.sections.map((s, i) => `<li><a href="#sec-${i}">${esc(s.heading)}</a></li>`).join("")}
    </ol>
  </nav>

  ${g.sections
    .map(
      (s, i) => `<section class="guide-section" id="sec-${i}">
    <h2>${esc(s.heading)}</h2>
    ${s.paragraphs.map((p) => `<p>${esc(p)}</p>`).join("")}
    ${s.list ? `<ul>${s.list.map((li) => `<li>${esc(li)}</li>`).join("")}</ul>` : ""}
  </section>`
    )
    .join("")}

  <aside class="notice-box">
    <p>各学校の料金・日程・給付金などの情報は変更される可能性があります。申込み前に必ず公式サイトとハローワークで最新情報をご確認ください。</p>
  </aside>

  ${RelatedContents(g.related, "あわせて読みたい")}
  ${AuthorProfile(true)}
</article>`;

  return renderPage({
    title: g.title,
    description: g.description,
    path: g.path,
    activeNav: "/schools/",
    ogType: "article",
    crumbs: [
      { name: "ホーム", url: "/" },
      { name: "養成学校一覧", url: "/schools/" },
      { name: g.title },
    ],
    structuredData: [
      {
        "@context": "https://schema.org",
        "@type": "Article",
        headline: g.title,
        description: g.description,
        dateModified: g.updatedAt,
        author: { "@type": "Person", name: SITE.author.name },
        mainEntityOfPage: `${SITE.baseUrl}${g.path}`,
      },
    ],
    body,
  });
}

const COMMON_RELATED: RelatedItem[] = [
  { type: "学校", title: "養成学校一覧", url: "/schools/" },
  { type: "比較", title: "養成学校を比較する", url: "/schools/compare/" },
  {
    type: "受講体験",
    title: "運営者の受講記録(地域連携プラットフォーム)",
    url: "/school-reviews/chiiki-renkei-platform/",
  },
];

export function howToChoosePage(): string {
  return guidePage({
    path: "/school-guides/how-to-choose/",
    title: "養成学校の選び方 — 比べる前に決めておく3つのこと",
    description:
      "キャリアコンサルタント養成学校の選び方を初学者向けに解説。学校を比べる前に決めておきたい条件と、公式サイトで確認すべき項目を整理します。",
    lede: "「おすすめはどこ?」と探し始める前に、自分の条件を決めておくと迷いにくくなります。",
    updatedAt: "2026-07-11",
    infoCheckedAt: "2026-07-11",
    sections: [
      {
        heading: "まず知っておくこと:どの養成講習も「厚生労働大臣認定」",
        paragraphs: [
          "国家試験の受験資格につながる養成講習は、厚生労働大臣の認定を受けた講習です。つまり「認定されているかどうか」では差がつきません。差がつくのは、受講形式・日程・費用・サポートなど、自分の暮らしとの相性です。",
          "認定講習の一覧は厚生労働省のサイトで公開されています。検討している講座が認定講習かどうかは、必ず一次情報で確認しましょう。",
        ],
      },
      {
        heading: "決めておくこと1:いつまでに、どのくらいのペースで学ぶか",
        paragraphs: [
          "受験したい試験の回から逆算すると、選べるコースが絞られます。短期集中は早く修了できるぶん1回の学習量が多く、ゆっくりコースは両立しやすいぶん期間が長くなります。",
          "仕事や育児がある人は、「週に何時間なら勉強に使えるか」を先に見積もっておくと現実的な判断ができます。",
        ],
      },
      {
        heading: "決めておくこと2:オンラインか、通学か",
        paragraphs: [
          "移動時間がないオンラインは両立に有利ですが、自宅で集中できる環境(時間帯・場所・家族の協力)が必要です。通学は強制力があり仲間もできやすい一方、通学時間と交通費がかかります。",
          "ハイブリッド型もあります。詳しくはオンライン講座の選び方の記事にまとめています。",
        ],
      },
      {
        heading: "決めておくこと3:総費用の上限(試験対策まで含めて)",
        paragraphs: [
          "見るべきは受講料だけではありません。入学金・教材費、そして養成講習とは別料金になることが多い「試験対策講座」まで含めた総費用で考えます。",
          "専門実践教育訓練給付金の対象講座なら自己負担を抑えられる可能性がありますが、給付額は雇用保険の加入状況など個人の条件によって異なります。必ずハローワークで自分の場合の条件を確認してください。",
        ],
      },
      {
        heading: "公式サイトで確認するチェックリスト",
        paragraphs: ["候補が2〜3校に絞れたら、次の項目を公式サイトで確認します。"],
        list: [
          "受講形式(オンライン/通学/ハイブリッド)とオンライン完結の可否",
          "受講期間と日程(平日・土日・夜間)",
          "受講料・入学金・教材費",
          "教育訓練給付の対象かどうか",
          "振替制度(何時間まで・無料か)",
          "修了要件と課題の量",
          "ロールプレイの実施方法",
          "試験対策講座の料金体系",
          "資格取得後のサポートやコミュニティ",
        ],
      },
      {
        heading: "最後に:口コミより「自分の条件」",
        paragraphs: [
          "他の人にとって最高の学校が、自分にも合うとは限りません。当サイトでも、公式情報・受講者本人の体験・運営者の考察を分けて表示しています。体験談は「その人の条件での話」として読み、最終判断は自分の条件と公式情報で行うのがおすすめです。",
        ],
      },
    ],
    related: COMMON_RELATED,
  });
}

export function onlineGuidePage(): string {
  return guidePage({
    path: "/school-guides/online/",
    title: "オンライン養成講座の選び方 — 自宅で学ぶ前に確認すること",
    description:
      "キャリアコンサルタント養成講座をオンラインで受講する前に確認したいポイント。ライブ型と録画型の違い、ロールプレイの実施方法、通信環境などを解説します。",
    lede: "「オンライン」とひとことで言っても、中身は学校によって大きく違います。",
    updatedAt: "2026-07-11",
    infoCheckedAt: "2026-07-11",
    sections: [
      {
        heading: "ライブ型と録画(オンデマンド)型の違い",
        paragraphs: [
          "ライブ型は決まった日時にZoomなどで参加する形式で、その場で質問でき、グループワークやロールプレイも実施しやすいのが特徴です。録画型は好きな時間に視聴できますが、演習は別途ライブやスクーリングで行う設計になっていることが多いです。",
          "養成講習は演習が重要な位置を占めるため、「すべて録画だけで修了できる」講習は基本的にありません。演習部分がどの形式で行われるかを必ず確認しましょう。",
        ],
      },
      {
        heading: "ロールプレイはオンラインでどうやるのか",
        paragraphs: [
          "多くのオンライン講習では、Zoomのブレイクアウトルームなどで少人数に分かれてロールプレイを行います。カメラ・マイクは必須で、表情が見える環境が求められます。",
          "自宅で「声を出して練習できるか」は意外と重要です。家族がいる時間帯の受講になる場合、場所の確保を先に考えておきましょう。",
        ],
      },
      {
        heading: "受講前に確認する環境チェック",
        paragraphs: ["次の項目を確認しておくと、初日に慌てません。"],
        list: [
          "安定した通信環境(ビデオ通話が途切れないか)",
          "カメラ・マイク付きのパソコン(スマホのみでの受講可否は学校に確認)",
          "2〜8時間の講習中、集中できる場所",
          "欠席・途中退席時の振替ルール",
          "録画補講の有無(体調不良や子どもの発熱への備え)",
        ],
      },
      {
        heading: "オンラインに向く人・向かない可能性がある人",
        paragraphs: [
          "移動時間を節約したい人、近くに通学拠点がない人、家庭の都合で外出が難しい人にはオンラインが有力な選択肢になります。",
          "一方で、自宅では集中しにくい人や、対面での練習に安心感がある人は、通学やハイブリッドも検討する価値があります。これは優劣ではなく相性の問題です。",
        ],
      },
    ],
    related: COMMON_RELATED,
  });
}

export function workingMothersGuidePage(): string {
  return guidePage({
    path: "/school-guides/working-mothers/",
    title: "子育て中・仕事をしながら通いやすい学校の選び方",
    description:
      "子育てや仕事と両立しながらキャリアコンサルタント養成講座に通うための学校選び。振替制度・オンライン・課題量など、両立のための確認ポイントを解説します。",
    lede: "「休まず全部出席できる前提」で選ぶと、子どもの発熱ひとつで計画が崩れます。崩れても続けられる学校を選びましょう。",
    updatedAt: "2026-07-11",
    infoCheckedAt: "2026-07-11",
    sections: [
      {
        heading: "両立の最大の敵は「欠席できない仕組み」",
        paragraphs: [
          "養成講習には出席時間の要件があり、欠席が多いと修了できません。だからこそ、欠席が起きる前提で「振替制度」を最初に確認します。何時間まで・無料か・別日程に振り替えやすいかは学校によって差があります。",
          "運営者が受講している講習では、80時間のうち16時間まで無料振替という制度がありました(2026年7月確認時点の公式サイト情報。最新の条件は公式サイトで確認してください)。",
        ],
      },
      {
        heading: "確認したい条件リスト",
        paragraphs: ["子育て・仕事との両立の観点では、次の条件を確認します。"],
        list: [
          "振替制度(何時間まで・無料か・どの日程に振替できるか)",
          "オンライン受講の可否(送迎や移動時間を減らせるか)",
          "土日コース・平日コース・夜間コースの選択肢",
          "1回の講習時間(長時間拘束か、小分けか)",
          "課題の量と提出方法(在宅で深夜でも提出できるか)",
          "急な欠席時の録画補講の有無",
          "試験対策講座の日程の柔軟さ",
        ],
      },
      {
        heading: "週あたりの学習時間を見積もる",
        paragraphs: [
          "講習時間のほかに、通信課題・予習復習の時間が必要です。合計の学習時間はコースや個人差で大きく変わるため、ここで断定はしませんが、「講習+数時間の自習」が毎週続く前提でスケジュールを組むのが現実的です。",
          "家族との調整は先手が肝心です。講習日程が出たら、先にカレンダーに入れて共有してしまいましょう。",
        ],
      },
      {
        heading: "完璧を目指さない",
        paragraphs: [
          "子育て中の受講は、予定どおりに進まないことが前提です。振替制度・録画・仲間のノートに助けられながら修了する人はたくさんいます。「休んだら終わり」ではない学校を選ぶこと自体が、いちばんの両立対策です。",
        ],
      },
    ],
    related: COMMON_RELATED,
  });
}

export function trainingVsExamPrepPage(): string {
  return guidePage({
    path: "/school-guides/training-and-exam-preparation/",
    title: "養成講習と試験対策講座の違い — 費用計画の前に知っておく",
    description:
      "キャリアコンサルタントの養成講習と試験対策講座の役割の違いを解説。受験資格と合格対策は別物です。総費用の考え方も整理します。",
    lede: "「養成講習を修了すれば合格できる」とは限りません。2つの講座は役割が違います。",
    updatedAt: "2026-07-11",
    infoCheckedAt: "2026-07-11",
    sections: [
      {
        heading: "養成講習の役割:受験資格を得る",
        paragraphs: [
          "厚生労働大臣認定の養成講習は、国家試験の受験資格を得るためのルートのひとつです(実務経験による受験ルートもあります)。カウンセリングの基礎やキャリア理論を体系的に学び、修了要件を満たすことが目的です。",
          "つまり養成講習は「試験に合格させるための講座」として設計されているとは限りません。学校によっては試験対策的な内容を含む場合もありますが、それは各校の設計次第です。",
        ],
      },
      {
        heading: "試験対策講座の役割:学科・論述・面接の得点力を上げる",
        paragraphs: [
          "試験対策講座は、過去問演習・論述の書き方・面接(ロールプレイ)の練習など、試験で点を取るための訓練に特化した講座です。養成講習とセットの学校もあれば、別料金の学校も、試験対策専門のスクールもあります。",
          "運営者が受講している学校では、試験対策講座は養成講習と別講座で、受講生・卒業生価格が設定されていました(2026年7月確認時点の公式サイト情報)。",
        ],
      },
      {
        heading: "費用計画は「養成講習+試験対策」の合計で",
        paragraphs: [
          "学校を比較するときに受講料だけを見ると、試験対策が含まれる学校と含まれない学校を同じ土俵で比べてしまうことになります。",
          "「試験対策が受講料に含まれるか」「含まれない場合はいくらか」まで確認して、合計金額で比較しましょう。当サイトの学校ページでも、この項目を分けて表示しています。",
        ],
      },
      {
        heading: "独学での試験対策という選択肢",
        paragraphs: [
          "試験対策講座を使わず、過去問と市販教材で合格を目指す人もいます。学科は独学しやすい一方、論述の添削と面接の練習相手は独学では確保しにくいのが実情です。養成講習の同期と練習会を組むなど、工夫している人も多いようです。",
          "当サイトのことば図鑑や1問1答も、すきま時間の学科対策として使ってもらえるように作っています。",
        ],
      },
    ],
    related: COMMON_RELATED,
  });
}
