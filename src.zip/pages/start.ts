import { renderPage } from "../components/Layout";
import { EditorialSectionHeader } from "../components/EditorialSectionHeader";
import { RelatedContents } from "../components/RelatedContents";
import { AuthorProfile } from "../components/AuthorProfile";
import { UpdatedDate } from "../components/UpdatedDate";

/** はじめての学習ルート(試験対策の入口ページ) */
export function startPage(): string {
  const body = `
<article class="container container--article guide-article">
  <header class="article-header">
    <p class="article-header__meta"><span class="article-card__category">はじめての方へ</span></p>
    <h1>初学者の学習ルート — どこから勉強すればいいかわからない方へ</h1>
    <p class="article-header__lede">養成講座のテキストは、知らない言葉だらけで当たり前。この順番で少しずつ進めれば大丈夫です。</p>
    ${UpdatedDate({ updatedAt: "2026-07-11" })}
  </header>

  <section class="guide-section">
    <h2>ステップ1:試験の全体像を知る</h2>
    <p>国家資格キャリアコンサルタント試験は、おもに「学科試験」「実技試験(論述・面接)」で構成されます。試験の実施団体・出題範囲・日程などの正式な情報は、必ず試験機関の公式サイトで確認してください(制度は変わることがあります)。</p>
    <p>最初のうちは「学科・論述・面接の3つがある」ことと、「どれも同じ理論・同じ姿勢につながっている」ことだけ押さえれば十分です。</p>
  </section>

  <section class="guide-section">
    <h2>ステップ2:よく出る用語を知る</h2>
    <p>テキストを読んで分からない言葉に出会ったら、<a href="/terms/">ことば図鑑</a>で調べてください。「ひとことで」「たとえで」「試験用の正式な説明で」の3段階で書いてあるので、分かるところまで読めばOKです。</p>
    <p>知らない言葉を全部その場で覚えようとしないこと。「見たことがある」状態を先に作るのがコツです。</p>
  </section>

  <section class="guide-section">
    <h2>ステップ3:理論家同士の違いを知る</h2>
    <p>スーパーとシャイン、ロジャーズとクランボルツ。名前と理論が混ざってきたら、<a href="/theorists/">理論家図鑑</a>の「混同しやすい理論家」の項目を見てください。違いで覚えると忘れにくくなります。</p>
  </section>

  <section class="guide-section">
    <h2>ステップ4:1問1答で確認する</h2>
    <p>用語ページの下にある○×問題と、トップページの<a href="/#daily">今日の3分学習</a>で、覚えたことを小さく確認します。間違えても大丈夫。間違えた言葉のページに戻れば、それが復習になります。</p>
  </section>

  <section class="guide-section" id="exam-links">
    <h2>ステップ5:論述と面接につなげる</h2>
    <p>学科で覚えた「傾聴」「感情の反映」「ラポール」は、そのまま論述・面接(ロールプレイ)で使う道具です。用語ページの「子育て・仕事で考えると」の欄は、面接で自然な応答をするための引き出しにもなります。</p>
    <p>論述・面接の専用コンテンツは現在準備中です。まずは<a href="/terms/keicho/">傾聴</a>・<a href="/terms/kanjo-no-hanei/">感情の反映</a>・<a href="/terms/rapport/">ラポール</a>の3つから読むのがおすすめです。</p>
  </section>

  ${EditorialSectionHeader({
    en: "NEXT",
    title: "勉強と並行して考えること",
  })}
  <section class="guide-section">
    <p>養成講座選びで迷っている人は<a href="/school-guides/how-to-choose/">養成学校の選び方</a>へ。資格を取ったあとの働き方が気になる人は<a href="/careers/">資格取得後の働き方</a>へ。勉強のモチベーションは「その先」が見えると保ちやすくなります。</p>
  </section>

  ${RelatedContents(
    [
      { type: "用語", title: "ことば図鑑(用語一覧)", url: "/terms/" },
      { type: "理論家", title: "理論家図鑑", url: "/theorists/" },
      { type: "ガイド", title: "養成学校の選び方", url: "/school-guides/how-to-choose/" },
      { type: "働き方", title: "資格取得後の働き方", url: "/careers/" },
    ],
    "次に読む"
  )}
  ${AuthorProfile(true)}
</article>`;

  return renderPage({
    title: "初学者の学習ルート(試験対策の入口)",
    description:
      "キャリアコンサルタント試験の勉強をどこから始めればいいかわからない初学者向けに、5ステップの学習ルートを紹介します。",
    path: "/start/",
    activeNav: "/start/",
    crumbs: [{ name: "ホーム", url: "/" }, { name: "初学者の学習ルート" }],
    body,
  });
}
