import { renderPage } from "../components/Layout";
import { EditorialSectionHeader } from "../components/EditorialSectionHeader";
import { esc } from "../lib/html";
import { schools } from "../data/schools/index";

/**
 * 学校比較ページ。
 * 最大3校の選択は URL クエリ(?schools=a,b,c)またはローカルストレージで保持し、
 * クライアント側 JS (compare.js) が /data/schools.json を読み込んで
 * 「比較項目ごとのカード」を描画する(スマホで巨大な横長表にしない)。
 * 総合順位・根拠のない点数は付けない。
 */
export function comparePage(): string {
  const userTypes = [
    { label: "オンラインで完結したい人", point: "受講形式と「オンライン完結の可否」を確認。ロールプレイもオンラインで実施されるかが重要です。" },
    { label: "短期間で修了したい人", point: "受講期間と週あたりの授業ペースを確認。短期コースは1回の学習量が多くなります。" },
    { label: "土日に学びたい人", point: "土日コースの有無と、欠席時の振替先(平日に振替できるか)を確認。" },
    { label: "夜間に学びたい人", point: "夜間コースの有無と終了時刻を確認。家庭の時間と重ならないかも大切です。" },
    { label: "通学で学びたい人", point: "通学拠点の場所と、通学コースの開講頻度を確認。" },
    { label: "振替制度を重視する人", point: "振替できる時間数・回数・費用を確認。「何時間まで無料か」は学校で差が出ます。" },
    { label: "試験対策までまとめて受けたい人", point: "試験対策が受講料に含まれるか、別料金かを確認。総費用が変わります。" },
    { label: "資格取得後のつながりを重視する人", point: "卒業生コミュニティや就業支援・独立支援の有無を確認。" },
    { label: "子育てと両立したい人", point: "振替制度・録画対応・課題量・急な欠席への対応を確認。詳しくは「子育て中の学校選び」へ。" },
    { label: "費用を重視する人", point: "受講料だけでなく入学金・教材費・試験対策費まで含めた総費用で比べる。給付金の自己負担額は個人の条件で異なるため、断定的な金額をあてにしない。" },
  ];

  const body = `
<div class="container">
  ${EditorialSectionHeader({
    en: "COMPARE",
    title: "養成学校を比較する",
    lede: "最大3校まで選んで、項目ごとに並べて確認できます。総合順位や点数は付けません。「どこが一番良いか」ではなく「自分の暮らしに合うのはどこか」で見てください。",
    headingLevel: 1,
  })}

  <aside class="notice-box">
    <p>比較条件(コース・時期・キャンペーン)が異なる学校を、同じ条件であるかのように比較しないようご注意ください。料金・日程・給付金は変更される可能性があります。給付金利用後の自己負担額は個人の条件によって異なるため、このページでは表示しません。申込み前に必ず各校の公式サイトをご確認ください。</p>
  </aside>

  <section class="compare-picker" aria-label="比較する学校の選択">
    <h2 class="school-section__title">比較する学校を選ぶ(最大3校)</h2>
    <div class="compare-picker__list" data-compare-picker>
      ${schools
        .map(
          (s) => `<label class="compare-picker__item">
        <input type="checkbox" value="${esc(s.slug)}" data-compare-checkbox>
        <span>${esc(s.name)}</span>
        ${s.informationStatus === "unverified" ? '<span class="info-label info-label--unverified">調査中</span>' : ""}
      </label>`
        )
        .join("")}
    </div>
  </section>

  <section class="compare-result" aria-live="polite">
    <h2 class="school-section__title">比較結果</h2>
    <p class="compare-result__empty" data-compare-empty>上のリストから学校を選ぶと、ここに項目ごとの比較が表示されます。</p>
    <div data-compare-result></div>
  </section>

  <section class="compare-guide">
    ${EditorialSectionHeader({
      en: "HOW TO READ",
      title: "利用者別の見かた",
      lede: "順位の代わりに、目的別に「どこを見るか」を整理しました。",
    })}
    <dl class="compare-guide__list">
      ${userTypes
        .map(
          (u) => `<div><dt>${esc(u.label)}</dt><dd>${esc(u.point)}</dd></div>`
        )
        .join("")}
    </dl>
    <p class="section__more"><a href="/school-guides/working-mothers/">子育て中・仕事をしながら通いやすい学校の選び方 →</a></p>
  </section>
</div>
<script src="/js/compare.js" defer></script>
<script src="/js/compare-page.js" defer></script>`;

  return renderPage({
    title: "養成学校比較(最大3校)",
    description:
      "キャリアコンサルタント養成学校を最大3校まで選んで、受講形式・期間・料金・給付金・振替制度・試験対策・資格取得後の支援などの項目ごとに比較できます。",
    path: "/schools/compare/",
    activeNav: "/schools/",
    crumbs: [
      { name: "ホーム", url: "/" },
      { name: "養成学校一覧", url: "/schools/" },
      { name: "学校比較" },
    ],
    body,
  });
}
