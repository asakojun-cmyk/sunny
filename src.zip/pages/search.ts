import { renderPage } from "../components/Layout";
import { EditorialSectionHeader } from "../components/EditorialSectionHeader";
import { SiteSearch } from "../components/SiteSearch";

/**
 * サイト内検索ページ。
 * /search-index.json をクライアント側 JS (search.js) が読み込み、
 * 用語名・読み方・理論家名・学校名・運営会社名・記事タイトル・関連キーワードを対象に検索する。
 * 検索結果にはコンテンツの種類(用語/理論家/学校/受講体験/ガイド/働き方)を表示する。
 */
export function searchPage(): string {
  const body = `
<div class="container container--narrow">
  ${EditorialSectionHeader({
    en: "SEARCH",
    title: "サイト内検索",
    lede: "用語・理論家・学校名・記事タイトルから探せます。ひらがなでも検索できます。",
    headingLevel: 1,
  })}
  ${SiteSearch({ heading: "今、わからない言葉は何ですか?", large: true, showPopular: true })}
  <section class="search-results" aria-live="polite">
    <p class="search-results__status" data-search-status>キーワードを入力してください。</p>
    <ul class="search-results__list" data-search-results></ul>
  </section>
</div>
<script src="/js/search.js" defer></script>`;

  return renderPage({
    title: "サイト内検索",
    description:
      "キャリコンことば図鑑のサイト内検索。試験用語・理論家・養成学校・受講体験・ガイド記事を横断して検索できます。",
    path: "/search/",
    crumbs: [{ name: "ホーム", url: "/" }, { name: "検索" }],
    body,
  });
}
