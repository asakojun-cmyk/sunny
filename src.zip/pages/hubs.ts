import { renderPage } from "../components/Layout";
import { EditorialSectionHeader } from "../components/EditorialSectionHeader";
import { CharacterGuide } from "../components/Characters";
import { RelatedContents } from "../components/RelatedContents";
import { UpdatedDate } from "../components/UpdatedDate";
import { PastQuestions } from "../components/PastQuestions";
import { esc } from "../lib/html";
import { PAST_EXAM_SOURCES } from "../lib/site";
import { terms } from "../data/terms";

/** ☂️ 労働法・統計・制度ハブ */
export function lawsPage(): string {
  const seido = terms.filter((t) => t.category === "制度・支援");
  const body = `
<div class="container container--article guide-article">
  ${EditorialSectionHeader({
    en: "LAW & DATA",
    title: "☂️ 労働法・統計・制度",
    lede: "苦手になりやすい分野こそ、正確さが命。当サイトは一次資料(官公庁の公式情報)で確認できた内容だけを掲載します。",
    headingLevel: 1,
  })}
  ${UpdatedDate({ updatedAt: "2026-07-11", infoCheckedAt: "2026-07-11" })}

  ${CharacterGuide("moyan", "法律とか統計って、数字も言葉もかたくて苦手…")}
  ${CharacterGuide(
    "sunny",
    "わかるよ。でもここは「暗記」より「どこに正しい情報があるか」を知るのが先。一次資料への入口を用意したよ。"
  )}

  <section class="guide-section">
    <h2>いま読める用語(制度・支援)</h2>
    <ul>
      ${seido
        .map(
          (t) =>
            `<li><a href="/terms/${esc(t.slug)}/">${esc(t.name)}</a> — ${esc(t.oneLiner)}</li>`
        )
        .join("")}
    </ul>
    <p>労働基準法・育児介護休業法・雇用保険(教育訓練給付)などの個別解説は、一次資料の確認を終えたものから順次追加していきます。</p>
  </section>

  <section class="guide-section">
    <h2>一次資料への入口(ここをブックマーク)</h2>
    <p>試験勉強で法律・統計・制度に迷ったら、まとめサイトではなく、次の公式サイトで原文・原データを確認するのがいちばん確実です。</p>
    <ul>
      <li><a href="https://www.mhlw.go.jp/" rel="noopener nofollow" target="_blank">厚生労働省</a> — 労働法・雇用施策・キャリア形成支援・能力開発基本調査など</li>
      <li><a href="https://elaws.e-gov.go.jp/" rel="noopener nofollow" target="_blank">e-Gov法令検索</a> — 労働基準法などの法令の原文</li>
      <li><a href="https://www.stat.go.jp/" rel="noopener nofollow" target="_blank">総務省統計局</a> — 労働力調査(完全失業率など)</li>
      <li><a href="https://www.job-card.mhlw.go.jp/" rel="noopener nofollow" target="_blank">マイジョブ・カード(厚生労働省)</a> — ジョブ・カードの作成・活用</li>
    </ul>
    <p class="page-guide">※統計の数値は更新されます。当サイトでは古くなりやすい数値の断定的な掲載を避け、出典への案内を優先しています。</p>
  </section>

  ${PastQuestions("労働関係法令・社会保障制度")}

  ${RelatedContents(
    [
      { type: "用語", title: "ことば図鑑(用語一覧)", url: "/terms/" },
      { type: "ガイド", title: "初学者の学習ルート", url: "/start/" },
      { type: "試験", title: "学科・論述・面接", url: "/exam/" },
    ],
    "あわせて読みたい"
  )}
</div>`;
  return renderPage({
    title: "労働法・統計・制度(一次資料への入口)",
    description:
      "キャリアコンサルタント試験の労働法・統計・制度分野を学ぶための入口。厚生労働省・e-Gov・統計局など一次資料へのリンクと、制度用語のやさしい解説。",
    path: "/laws/",
    activeNav: "/terms/",
    crumbs: [{ name: "ホーム", url: "/" }, { name: "労働法・統計・制度" }],
    body,
  });
}

/** 🌈 学科・論述・面接ハブ */
export function examPage(): string {
  const body = `
<div class="container container--article guide-article">
  ${EditorialSectionHeader({
    en: "EXAM",
    title: "🌈 学科・論述・面接",
    lede: "国家資格キャリアコンサルタント試験の全体像と、公式の過去問への入口をまとめました。",
    headingLevel: 1,
  })}
  ${UpdatedDate({ updatedAt: "2026-07-11", infoCheckedAt: "2026-07-11" })}

  ${CharacterGuide("moyan", "試験って、なにがあるの?ぜんぶ一度に受けるの?")}
  ${CharacterGuide(
    "sunny",
    "大きく分けて「学科試験」と「実技試験(論述+面接)」があるよ。実施しているのは2つの登録試験機関。学科は共通で、実技は機関ごとに特徴があるんだ。"
  )}

  <section class="guide-section">
    <h2>試験の全体像</h2>
    <ul>
      <li><strong>学科試験</strong> — マークシート形式。理論・法律・統計・倫理など幅広く出題されます。</li>
      <li><strong>実技試験(論述)</strong> — 事例を読んで記述する筆記試験。</li>
      <li><strong>実技試験(面接)</strong> — ロールプレイと口頭試問。傾聴や関係構築の姿勢が見られます。</li>
    </ul>
    <p>出題数・合格基準・日程などの正式な情報は、必ず下の試験機関の公式サイトで最新の受験案内を確認してください(制度は変わることがあります)。</p>
  </section>

  <section class="guide-section">
    <h2>2つの試験機関(公式サイト・過去問)</h2>
    <ul>
      ${PAST_EXAM_SOURCES.map(
        (s) =>
          `<li><a href="${esc(s.url)}" rel="noopener nofollow" target="_blank">${esc(s.label)}</a></li>`
      ).join("")}
    </ul>
    <p>どちらの機関でも過去問題が公開されています。過去問の本文は著作権保護のため当サイトには転載していませんが、各用語ページに「過去問で確認する」の案内を付けています。</p>
  </section>

  <section class="guide-section">
    <h2>このサイトでの勉強のしかた</h2>
    <ol>
      <li><a href="/start/">学習ルート</a>で全体の流れをつかむ</li>
      <li><a href="/terms/">ことば図鑑</a>と<a href="/theorists/">理論家図鑑</a>で用語を固める(学科対策)</li>
      <li>各ページの1問1答(当サイトオリジナル)で確認する</li>
      <li>公式の過去問PDFで、実際の問われ方を体験する</li>
      <li><a href="/terms/keicho/">傾聴</a>・<a href="/terms/kanjo-no-hanei/">感情の反映</a>・<a href="/terms/rapport/">ラポール</a>を面接(ロールプレイ)につなげる</li>
    </ol>
  </section>

  ${CharacterGuide(
    "sunny",
    "論述・面接の専用コンテンツは、運営者の受講が進むのに合わせて増やしていく予定だよ。"
  )}

  ${RelatedContents(
    [
      { type: "ガイド", title: "初学者の学習ルート", url: "/start/" },
      { type: "用語", title: "ことば図鑑(用語一覧)", url: "/terms/" },
      { type: "ガイド", title: "養成講習と試験対策講座の違い", url: "/school-guides/training-and-exam-preparation/" },
    ],
    "あわせて読みたい"
  )}
</div>`;
  return renderPage({
    title: "学科・論述・面接(試験の全体像と公式過去問)",
    description:
      "国家資格キャリアコンサルタント試験の学科・論述・面接の全体像と、2つの試験機関の公式過去問ページへの入口をまとめました。",
    path: "/exam/",
    activeNav: "/start/",
    crumbs: [{ name: "ホーム", url: "/" }, { name: "学科・論述・面接" }],
    body,
  });
}
