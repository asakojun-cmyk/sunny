import { renderPage } from "../components/Layout";
import { EditorialSectionHeader } from "../components/EditorialSectionHeader";
import { CharacterGuide } from "../components/Characters";

/**
 * お守りページ:
 * - 試験日カウントダウン(この端末に保存)
 * - 分野別の学習チェックリスト(進捗バー+各分野へのリンク)
 * - お守りスマホ待ち受け(2パターン)のダウンロード
 * 試験が近づく(21日以内)と「あとは、うかるだけ。」応援モードに切り替わる。
 */
export function omamoriPage(): string {
  const CHECK_ITEMS = [
    { id: "riron", label: "キャリア理論(スーパー・シャインなど18人)", href: "/theorists/" },
    { id: "counseling", label: "カウンセリング理論・技法のことば", href: "/terms/" },
    { id: "law", label: "労働法・社会保険・制度", href: "/laws/" },
    { id: "toukei", label: "統計・調査(失業率・賃金など)", href: "/terms/rodoryoku-chosa/" },
    { id: "kako-gakka", label: "学科の過去問(公式)を解く", href: "/exam/" },
    { id: "ronjutsu", label: "論述の練習", href: "/exam/" },
    { id: "mensetsu", label: "面接(ロープレ)の練習", href: "/exam/" },
    { id: "game", label: "ミニゲームで最終チェック", href: "/games/" },
  ];

  const body = `
<section class="section">
  <div class="container container--narrow">
    ${EditorialSectionHeader({
      en: "OMAMORI",
      title: "🌥️ がんばるあなたの、お守りページ",
      lede: "試験日までのカウントダウンと学習チェック、そしてスマホのお守り待ち受け。ぜんぶこの端末の中だけに保存されるから、安心して使ってね。",
    })}
    ${CharacterGuide("moyan", "試験の日が近づくと、そわそわしちゃう…")}
    ${CharacterGuide("sunny", "そんなときこそ、このページ。今日の一歩が見えれば、こころは晴れてくるよ。")}

    <!-- カウントダウン -->
    <div class="omamori-card" id="omamori-countdown">
      <h2 class="omamori-card__title">📅 試験日カウントダウン</h2>
      <div class="omamori-date-row">
        <label for="exam-date">試験日:</label>
        <input type="date" id="exam-date">
        <button type="button" class="button button--secondary" data-date-save>保存</button>
      </div>
      <p class="omamori-days" data-days-display hidden>
        試験まで <strong data-days-num></strong>
      </p>
      <p class="omamori-cheer" data-cheer></p>
      <div class="omamori-focus" data-focus hidden>
        <p class="omamori-focus__title">☀️ あとは、うかるだけ。仕上げはここを重点的に!</p>
        <ul>
          <li><a href="/games/match/">🃏 理論家カードあわせ — 人名の入れ替えひっかけ対策</a></li>
          <li><a href="/#daily">✏️ 今日の3問 — 毎日ちがう○×で最終確認</a></li>
          <li><a href="/laws/">⚖️ 法律の数字(93日・5年・65歳…)を見直す</a></li>
          <li><a href="/exam/">📝 公式過去問を、時間を計ってもう1回</a></li>
        </ul>
      </div>
    </div>

    <!-- 学習チェック -->
    <div class="omamori-card">
      <h2 class="omamori-card__title">✅ 学習チェックリスト</h2>
      <p class="omamori-card__note">「ひととおり学んだ」と思えたらチェック。わからないところは、リンクからすぐ復習できるよ。</p>
      <div class="omamori-progress">
        <div class="omamori-progress__bar"><span data-progress-fill></span></div>
        <span class="omamori-progress__label" data-progress-label>0 / ${CHECK_ITEMS.length}</span>
      </div>
      <ul class="omamori-checklist">
        ${CHECK_ITEMS.map(
          (c) => `<li>
          <label><input type="checkbox" data-check="${c.id}"><span>${c.label}</span></label>
          <a class="omamori-checklist__link" href="${c.href}">復習する →</a>
        </li>`
        ).join("")}
      </ul>
    </div>

    <!-- 待ち受けダウンロード -->
    <div class="omamori-card">
      <h2 class="omamori-card__title">📱 お守り待ち受け(無料ダウンロード)</h2>
      <p class="omamori-card__note">スマホの待ち受けにして、モヤンとサニー先生と一緒に試験までがんばろう。画像を長押し(またはボタン)で保存できるよ。</p>
      <div class="omamori-walls">
        <figure class="omamori-wall">
          <img src="/img/omamori-1.png" alt="お守り待ち受け1: いっぽずつで、だいじょうぶ。モヤンとサニー先生" loading="lazy" width="1179" height="2556">
          <figcaption>①コツコツ期に「いっぽずつで、だいじょうぶ。」</figcaption>
          <a class="button button--secondary" href="/img/omamori-1.png" download="omamori-ippozutsu.png">ダウンロード</a>
        </figure>
        <figure class="omamori-wall">
          <img src="/img/omamori-2.png" alt="お守り待ち受け2: あとは、うかるだけ。笑顔のサニー先生とひらめきモヤン" loading="lazy" width="1179" height="2556">
          <figcaption>②試験まぢかに「あとは、うかるだけ。」</figcaption>
          <a class="button button--secondary" href="/img/omamori-2.png" download="omamori-ukarudake.png">ダウンロード</a>
        </figure>
      </div>
    </div>

    <p class="omamori-note">🔒 試験日とチェックは、あなたのスマホ・パソコンの中だけに保存されます(サイトには送信されません)。</p>
  </div>
</section>
<script src="/js/omamori.js" defer></script>`;

  return renderPage({
    title: "お守りページ(試験日カウントダウン&待ち受け)",
    description:
      "キャリアコンサルタント試験までのカウントダウン、分野別の学習チェックリスト、モヤンとサニー先生のお守りスマホ待ち受けを無料配布。",
    path: "/omamori/",
    body,
    crumbs: [{ name: "ホーム", url: "/" }, { name: "お守りページ" }],
  });
}
