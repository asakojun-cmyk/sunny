import { renderPage } from "../components/Layout";
import { EditorialSectionHeader } from "../components/EditorialSectionHeader";
import { CharacterGuide } from "../components/Characters";
import { TheoristAvatar } from "../components/Diagrams";
import { esc } from "../lib/html";
import { matchPairs } from "../data/games";

/** ミニゲームのハブページ */
export function gamesHubPage(): string {
  const body = `
<section class="section">
  <div class="container container--narrow">
    ${EditorialSectionHeader({
      en: "MINI GAMES",
      title: "🎮 3分ミニゲームで覚える",
      lede: "すきま時間の3分で、あそびながら試験の知識を身につけるコーナー。むずかしい勉強の前の準備運動にもどうぞ。",
    })}
    ${CharacterGuide("sunny", "勉強は「たのしい」がいちばんの近道。まずは1回、あそんでみてね。")}

    <div class="game-list">
      <a class="game-card-link" href="/games/quiz/">
        <span class="game-card-link__emoji">🌈</span>
        <span class="game-card-link__body">
          <span class="game-card-link__title">○×クイズドリル(全用語の1問1答)</span>
          <span class="game-card-link__desc">各用語ページの○×だけを集めて連続出題。カテゴリ別・「よく出るだけ」の絞り込みつき。すきま時間の最強のおとも。</span>
        </span>
        <span class="game-card-link__arrow">→</span>
      </a>
      <a class="game-card-link" href="/games/tsumiki/">
        <span class="game-card-link__emoji">🧱</span>
        <span class="game-card-link__body">
          <span class="game-card-link__title">傾聴のつみきブロック</span>
          <span class="game-card-link__desc">人間観→基本的態度→技法。積む順番をまちがえると…カウンセリング失敗! まずはここから。</span>
        </span>
        <span class="game-card-link__arrow">→</span>
      </a>
      <a class="game-card-link" href="/games/match/">
        <span class="game-card-link__emoji">🃏</span>
        <span class="game-card-link__body">
          <span class="game-card-link__title">理論家カードあわせ</span>
          <span class="game-card-link__desc">理論家と理論を結びつけるカードゲーム。赤字は試験に出やすいポイントだよ。1回約3分。</span>
        </span>
        <span class="game-card-link__arrow">→</span>
      </a>
      <a class="game-card-link" href="/games/ryuha/">
        <span class="game-card-link__emoji">🗃️</span>
        <span class="game-card-link__body">
          <span class="game-card-link__title">理論家の流派仕分け</span>
          <span class="game-card-link__desc">特性因子・精神力動・自己成長・認知行動・組織心理の5つの棚に理論家を仕分けよう。</span>
        </span>
        <span class="game-card-link__arrow">→</span>
      </a>
      <a class="game-card-link" href="/games/anaume/">
        <span class="game-card-link__emoji">🧩</span>
        <span class="game-card-link__body">
          <span class="game-card-link__title">理論の図 あなうめゲーム</span>
          <span class="game-card-link__desc">マズロー5段階・スーパーのアーチ・ブロンフェンブレナー・キャリアコーンを穴埋めで完成させよう。</span>
        </span>
        <span class="game-card-link__arrow">→</span>
      </a>
      <div class="game-card-link game-card-link--soon">
        <span class="game-card-link__emoji">🔍</span>
        <span class="game-card-link__body">
          <span class="game-card-link__title">「30のわたし」診断・キャリアアンカー簡易診断(準備中)</span>
          <span class="game-card-link__desc">自分を知るセルフ・アセスメント。次のアップデートで登場!</span>
        </span>
      </div>
    </div>

    <p class="section__more"><a href="/#daily">きょうの3分学習(用語・理論家・1問)もどうぞ →</a></p>
  </div>
</section>`;
  return renderPage({
    title: "3分ミニゲーム",
    description:
      "キャリアコンサルタント試験の知識を、あそびながら覚える3分ミニゲーム。理論家と理論を結びつけるカードあわせなど。",
    path: "/games/",
    body,
    crumbs: [{ name: "ホーム", url: "/" }, { name: "ミニゲーム" }],
  });
}

/** 理論家カードあわせゲーム */
export function matchGamePage(): string {
  // 全カードをサーバー側で描画しておき、JSが毎ラウンド6組を選んで表示する
  const theoristCards = matchPairs
    .map(
      (p) => `<button type="button" class="match-card match-card--theorist" data-slug="${esc(
        p.slug
      )}" hidden>
        <span class="match-card__avatar">${TheoristAvatar(p.slug, 64)}</span>
        <span class="match-card__name">${esc(p.name)}</span>
      </button>`
    )
    .join("");
  const theoryCards = matchPairs
    .map(
      (p) => `<button type="button" class="match-card match-card--theory" data-slug="${esc(
        p.slug
      )}" hidden>
        <span class="match-card__theory">${p.theory}</span>
      </button>`
    )
    .join("");

  const body = `
<section class="section">
  <div class="container container--narrow">
    ${EditorialSectionHeader({
      en: "MINI GAME 01",
      title: "🃏 理論家カードあわせ",
      lede: "左の理論家と、右の理論をタップして、正しいペアを見つけよう。全6組そろえばクリア!赤い字は試験に出やすいポイントだよ。",
    })}
    ${CharacterGuide("moyan", "えっと…この先生の理論はどれだっけ…?")}
    ${CharacterGuide("sunny", "まちがえても大丈夫。まちがえた組み合わせほど、記憶に残るからね。")}

    <div class="match-game" id="match-game">
      <div class="match-game__status">
        <span data-match-progress>0 / 6</span>
        <span data-match-miss>ミス: 0</span>
        <button type="button" class="button button--ghost" data-match-restart>くばり直す</button>
      </div>
      <div class="match-game__board">
        <div class="match-game__col" data-col="theorist">
          <p class="match-game__col-label">理論家</p>
          ${theoristCards}
        </div>
        <div class="match-game__col" data-col="theory">
          <p class="match-game__col-label">理論</p>
          ${theoryCards}
        </div>
      </div>
      <p class="match-game__feedback" data-match-feedback aria-live="polite"></p>
      <div class="match-game__clear" data-match-clear hidden>
        <p class="match-game__clear-title">🎉 ぜんぶそろったね!</p>
        <p data-match-clear-text></p>
        <div class="match-game__clear-actions">
          <button type="button" class="button button--primary" data-match-again>もう一回(べつの6組)</button>
          <a class="button button--secondary" href="/theorists/">理論家図鑑でおさらいする</a>
        </div>
      </div>
    </div>

    <p class="match-game__note">出てくるペアは毎回シャッフル。全部で${matchPairs.length}人の理論家が登場するよ。</p>
  </div>
</section>
<script src="/js/game-match.js" defer></script>`;
  return renderPage({
    title: "理論家カードあわせ(3分ミニゲーム)",
    description:
      "キャリアコンサルタント試験に出る理論家と理論を、カードあわせで楽しく覚えるミニゲーム。スーパー、ロジャーズ、シャインなど18人が登場。",
    path: "/games/match/",
    body,
    crumbs: [
      { name: "ホーム", url: "/" },
      { name: "ミニゲーム", url: "/games/" },
      { name: "理論家カードあわせ" },
    ],
  });
}
