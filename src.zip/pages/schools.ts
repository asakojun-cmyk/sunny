import { renderPage } from "../components/Layout";
import { CharacterGuide } from "../components/Characters";
import { EditorialSectionHeader } from "../components/EditorialSectionHeader";
import { SchoolCard, deliveryModesLabel } from "../components/SchoolCard";
import { InfoLabel, InfoBlock } from "../components/InfoLabel";
import { SourceList } from "../components/SourceList";
import { UpdatedDate } from "../components/UpdatedDate";
import { RelatedContents } from "../components/RelatedContents";
import { esc, formatDate, formatYen } from "../lib/html";
import { SITE } from "../lib/site";
import { schools } from "../data/schools/index";
import type { School } from "../lib/types";

const FILTERS: { tag: string; label: string }[] = [
  { tag: "online", label: "オンライン" },
  { tag: "classroom", label: "通学" },
  { tag: "weekend", label: "土日" },
  { tag: "weekday", label: "平日" },
  { tag: "evening", label: "夜間" },
  { tag: "short-term", label: "短期" },
  { tag: "benefit", label: "給付金対象" },
  { tag: "makeup", label: "振替制度" },
  { tag: "after-support", label: "資格取得後の支援" },
];

/** 学校一覧 */
export function schoolsIndexPage(): string {
  const body = `
<div class="container">
  ${EditorialSectionHeader({
    en: "SCHOOLS",
    title: "養成学校一覧",
    lede: "公式情報・受講者本人の体験・運営者の考察を分けて掲載しています。料金や日程は変更される可能性があるため、申込み前に必ず公式サイトをご確認ください。",
    headingLevel: 1,
  })}
  <p class="schools-entry-link">🔰 まだ検討中の方は、まず<a href="/shikaku-guide/">資格まるわかりガイド(費用・給付金・難易度)</a>からどうぞ。</p>
  <div class="school-filters" role="group" aria-label="学校の絞り込み">
    <p class="school-filters__label">条件で絞り込む:</p>
    ${FILTERS.map(
      (f) =>
        `<button type="button" class="filter-chip" data-filter="${esc(f.tag)}" aria-pressed="false">${esc(f.label)}</button>`
    ).join("")}
    <button type="button" class="filter-chip filter-chip--reset" data-filter-reset>すべて表示</button>
  </div>
  <p class="school-filters__note">※「未確認・調査中」の学校は、条件を確認できるまで絞り込み結果に表示されないことがあります。</p>
  <div class="school-grid school-grid--index" data-school-list>
    ${schools.map((s) => SchoolCard(s)).join("")}
  </div>
  <div class="compare-bar" data-compare-bar hidden>
    <p class="compare-bar__text">比較リスト(<span data-compare-count>0</span>/3校)</p>
    <a class="button button--primary" href="/schools/compare/">選んだ学校を比較する</a>
    <button type="button" class="button button--ghost" data-compare-clear>クリア</button>
  </div>

  <section class="future-work">
    ${EditorialSectionHeader({
      en: "AFTER LICENSE",
      title: "資格を取った後の働き方",
      lede: "講座選びとセットで、「取ったあと、どこでどう働けるのか」も見ておくと安心です。",
    })}
    ${CharacterGuide("moyan", "資格を取ったら、どんなお仕事ができるの?")}
    ${CharacterGuide(
      "sunny",
      "大きく分けて5つの場があるよ。今の職場で生かす形も立派なひとつ。くわしくは下のページでね。"
    )}
    <ul class="future-work__list">
      <li><span class="future-work__icon" aria-hidden="true">🏢</span><span class="future-work__name">企業内</span><span class="future-work__desc">人事・キャリア開発部門で従業員の面談や研修に。今の職場で生かす形も</span></li>
      <li><span class="future-work__icon" aria-hidden="true">🎓</span><span class="future-work__name">学校</span><span class="future-work__desc">大学のキャリアセンターなどで学生の就職支援に</span></li>
      <li><span class="future-work__icon" aria-hidden="true">🏛️</span><span class="future-work__name">公的機関</span><span class="future-work__desc">ハローワークや地域の就労支援機関で求職者の支援に</span></li>
      <li><span class="future-work__icon" aria-hidden="true">🤝</span><span class="future-work__name">人材関連企業</span><span class="future-work__desc">人材紹介・派遣会社で求職者と企業のマッチングに</span></li>
      <li><span class="future-work__icon" aria-hidden="true">🏠</span><span class="future-work__name">独立・副業・在宅</span><span class="future-work__desc">オンライン相談・セミナー・執筆など。小さく経験を積むところから</span></li>
    </ul>
    <p class="section__more"><a class="button button--secondary" href="/careers/">資格取得後の働き方をくわしく見る →</a></p>
  </section>
</div>
<script src="/js/schools-filter.js" defer></script>
<script src="/js/compare.js" defer></script>`;
  return renderPage({
    title: "キャリアコンサルタント養成学校一覧",
    description:
      "国家資格キャリアコンサルタントの養成学校を、受講形式・期間・料金・給付金・振替制度などの条件で整理した一覧です。公式情報と体験談を分けて掲載しています。",
    path: "/schools/",
    activeNav: "/schools/",
    crumbs: [{ name: "ホーム", url: "/" }, { name: "養成学校一覧" }],
    body,
  });
}

function factRow(label: string, value: string | undefined): string {
  return `<div class="fact-row">
    <dt>${esc(label)}</dt>
    <dd>${value !== undefined && value !== "" ? esc(value) : '<span class="info-label info-label--unverified">未確認</span>'}</dd>
  </div>`;
}

/** 学校詳細 */
export function schoolDetailPage(s: School): string {
  const isUnverified = s.informationStatus === "unverified";
  const hasReview = s.slug === "chiiki-renkei-platform";

  const officialFactsSection =
    (s.officialFacts ?? []).length > 0
      ? `<section class="school-section">
    <h2 class="school-section__title">${InfoLabel("official")} 公式サイトで確認できた情報</h2>
    <dl class="fact-table">
      ${(s.officialFacts ?? [])
        .map(
          (f) => `<div class="fact-row">
        <dt>${esc(f.label)}</dt>
        <dd>${esc(f.value)}
          ${f.note ? `<span class="fact-row__note">${esc(f.note)}</span>` : ""}
          <span class="fact-row__source">(<a href="${esc(f.sourceUrl)}" rel="noopener nofollow" target="_blank">出典</a> / 確認日: ${esc(formatDate(f.checkedAt))})</span>
        </dd>
      </div>`
        )
        .join("")}
    </dl>
  </section>`
      : `<section class="school-section">
    <h2 class="school-section__title">${InfoLabel("unverified")} 基本情報</h2>
    <p>この学校の詳細情報は現在調査中です。確認でき次第、公式サイトを出典として掲載します。最新情報は<a href="${esc(s.officialUrl)}" rel="noopener nofollow" target="_blank">公式サイト</a>をご確認ください。</p>
  </section>`;

  const basicFacts = `<section class="school-section">
    <h2 class="school-section__title">基本データ</h2>
    <dl class="fact-table">
      ${factRow("運営", s.operatorName)}
      ${factRow("受講形式", s.deliveryModes.length > 0 ? deliveryModesLabel(s) : undefined)}
      ${factRow("受講期間", s.courseDuration)}
      ${factRow("ライブ講習時間", s.liveLessonHours !== undefined ? `${s.liveLessonHours}時間` : undefined)}
      ${factRow("受講料", s.tuition !== undefined ? formatYen(s.tuition) : undefined)}
      ${factRow("入学金", s.admissionFee !== undefined ? (s.admissionFee === 0 ? "なし" : formatYen(s.admissionFee)) : undefined)}
      ${factRow("教材費", s.materialFee !== undefined ? (s.materialFee === 0 ? "受講料に込み" : formatYen(s.materialFee)) : undefined)}
      ${factRow("教育訓練給付", s.educationBenefitAvailable === undefined ? undefined : s.educationBenefitAvailable ? "対象講座あり(条件は要確認)" : "対象外")}
      ${factRow("日程", (s.scheduleOptions ?? []).length > 0 ? (s.scheduleOptions ?? []).join(" / ") : undefined)}
      ${factRow("クラス規模", s.classSize)}
      ${factRow("振替制度", s.makeupPolicy)}
      ${factRow("課題の形式", s.assignmentFormat)}
      ${factRow("修了要件", (s.completionRequirements ?? []).length > 0 ? (s.completionRequirements ?? []).join(" / ") : undefined)}
      ${factRow("ロールプレイ", s.roleplayTraining)}
      ${factRow("試験対策", s.examPreparationIncluded === undefined ? undefined : s.examPreparationIncluded ? "受講料に含まれる" : `別講座・別料金${s.examPreparationNotes ? `(${s.examPreparationNotes})` : ""}`)}
      ${factRow("資格取得後の支援", (s.postQualificationSupport ?? []).length > 0 ? (s.postQualificationSupport ?? []).join(" / ") : undefined)}
    </dl>
    ${s.benefitNotes ? `<p class="school-section__note">給付金について: ${esc(s.benefitNotes)}</p>` : ""}
  </section>`;

  const editorialSection =
    (s.recommendedFor ?? []).length > 0 || (s.cautions ?? []).length > 0
      ? InfoBlock(
          "editorial",
          `
      ${
        (s.recommendedFor ?? []).length > 0
          ? `<h3>こんな人に合いそう</h3>
      <ul>${(s.recommendedFor ?? []).map((r) => `<li>${esc(r)}</li>`).join("")}</ul>`
          : ""
      }
      ${
        (s.cautions ?? []).length > 0
          ? `<h3>申込み前に確認したいこと</h3>
      <ul>${(s.cautions ?? []).map((c) => `<li>${esc(c)}</li>`).join("")}</ul>`
          : ""
      }
      <p class="info-block__note">この項目は、公式情報や体験を基にした運営者の考察です。判断は必ずご自身の条件に合わせて行ってください。</p>`
        )
      : "";

  const reviewSection = hasReview
    ? InfoBlock(
        "experience",
        `<p>運営者はこの講座を実際に受講しています。受講して感じたことは体験記事にまとめています。</p>
      <p><a class="button button--secondary" href="/school-reviews/chiiki-renkei-platform/">受講体験を読む</a></p>`
      )
    : `<div class="no-review-note">
      <p>${InfoLabel("unverified", "ご注意")} 運営者はこの講座を受講していません。公開されている公式情報を基に整理しています。</p>
    </div>`;

  const body = `
<article class="container container--article school-article">
  <header class="school-header">
    <p class="school-header__status">
      ${
        isUnverified
          ? InfoLabel("unverified")
          : `<span class="updated-date__checked">情報確認日: ${esc(formatDate(s.verifiedAt ?? s.updatedAt))}</span>`
      }
    </p>
    <h1 class="school-header__name">${esc(s.name)}</h1>
    <p class="school-header__operator">運営: ${esc(s.operatorName)}</p>
    ${UpdatedDate({ updatedAt: s.updatedAt, infoCheckedAt: s.verifiedAt })}
    <p class="school-header__official"><a class="button button--secondary" href="${esc(s.officialUrl)}" rel="noopener nofollow" target="_blank">公式サイトを見る</a></p>
  </header>

  <aside class="notice-box">
    <p>掲載している料金・期間・給付金・日程・振替制度などの情報は変更される可能性があります。申込み前に必ず<a href="${esc(s.officialUrl)}" rel="noopener nofollow" target="_blank">公式サイト</a>で最新情報をご確認ください。確認できていない項目は「未確認」と表示しています。</p>
  </aside>

  ${officialFactsSection}
  ${basicFacts}
  ${reviewSection}
  ${editorialSection}
  ${SourceList(s.sources)}

  ${RelatedContents(
    [
      {
        type: "比較",
        title: "養成学校を比較する",
        url: "/schools/compare/",
        description: "最大3校まで並べて確認できます。",
      },
      {
        type: "ガイド",
        title: "養成学校の選び方",
        url: "/school-guides/how-to-choose/",
      },
      {
        type: "ガイド",
        title: "養成講習と試験対策講座の違い",
        url: "/school-guides/training-and-exam-preparation/",
      },
    ],
    "あわせて読みたい"
  )}
</article>`;

  const courseLd: object = {
    "@context": "https://schema.org",
    "@type": "Course",
    name: s.name,
    description: `${s.operatorName}が運営するキャリアコンサルタント養成講座の情報ページ。`,
    provider: {
      "@type": "Organization",
      name: s.operatorName,
      ...(s.officialUrl ? { url: s.officialUrl } : {}),
    },
  };

  return renderPage({
    title: `${s.name}の講座情報`,
    description: `${s.name}(運営: ${s.operatorName})の受講形式・期間・料金・給付金・振替制度などの情報。公式情報と運営者の考察を分けて掲載しています。`,
    path: `/schools/${s.slug}/`,
    activeNav: "/schools/",
    ogType: "article",
    crumbs: [
      { name: "ホーム", url: "/" },
      { name: "養成学校一覧", url: "/schools/" },
      { name: s.name },
    ],
    structuredData: [courseLd],
    body,
  });
}
