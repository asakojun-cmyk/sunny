import { renderPage } from "../components/Layout";
import { EditorialSectionHeader } from "../components/EditorialSectionHeader";
import { CharacterGuide } from "../components/Characters";
import { TermDiagram } from "../components/Diagrams";
import { esc } from "../lib/html";
import { getTerm } from "../data/terms";

/**
 * 図解ライブラリ:
 * - 動的フローチャート①: キャリア形成の流れとキャリアコンサルティング(6ステップ)
 * - 動的フローチャート②: カウンセリングのプロセス(システマティック・アプローチ)
 * - フェーズ別・理論別の図解一覧(各用語ページへリンク)
 * ステップの枠組みは、旧・雇用能力開発機構などで整理された
 * キャリア形成の6ステップを参考に、当サイトが再構成したもの。
 */

type FlowStep = {
  title: string;
  short: string;
  desc: string;
  sunny: string;
  links: { label: string; href: string }[];
};

function flowchart(id: string, steps: FlowStep[]): string {
  const buttons = steps
    .map(
      (s, i) => `<button type="button" class="flow-step${i === 0 ? " is-active" : ""}" data-flow-step="${i}">
        <span class="flow-step__num">${i + 1}</span>
        <span class="flow-step__title">${esc(s.title)}</span>
        <span class="flow-step__short">${esc(s.short)}</span>
      </button>${i < steps.length - 1 ? '<span class="flow-arrow" aria-hidden="true">→</span>' : ""}`
    )
    .join("");
  const panels = steps
    .map(
      (s, i) => `<div class="flow-panel"${i === 0 ? "" : " hidden"} data-flow-panel="${i}">
        <p class="flow-panel__desc">${esc(s.desc)}</p>
        <p class="flow-panel__sunny">☀️ ${esc(s.sunny)}</p>
        ${
          s.links.length > 0
            ? `<p class="flow-panel__links">くわしく: ${s.links
                .map((l) => `<a href="${esc(l.href)}">${esc(l.label)}</a>`)
                .join("")}</p>`
            : ""
        }
      </div>`
    )
    .join("");
  return `<div class="flowchart" id="${id}" data-flowchart>
    <div class="flowchart__steps">${buttons}</div>
    ${panels}
    <p class="flowchart__hint">👆 ステップをタップすると説明が変わるよ</p>
  </div>`;
}

const CAREER_FLOW: FlowStep[] = [
  {
    title: "自己理解",
    short: "自分を知る",
    desc: "興味・能力・価値観、そして自分をとりまく環境を理解するステップ。検査(アセスメント)や振り返りを通じて「自分はどんな人か」を言葉にしていきます。",
    sunny: "ぜんぶはここから始まるよ。「わたしの紹介カード(自己概念)」を一緒に書き出していこうね。",
    links: [
      { label: "自己概念", href: "/terms/jiko-gainen/" },
      { label: "アセスメント", href: "/terms/assessment/" },
      { label: "ジョハリの窓", href: "/terms/johari-window/" },
    ],
  },
  {
    title: "仕事理解",
    short: "仕事を知る",
    desc: "職業の内容、業界、労働市場の動きを知るステップ。job tag(職業情報提供サイト)や求人情報、職業分類などの情報源を目的に合わせて使い分けます。",
    sunny: "自分だけ見ても、仕事だけ見ても決められない。両方を知って、はじめてマッチングできるんだよ。",
    links: [
      { label: "job tagと職業理解", href: "/terms/job-tag/" },
      { label: "ハローワーク", href: "/terms/hello-work/" },
    ],
  },
  {
    title: "啓発的経験",
    short: "ためしてみる",
    desc: "インターンシップやトライアル雇用、ボランティアなどで実際に体験してみるステップ。頭で考えるだけでは分からない「肌感覚」を確かめます。",
    sunny: "くつは試しばきしてから買うでしょ? お仕事も、小さく試すとミスマッチが減るんだよ。",
    links: [{ label: "トライアル雇用・インターンシップ", href: "/terms/trial-koyo/" }],
  },
  {
    title: "意思決定",
    short: "選んで決める",
    desc: "キャリア選択に関わる意思決定を行うステップ。予測→価値づけ→決定をくり返しながら(ジェラット)、キャリアコンサルティングの支援も受けつつ進路を選びます。",
    sunny: "1回で完璧に決めなくていいの。決めては確かめて、少しずつ「最終決定」に近づけばOK。",
    links: [
      { label: "連続的意思決定プロセス", href: "/terms/renzokuteki-ishikettei/" },
      { label: "肯定的不確実性", href: "/terms/positive-uncertainty/" },
    ],
  },
  {
    title: "方策の実行",
    short: "行動する",
    desc: "決めたことを実行に移すステップ。応募書類の作成、面接、職業訓練の受講、教育訓練給付の活用など、具体的な行動を計画的に進めます。",
    sunny: "ここは行動の季節。応募書類づくりは、自分の棚卸しのチャンスでもあるんだよ。",
    links: [
      { label: "応募書類の支援", href: "/terms/oubo-shorui/" },
      { label: "教育訓練給付", href: "/terms/kyoiku-kunren-kyufu/" },
    ],
  },
  {
    title: "仕事への適応",
    short: "なじんで続ける",
    desc: "新しい仕事・職場に定着するステップ。リアリティショックへの備えやフォローアップを通じて、次のキャリア形成のサイクルへつながっていきます。",
    sunny: "就職はゴールじゃなくて新しいスタート。根づくまでの水やり(フォローアップ)が大事だよ。",
    links: [
      { label: "フォローアップ", href: "/terms/follow-up/" },
      { label: "リアリティショック", href: "/terms/reality-shock/" },
    ],
  },
];

const COUNSELING_FLOW: FlowStep[] = [
  {
    title: "開始",
    short: "関係をつくる",
    desc: "カウンセリング関係の樹立。あたたかい雰囲気づくり、場面設定(時間・役割・守秘義務の説明と同意)、ラポールの形成から始まります。",
    sunny: "最初のお約束(場面構成)が、安心して話せる土台。ここを丁寧に、だよ。",
    links: [
      { label: "相談場面の設定", href: "/terms/bamen-kosei/" },
      { label: "ラポール", href: "/terms/rapport/" },
      { label: "インテーク", href: "/terms/intake/" },
    ],
  },
  {
    title: "問題の把握",
    short: "なにに困ってる?",
    desc: "傾聴を通じて主訴(相談者の訴え)をつかみ、相談者自身の見方と、キャリアコンサルタントから見えた問題を整理して、取り組むテーマを共有します。",
    sunny: "「相談者が言う問題」と「見えてきた問題」は違うことがある。あわてて解決に走らないでね。",
    links: [
      { label: "傾聴", href: "/terms/keicho/" },
      { label: "質問技法", href: "/terms/shitsumon-giho/" },
      { label: "感情の反映", href: "/terms/kanjo-no-hanei/" },
    ],
  },
  {
    title: "目標の設定",
    short: "ゴールを決める",
    desc: "相談者と一緒に、カウンセリングの目標を合意するステップ。目標・課題・絆の合意(作業同盟)ができると、支援は前に進みはじめます。",
    sunny: "ゴールは相談者と「一緒に」決める。カウンセラーが勝手に決めたら×だよ。",
    links: [{ label: "作業同盟", href: "/terms/working-alliance/" }],
  },
  {
    title: "方策の実行",
    short: "取り組む",
    desc: "目標達成のための方策(意思決定の支援、学習の支援、自己管理の支援など)を選んで実行するステップ。相談者の主体性を尊重しながら伴走します。",
    sunny: "方策は「目標が決まってから」。順番の入れ替えは試験のひっかけ定番だよ。",
    links: [{ label: "システマティック・アプローチ", href: "/terms/systematic-approach/" }],
  },
  {
    title: "結果の評価",
    short: "ふりかえる",
    desc: "方策の実行結果と目標の達成度を、相談者と一緒に評価するステップ。必要なら目標や方策を修正して、もう一度取り組みます。",
    sunny: "うまくいかなくても失敗じゃない。「作戦を変える材料が手に入った」ってことだよ。",
    links: [{ label: "相談過程の管理", href: "/terms/case-management/" }],
  },
  {
    title: "終了",
    short: "しめくくる",
    desc: "成果と残された課題を確認し、関係を適切に終結するステップ。就職後のフォローアップや、必要に応じた専門機関への紹介(リファー)も視野に入れます。",
    sunny: "「なんとなく途切れる」んじゃなくて、ちゃんと確認して終わる。それが次の一歩への贈り物。",
    links: [
      { label: "フォローアップ", href: "/terms/follow-up/" },
      { label: "リファー", href: "/terms/refer/" },
    ],
  },
];

/** ライブラリ棚: slug の図をカードで並べる */
function shelf(title: string, note: string, slugs: string[]): string {
  const cards = slugs
    .map((slug) => {
      const d = TermDiagram(slug);
      if (!d) return "";
      const t = getTerm(slug);
      const link = t
        ? `<a class="diagram-card__link" href="/terms/${esc(slug)}/">${esc(t.name)}のページへ →</a>`
        : "";
      return `<div class="diagram-card">${d}${link}</div>`;
    })
    .join("");
  return `<section class="diagram-shelf">
    <h2 class="term-section-title">${esc(title)}</h2>
    <p class="diagram-shelf__note">${esc(note)}</p>
    <div class="diagram-shelf__grid">${cards}</div>
  </section>`;
}

export function diagramsPage(): string {
  const body = `
<section class="section">
  <div class="container container--narrow">
    ${EditorialSectionHeader({
      en: "DIAGRAMS",
      title: "🗺️ 図解ライブラリ",
      lede: "理論と技法を「絵」で覚えるコーナー。まずは2つの動的フローチャートで全体の流れをつかんで、それから各図解へどうぞ。",
    })}
    ${CharacterGuide("moyan", "文字だけだと、頭の中でごちゃごちゃになっちゃう…")}
    ${CharacterGuide("sunny", "そんなときは絵の出番。「どの場面の話か」が見えると、ぜんぶつながるよ。")}

    <h2 class="term-section-title">① キャリア形成の流れとキャリアコンサルティング</h2>
    <p class="flowchart__lede">人がキャリアをつくっていく6つのステップ。キャリアコンサルタントは、この<strong>すべてのステップに伴走</strong>します。学科でも実技でも土台になる、いちばん大事な地図だよ。</p>
    ${flowchart("career-flow", CAREER_FLOW)}

    <h2 class="term-section-title" style="margin-top:48px;">② カウンセリングのプロセス</h2>
    <p class="flowchart__lede">1回1回の相談が進む流れ(システマティック・アプローチ)。①の大きな流れの中で、この6段階がくり返されるイメージです。</p>
    ${flowchart("counseling-flow", COUNSELING_FLOW)}

    <div style="margin-top:40px;">
      ${TermDiagram("sodan-katei-map")}
    </div>

    ${shelf(
      "自己理解の支援に効く図解",
      "「自分を知る」を助ける理論たち。",
      ["jiko-gainen", "johari-window", "jiko-icchi", "tokusei-inshi", "career-anchor", "jiko-koryokukan"]
    )}
    ${shelf(
      "仕事理解・意思決定・転機の図解",
      "「選ぶ・決める・乗り越える」を助ける理論たち。",
      ["holland", "renzokuteki-ishikettei", "tenki", "transition-riron", "career-adaptability"]
    )}
    ${shelf(
      "カウンセリング理論・技法の図解",
      "面接を支える理論と技法。人名とセットで覚えよう。",
      ["systematic-approach", "coffee-cup-model", "microcounseling", "abc-riron", "ninchi-ryoho", "kodo-ryoho", "assertion", "seishin-bunseki", "boei-kisei", "koryu-bunseki"]
    )}
    ${shelf(
      "発達・人生の視点の図解",
      "人生全体を見わたす理論たち。",
      ["life-career-rainbow", "erikson", "levinson"]
    )}

    <p class="diagram-lib__note">🌱 図解はこれからも増えていくよ(ライフラインチャート、ユングの人生の正午、World-of-Work Mapなどを準備中)。「この理論の図がほしい!」があったら教えてね。</p>
  </div>
</section>
<script src="/js/flowchart.js" defer></script>`;

  return renderPage({
    title: "図解ライブラリ(キャリア形成の流れ・カウンセリングのプロセス)",
    description:
      "キャリア形成の6ステップとカウンセリングのプロセスを動的フローチャートで、キャリア理論・カウンセリング技法をオリジナル図解で学べるライブラリ。",
    path: "/diagrams/",
    body,
    crumbs: [{ name: "ホーム", url: "/" }, { name: "図解ライブラリ" }],
  });
}
