import { renderPage } from "../components/Layout";
import { CharacterDialogue } from "../components/Characters";
import { AuthorProfile } from "../components/AuthorProfile";
import { UpdatedDate } from "../components/UpdatedDate";
import { SITE } from "../lib/site";
import { esc } from "../lib/html";

/** このサイトについて */
export function aboutPage(): string {
  const body = `
<article class="container container--article guide-article">
  <header class="article-header">
    <p class="article-header__meta"><span class="article-card__category">このサイトについて</span></p>
    <h1>このサイトについて</h1>
    <p class="article-header__lede">${esc(SITE.concept)} — ${esc(SITE.name)}は、忙しい人が静かに学べる小さな図書室を目指しています。</p>
    ${UpdatedDate({ updatedAt: "2026-07-11" })}
  </header>

  <section class="guide-section">
    <h2>運営者</h2>
    ${AuthorProfile()}
  </section>

  <section class="guide-section">
    <h2>このサイトの方針</h2>
    <ul>
      <li>難しい専門用語を「ひとこと」「身近なたとえ」「試験で必要な正式な説明」の3段階で解説します。簡単な説明で終わらせず、試験で使える正確な知識につなげます。</li>
      <li>学校の情報は「公式情報」「受講者本人の体験」「運営者の考察」を分けて表示します。受講していない学校について「受講体験」とは書きません。</li>
      <li>体験談の本文はAIで作りません。運営者本人の記録だけを掲載します。</li>
      <li>法律・統計・受験制度・受講料・給付金・合格率などは、一次資料で確認できない内容を推測で公開しません。確認できない項目は「未確認」「調査中」と表示します。</li>
      <li>「人気」「一番」「最安」「合格しやすい」などの表現は、客観的な根拠がない場合は使いません。</li>
      <li>広告・PRを含む記事には、記事冒頭の分かりやすい場所にPR表示をします。学校からの報酬・無償提供・紹介リンクの有無を記事ごとに開示します。</li>
    </ul>
  </section>

  <section class="guide-section">
    <h2>免責事項</h2>
    <p>掲載している学校の料金・日程・給付金などの情報は変更される可能性があります。申込み前に必ず各校の公式サイトで最新情報をご確認ください。試験制度に関する正式な情報は、厚生労働省および試験実施機関の公式サイトをご確認ください。</p>
  </section>
</article>`;

  return renderPage({
    title: "このサイトについて",
    description:
      "キャリコンことば図鑑の運営者・編集方針・情報の信頼性への考え方について説明します。",
    path: "/about/",
    crumbs: [{ name: "ホーム", url: "/" }, { name: "このサイトについて" }],
    body,
  });
}

/** 404ページ */
export function notFoundPage(): string {
  const body = `
<div class="container container--narrow notfound">
  <p class="section-header__en" aria-hidden="true">404 NOT FOUND</p>
  <h1 class="section-header__title">ページが見つかりませんでした</h1>
  ${CharacterDialogue(
    "あれ…? このページ、どこかに行っちゃったみたい…",
    "だいじょうぶ。ホームか検索から、もう一度探してみよう!"
  )}
  <p>お探しのページは移動または削除された可能性があります。</p>
  <div class="notfound__actions">
    <a class="button button--primary" href="/">ホームに戻る</a>
    <a class="button button--secondary" href="/search/">サイト内検索</a>
  </div>
</div>`;
  return renderPage({
    title: "ページが見つかりません",
    description: "お探しのページは見つかりませんでした。",
    path: "/404.html",
    body,
  });
}
