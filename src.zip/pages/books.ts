import { renderPage } from "../components/Layout";
import { EditorialSectionHeader } from "../components/EditorialSectionHeader";
import { CharacterGuide } from "../components/Characters";
import { BookShelf } from "../components/BookShelf";
import { books } from "../data/books";

/** さらに学べる本棚(書籍紹介のハブページ) */
export function booksPage(): string {
  const teiban = books.filter((b) => b.audience === "受験生の定番");
  const genten = books.filter((b) => b.audience === "理論の原典");
  const yomimono = books.filter((b) => b.audience === "読みものとして");

  const body = `
<div class="container container--narrow">
  ${EditorialSectionHeader({
    en: "BOOKS",
    title: "📚 さらに学べる本棚",
    lede: "このサイトで「わかった!」の入口をつくったら、次は本で深めましょう。試験の定番テキストから、理論家本人の原典、勉強に疲れた夜の読みものまで。",
    headingLevel: 1,
  })}
  ${CharacterGuide("moyan", "本がたくさんありすぎて、どれを買えばいいかわからないよ〜")}
  ${CharacterGuide(
    "sunny",
    "ぜんぶ買わなくて大丈夫。まずは定番テキストを1冊。原典は、好きになった理論家のものだけでいいんだよ。"
  )}
  ${BookShelf(teiban, "まずはここから — 受験生の定番")}
  ${BookShelf(genten, "好きな理論家ができたら — 理論の原典")}
  ${BookShelf(yomimono, "勉強に疲れた夜に — 読みものとして")}
  <p class="section__more"><a class="button button--secondary" href="/text/">📖 当サイト公式「直前対策テキスト(PDF)」について →</a></p>
</div>`;
  return renderPage({
    title: "さらに学べる本棚(参考書・理論家の本)",
    description:
      "キャリアコンサルタント試験の定番テキスト・過去問集から、シャイン・クランボルツ・サビカスなど理論家の原典、夜と霧・嫌われる勇気などの読みものまで、学びを深める本を紹介します。",
    path: "/books/",
    body,
    crumbs: [{ name: "ホーム", url: "/" }, { name: "本棚" }],
  });
}
