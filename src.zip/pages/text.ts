import { renderPage } from "../components/Layout";
import { EditorialSectionHeader } from "../components/EditorialSectionHeader";
import { CharacterGuide } from "../components/Characters";
import { terms } from "../data/terms";
import { theorists } from "../data/theorists";

/**
 * 学科対策テキスト(PDF)の販売案内ページ。
 * NOTE_URL が空の間は「発売準備中」。noteで発売したらURLを入れるだけで購入ボタンに変わる。
 */
const NOTE_URL = "";
const PRICE_LABEL = "980円(予定)";

export function textSalesPage(): string {
  const cta = NOTE_URL
    ? `<a class="button button--primary text-sales__cta" href="${NOTE_URL}" target="_blank" rel="noopener">noteで購入する(${PRICE_LABEL})→</a>`
    : `<p class="text-sales__soon">🌥️ ただいま発売準備中です(noteで発売予定・${PRICE_LABEL})。<br>発売までは、このサイトの全ページを無料でご利用ください。</p>`;

  const body = `
<div class="container container--narrow">
  ${EditorialSectionHeader({
    en: "STUDY TEXT",
    title: "📖 学科試験 直前対策テキスト(PDF)",
    lede: `このサイトの${terms.length}用語+理論家${theorists.length}人を「隠す→思い出す→確かめる」ができる形にした、穴埋めドリル式テキスト。スマホ用(タップで答え)と印刷用(解答編つきPDF)の2形式セットです。`,
    headingLevel: 1,
  })}
  ${CharacterGuide("moyan", "サイトと同じ内容なら、無料のサイトだけでよくない?")}
  ${CharacterGuide(
    "sunny",
    "サイトは「わかるまで」の場所、テキストは「試験直前に回す」ための道具。役割がちがうんだ。印刷して書き込めるし、ネットがない場所でも使えるよ。"
  )}

  <section class="text-sales__box">
    <h2 class="term-section-title">収録内容</h2>
    <ul class="text-sales__list">
      <li>📱 <strong>タップで答えが出るインタラクティブ版(HTML)</strong> — 重要語が⛅️で隠れていて、タップすると表示。○×も「答えを見る」を押すまで出ません。スマホのすきま時間学習に</li>
      <li>🖨️ <strong>穴埋めドリル式・印刷用PDF(A4・約100ページ)</strong> — 重要語が〔①〕の空欄に。○×の答えも本文にはなし。巻末の「解答編」で答え合わせする、紙の問題集スタイル</li>
      <li>✅ 全${terms.length}用語+理論家${theorists.length}人/「試験ではこう出る」ひっかけ注意/全項目に頻出度つき</li>
      <li>✅ 「読む」教材ではなく「思い出す」教材 — 想起練習で記憶に残す設計です</li>
    </ul>
  </section>

  <section class="text-sales__box">
    <h2 class="term-section-title">無料のサイトとの違い</h2>
    <ul class="text-sales__list">
      <li>🌐 サイト(無料): やさしい解説・たとえ話・図解・ゲームで「わかる」ための場所。これからもずっと無料です</li>
      <li>📖 テキスト(有料): やさしい解説を抜いて「試験で出る形」だけに凝縮。直前期に高速で回すための1冊</li>
    </ul>
  </section>

  ${cta}

  <section class="text-sales__box text-sales__box--note">
    <h2 class="term-section-title">ご購入前に必ずお読みください</h2>
    <ul class="text-sales__list text-sales__list--small">
      <li>・本テキストは運営者のオリジナル教材です。実際の過去問題文の転載はありません。頻出度は運営者調べの目安であり、出題を保証するものではありません。</li>
      <li>・法令・統計は作成時点の情報です。受験前に一次資料(厚生労働省等)で最新情報をご確認ください。</li>
      <li>・購入者個人の学習用です。複製・再配布・転売はできません。</li>
    </ul>
  </section>
</div>`;

  return renderPage({
    title: "学科試験 直前対策テキスト(PDF)",
    description: `キャリアコンサルタント学科試験の直前対策PDFテキスト。${terms.length}用語+理論家${theorists.length}人を頻出度・ひっかけ注意・○×チェックつきで「試験で出る形」に凝縮しました。`,
    path: "/text/",
    body,
    crumbs: [{ name: "ホーム", url: "/" }, { name: "対策テキスト" }],
  });
}
