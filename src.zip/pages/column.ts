import { renderPage } from "../components/Layout";
import { EditorialSectionHeader } from "../components/EditorialSectionHeader";
import { CharacterGuide, MoyanIdeaSvg } from "../components/Characters";
import { UpdatedDate } from "../components/UpdatedDate";
import { esc } from "../lib/html";
import { columns, type Column } from "../data/columns";
import { getTerm } from "../data/terms";
import { getTheorist } from "../data/theorists";

/**
 * モヤンの中の人コラム。
 * キャリア理論を、キャリア以外の暮らし(子育て・対人関係・マインド)に翻訳する読みもの。
 * 「人の可能性を信じて、整理して、選択肢を広げて、前向きな一歩をうながす」がコンセプト。
 */

export function columnHubPage(): string {
  const cards = columns
    .map(
      (c) => `<a class="column-card" href="/column/${esc(c.slug)}/">
        <span class="column-card__no">COLUMN ${String(c.number).padStart(2, "0")}</span>
        <span class="column-card__title">${esc(c.title)}</span>
        <span class="column-card__lede">${esc(c.lede)}</span>
        <span class="column-card__tags">${c.tags.map((t) => `<span>#${esc(t)}</span>`).join("")}</span>
      </a>`
    )
    .join("");

  const body = `
<section class="section">
  <div class="container container--narrow">
    ${EditorialSectionHeader({
      en: "COLUMN",
      title: "☁️ モヤンの中の人コラム",
      lede: "キャリア理論は、キャリアだけのものじゃない。子育てに、対人関係に、自分のこころに。理論を暮らしのことばに翻訳して、前向きな一歩をそっと後押しする読みものです。",
    })}
    <div class="column-hub__chara">${MoyanIdeaSvg(84)}</div>
    ${CharacterGuide("sunny", "理論はぜんぶ、「人には可能性がある」と信じた人たちが残してくれた地図。試験が終わっても、一生使えるよ。")}
    <div class="column-list">${cards}</div>
    <p class="column-hub__note">🌱 コラムは少しずつ増えていきます。「こんなテーマを読みたい」があれば、ぜひ教えてください。</p>
  </div>
</section>`;
  return renderPage({
    title: "モヤンの中の人コラム(キャリア理論を暮らしに)",
    description:
      "キャリア理論を子育て・対人関係・自分のマインドに生かす読みものコラム。計画された偶発性、ABC理論、トランジション理論などを暮らしのことばで。",
    path: "/column/",
    body,
    crumbs: [{ name: "ホーム", url: "/" }, { name: "中の人コラム" }],
  });
}

export function columnDetailPage(c: Column): string {
  const sections = c.sections
    .map(
      (s) => `<section class="column-section">
        <h2>${esc(s.heading)}</h2>
        ${s.paragraphs.map((p) => `<p>${esc(p)}</p>`).join("")}
      </section>`
    )
    .join("");

  const relatedTerms = (c.relatedTermSlugs ?? [])
    .map((slug) => {
      const t = getTerm(slug);
      return t ? `<a href="/terms/${esc(slug)}/">${esc(t.name)}</a>` : "";
    })
    .filter(Boolean)
    .join("");
  const relatedTheorists = (c.relatedTheoristSlugs ?? [])
    .map((slug) => {
      const t = getTheorist(slug);
      return t ? `<a href="/theorists/${esc(slug)}/">${esc(t.name)}</a>` : "";
    })
    .filter(Boolean)
    .join("");

  const body = `
<article class="container container--article column-article">
  <header class="article-header">
    <p class="article-header__meta"><span class="article-card__category">モヤンの中の人コラム</span> ${c.tags
      .map((t) => `<span class="column-tag">#${esc(t)}</span>`)
      .join("")}</p>
    <h1>${esc(c.title)}</h1>
    <p class="article-header__lede">${esc(c.lede)}</p>
    ${UpdatedDate({ updatedAt: c.updatedAt })}
  </header>

  ${CharacterGuide("moyan", c.moyanLine)}
  ${CharacterGuide("sunny", c.sunnyLine)}

  ${sections}

  ${
    c.personalNote
      ? `<section class="column-personal">
    <h2>中の人のはなし</h2>
    <p>${esc(c.personalNote)}</p>
  </section>`
      : ""
  }

  <aside class="column-step">
    <p class="column-step__title">🌤️ きょうの、ちいさな一歩</p>
    <p class="column-step__body">${esc(c.smallStep)}</p>
    <p class="column-step__note">※ やらなくても大丈夫。読んだだけで、もう一歩目です。</p>
  </aside>

  ${
    relatedTerms || relatedTheorists
      ? `<section class="column-related">
    <h2>試験勉強にもどるなら</h2>
    <p class="column-related__links">
      ${relatedTerms}
      ${relatedTheorists}
    </p>
  </section>`
      : ""
  }

  <p class="column-back"><a href="/column/">← コラム一覧へ</a></p>
</article>`;

  return renderPage({
    title: `${c.title}(モヤンの中の人コラム)`,
    description: c.lede,
    path: `/column/${c.slug}/`,
    body,
    ogType: "article",
    crumbs: [
      { name: "ホーム", url: "/" },
      { name: "中の人コラム", url: "/column/" },
      { name: `COLUMN ${String(c.number).padStart(2, "0")}` },
    ],
  });
}

export { columns };
