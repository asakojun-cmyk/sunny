import { renderPage } from "../components/Layout";
import { EditorialSectionHeader } from "../components/EditorialSectionHeader";
import { CharacterGuide } from "../components/Characters";
import { DisclosureBox } from "../components/PrLabel";
import { UpdatedDate } from "../components/UpdatedDate";

/**
 * 検討者の入口ページ:「キャリアコンサルタント資格まるわかりガイド」
 * どんな資格? / 取り方 / 費用総額 / 給付金でいくら戻る?(計算機つき) /
 * 難易度 / 働きながら・子育てしながら / FAQ / 次のステップ
 * 金額・制度は変わりうるため、確認日と一次資料リンクを明記する。
 */
export function shikakuGuidePage(): string {
  const body = `
<article class="container container--article guide-article shikaku-guide">
  <header class="article-header">
    <p class="article-header__meta"><span class="article-card__category">はじめての方へ</span></p>
    <h1>キャリアコンサルタント資格 まるわかりガイド</h1>
    <p class="article-header__lede">「気になるけど、費用は? 難しさは? 働きながらいける?」— 検討中のあなたが最初に知りたいことを、このページ1枚にまとめました。</p>
    ${UpdatedDate({ updatedAt: "2026-07-12", infoCheckedAt: "2026-07-12" })}
  </header>

  ${DisclosureBox({
    isPr: false,
    receivedCompensation: false,
    containsAffiliateLinks: false,
    paidByAuthor: true,
  })}

  ${CharacterGuide("moyan", "キャリアコンサルタントの資格、気になってるんだけど…私にも取れるのかな?")}
  ${CharacterGuide("sunny", "だいじょうぶ、順番に見ていこう。この5つがわかれば、検討はぐっと進むよ。")}

  <nav class="review-toc" aria-label="この記事の目次">
    <h2>この記事でわかること</h2>
    <ol>
      <li><a href="#what">どんな資格?(国家資格・できること)</a></li>
      <li><a href="#how">取得までの道のり</a></li>
      <li><a href="#cost">費用の総額(全部でいくら?)</a></li>
      <li><a href="#kyufu">給付金でいくら戻る?(計算機つき)</a></li>
      <li><a href="#difficulty">難易度と勉強時間</a></li>
      <li><a href="#work">働きながら・子育てしながら取れる?</a></li>
      <li><a href="#faq">よくある質問</a></li>
      <li><a href="#next">次のステップ</a></li>
    </ol>
  </nav>

  <section id="what">
    <h2>1. キャリアコンサルタントって、どんな資格?</h2>
    <p>キャリアコンサルタントは、働く人の「職業の選択」や「キャリアの設計」「能力開発」の相談にのる専門家で、<strong>2016年にできた国家資格</strong>です(職業能力開発促進法に基づく登録制)。資格がない人は「キャリアコンサルタント」と名乗れない<strong>名称独占資格</strong>で、登録は5年ごとに更新します。</p>
    <p>活躍の場は、企業の人事・人材開発、ハローワークなどの就労支援機関、大学のキャリアセンター、人材会社など。「人の話を聴いて、その人らしい選択を支える」ことが仕事の中心です。</p>
  </section>

  <section id="how">
    <h2>2. 取得までの道のり</h2>
    <p>いちばん一般的なルートはこの3ステップです。</p>
    <ol class="shikaku-steps">
      <li><strong>養成講習を修了する</strong>(厚生労働大臣認定・150時間。通学+オンライン+自宅学習の組み合わせが主流。期間はおおむね3〜6か月)</li>
      <li><strong>国家試験に合格する</strong>(学科+実技〈論述・面接〉。試験実施団体はキャリアコンサルティング協議会とJCDAの2つで、どちらで合格しても同じ国家資格)</li>
      <li><strong>登録する</strong>(名簿に登録して、はれて「キャリアコンサルタント」に)</li>
    </ol>
    <p>なお、相談業務の実務経験が3年以上ある方などは、講習を受けずに受験できるルートもあります。</p>
  </section>

  <section id="cost">
    <h2>3. 費用の総額 — 全部でいくら?</h2>
    <p>「講座代」だけ見ていると、あとから受験料や登録料が出てきておどろくので、先に全体像をどうぞ。</p>
    <table class="shikaku-cost-table">
      <thead><tr><th>項目</th><th>金額の目安</th><th>メモ</th></tr></thead>
      <tbody>
        <tr><td>養成講習</td><td>約30〜45万円</td><td>学校により差。多くが給付金の対象</td></tr>
        <tr><td>受験料(学科)</td><td>8,900円</td><td>両試験団体とも共通</td></tr>
        <tr><td>受験料(実技)</td><td>29,900円</td><td>論述+面接</td></tr>
        <tr><td>登録(初回)</td><td>17,000円ほど</td><td>登録免許税9,000円+登録手数料8,000円</td></tr>
        <tr><td>更新講習(5年ごと)</td><td>数万円〜</td><td>知識講習8時間+技能講習30時間以上</td></tr>
      </tbody>
    </table>
    <p>ざっくり言うと、<strong>給付金を使わない場合の初期費用は合計35〜50万円前後</strong>。ここから次の給付金で大きく戻ってくる可能性があります。</p>
  </section>

  <section id="kyufu">
    <h2>4. 給付金でいくら戻る?(専門実践教育訓練給付)</h2>
    ${CharacterGuide("sunny", "ここがいちばん大事。対象講座なら、受講料の半分以上が戻ってくることも多いんだよ。")}
    <p>多くの養成講習は、雇用保険の<strong>専門実践教育訓練給付</strong>の対象です。要件を満たすと、受講費用の<strong>50%</strong>(受講中に支給)+資格取得して就職等につながると<strong>+20%</strong>、さらに賃金上昇などの要件を満たすと<strong>+10%</strong>で、<strong>最大80%</strong>が支給されます(それぞれ年間の上限額あり)。</p>
    <div class="kyufu-calc" id="kyufu-calc">
      <h3>💰 実質負担額かんたん計算機</h3>
      <div class="kyufu-calc__row">
        <label for="kyufu-fee">講座の受講料(円):</label>
        <input type="number" id="kyufu-fee" value="350000" min="0" step="10000" inputmode="numeric">
      </div>
      <table class="shikaku-cost-table kyufu-calc__result">
        <thead><tr><th>ケース</th><th>戻る額</th><th>実質負担</th></tr></thead>
        <tbody>
          <tr><td>受講修了(50%)</td><td data-kyufu="50">—</td><td data-jifu="50">—</td></tr>
          <tr><td>+資格取得・就職等(70%)</td><td data-kyufu="70">—</td><td data-jifu="70">—</td></tr>
          <tr><td>+賃金上昇(最大80%)</td><td data-kyufu="80">—</td><td data-jifu="80">—</td></tr>
        </tbody>
      </table>
      <p class="kyufu-calc__note">※年間上限(50%: 40万円 / 70%: 56万円 / 80%: 64万円)を自動で反映した概算です。受給には雇用保険の加入期間などの条件があり、手続きは受講開始<strong>前</strong>にハローワークで行う必要があります。</p>
    </div>
    <aside class="law-notice">
      <p class="law-notice__lead">⚠️ 金額・給付率は<strong>2026年7月時点</strong>で確認したものです。制度は変わることがあるので、申込み前に必ず一次資料と学校の案内で確認してね。</p>
      <ul class="law-notice__links">
        <li><a href="https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/jinzaikaihatsu/kyouiku.html" target="_blank" rel="noopener">厚生労働省(教育訓練給付制度) →</a></li>
        <li><a href="https://www.career-shiken.org/" target="_blank" rel="noopener">キャリアコンサルティング協議会 →</a></li>
        <li><a href="https://www.jcda-careerex.org/" target="_blank" rel="noopener">JCDA(日本キャリア開発協会) →</a></li>
      </ul>
    </aside>
  </section>

  <section id="difficulty">
    <h2>5. 難易度と勉強時間</h2>
    <p>合格率は回によって変動しますが、学科・実技それぞれ<strong>おおむね50〜60%台</strong>で推移することが多く、国家資格の中では「正しく準備すれば、初学者でも十分ねらえる」水準です。直近の合格率は上の試験団体の公式サイトで毎回公表されています。</p>
    <p>勉強時間の目安は、講習150時間に加えて<strong>自習100〜200時間</strong>ほど。つまずきポイントの多くは「専門用語のむずかしさ」— まさにこのサイト(ことば図鑑)が生まれた理由です。</p>
    ${CharacterGuide("moyan", "用語の意味さえわかれば、こわくないんだね…!")}
  </section>

  <section id="work">
    <h2>6. 働きながら・子育てしながら取れる?</h2>
    <p>取れます。むしろ受講生の多くは社会人・子育て中の方です。講習の通学(またはオンラインのライブ授業)は<strong>週1日×3〜6か月</strong>のコースが主流で、平日夜・土日コース、録画振替のある学校も。生活に合わせた学校選びのコツは、こちらのガイドにまとめてあります。</p>
    <ul class="shikaku-links">
      <li><a href="/school-guides/working-mothers/">👶 子育て中の学校選び — 送迎・急な発熱と両立するコツ</a></li>
      <li><a href="/school-guides/online/">💻 オンライン講座の選び方</a></li>
    </ul>
  </section>

  <section id="faq">
    <h2>7. よくある質問</h2>
    <dl class="shikaku-faq">
      <div><dt>Q. 独学だけで受験できますか?</dt><dd>実務経験(3年以上)などがない場合は、養成講習の修了が受験の条件になります。多くの人は講習ルートです。</dd></div>
      <div><dt>Q. 試験団体が2つあるけど、どちらがいいの?</dt><dd>合格すれば同じ国家資格です。実技(面接)の評価観点に持ち味の違いがあるので、通う学校がどちらに対応しているかも参考に。くわしくは<a href="/school-guides/training-and-exam-preparation/">講習と試験対策の違いガイド</a>へ。</dd></div>
      <div><dt>Q. 資格を取ったら、すぐ食べていけますか?</dt><dd>正直に言うと、資格だけで自動的に仕事が来るものではありません。企業内での活用、就労支援機関、副業的な活動など生かし方はさまざま。<a href="/careers/">資格取得後の働き方</a>に現実的な情報をまとめています。</dd></div>
      <div><dt>Q. 更新にもお金がかかる?</dt><dd>5年ごとの更新に講習受講(知識8時間+技能30時間以上)が必要で、費用は数万円〜が目安です。取得後のコストも含めて検討するのがおすすめ。</dd></div>
    </dl>
  </section>

  <section id="next" class="shikaku-next">
    <h2>8. 次のステップ</h2>
    ${CharacterGuide("sunny", "検討の順番はこれがおすすめ。あわてなくて大丈夫、1つずつね。")}
    <ol class="shikaku-steps">
      <li><a href="/school-guides/how-to-choose/">養成学校の選び方</a>を読む(比べる前に決めること3つ)</li>
      <li><a href="/schools/compare/">学校を比較</a>して、2〜3校にしぼる</li>
      <li>気になる学校の説明会・資料で最終確認(給付金対象かも必ずチェック)</li>
      <li>迷ったら<a href="/school-reviews/chiiki-renkei-platform/">運営者の受講記録</a>ものぞいてみてね</li>
    </ol>
    <div class="hero__actions" style="justify-content:center;margin-top:22px;">
      <a class="button button--primary" href="/schools/">養成学校一覧を見る</a>
      <a class="button button--secondary" href="/terms/">ことば図鑑をのぞいてみる</a>
    </div>
  </section>
</article>
<script src="/js/kyufu-calc.js" defer></script>`;

  return renderPage({
    title: "キャリアコンサルタント資格まるわかりガイド(費用・給付金・難易度)",
    description:
      "キャリアコンサルタント資格の全体像を1ページで。国家資格の中身、取得ルート、費用総額の目安、教育訓練給付でいくら戻るかの計算機、合格率・勉強時間、働きながら・子育てしながらの取り方まで。",
    path: "/shikaku-guide/",
    body,
    crumbs: [{ name: "ホーム", url: "/" }, { name: "資格まるわかりガイド" }],
  });
}
