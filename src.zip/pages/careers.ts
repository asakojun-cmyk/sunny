import { renderPage } from "../components/Layout";
import { RelatedContents } from "../components/RelatedContents";
import { AuthorProfile } from "../components/AuthorProfile";
import { UpdatedDate } from "../components/UpdatedDate";
import { SITE } from "../lib/site";

/** 資格取得後の働き方 */
export function careersPage(): string {
  const body = `
<article class="container container--article guide-article">
  <header class="article-header">
    <p class="article-header__meta"><span class="article-card__category">資格取得後</span></p>
    <h1>キャリアコンサルタント資格取得後の働き方</h1>
    <p class="article-header__lede">「資格を取ったら、どこで、どんなふうに働けるのか」。煽らず、現実的に選択肢を整理します。</p>
    ${UpdatedDate({ updatedAt: "2026-07-11" })}
  </header>

  <aside class="notice-box">
    <p>収入・求人の状況は地域・時期・経験によって大きく異なります。このページでは、一次資料で確認できない具体的な収入額や求人数は記載していません。</p>
  </aside>

  <section class="guide-section">
    <h2>キャリアコンサルタントのおもな仕事</h2>
    <p>キャリアコンサルタントは、相談者の職業選択やキャリア形成を支援する国家資格の専門職です。仕事の中心は、面談を通じた相談支援ですが、セミナー講師、研修の企画・運営、書類添削や面接練習の支援など、活動の形はさまざまです。</p>
  </section>

  <section class="guide-section">
    <h2>資格を生かせるおもな場</h2>
    <ul>
      <li><strong>企業内</strong> — 人事・キャリア開発部門などで、従業員のキャリア面談や研修に関わる。今の職場で資格を生かす形もこれに含まれます。</li>
      <li><strong>学校</strong> — 大学のキャリアセンターなどで、学生の就職支援に関わる。</li>
      <li><strong>公的機関</strong> — ハローワークや地域の就労支援機関などで、求職者の支援に関わる。</li>
      <li><strong>人材関連企業</strong> — 人材紹介・派遣会社などで、求職者と企業のマッチングに関わる。</li>
      <li><strong>独立・副業</strong> — 個人で相談業務・セミナー・執筆などを行う。</li>
    </ul>
  </section>

  <section class="guide-section">
    <h2>在宅・副業で働けるのか</h2>
    <p>オンライン面談の普及により、在宅でキャリア相談を行う働き方は選択肢として存在します。ただし、資格を取っただけで自動的に仕事が来るわけではなく、経験を積む場をどう作るかが最初の課題になる、というのが多くの先輩たちの共通した話です。</p>
    <p>子育て中の人にとっては、「まず今の仕事や身近な場で相談スキルを使う→小さく経験を積む→働き方を広げる」という段階的な進み方が現実的です。</p>
  </section>

  <section class="guide-section">
    <h2>資格の更新について</h2>
    <p>キャリアコンサルタントは登録制の資格で、登録の更新には更新講習(知識講習・技能講習)の受講が必要とされています。更新の要件・時間数などの正式な情報は、国(厚生労働省)や登録センターの公式情報で確認してください。</p>
  </section>

  <section class="guide-section">
    <h2>子育て・暮らしへの活用</h2>
    <p>資格の学びは、仕事だけでなく暮らしにも生きます。傾聴や感情の反映は親子のコミュニケーションに、キャリア理論は自分自身の転機(転勤・育児・介護・復職)を整理するのに役立ちます。<a href="/terms/">ことば図鑑</a>の各用語ページには「子育て・仕事で考えると」の欄を用意しています。</p>
  </section>

  ${RelatedContents(
    [
      { type: "ガイド", title: "養成学校の選び方", url: "/school-guides/how-to-choose/" },
      { type: "ガイド", title: "養成講習と試験対策講座の違い", url: "/school-guides/training-and-exam-preparation/" },
      { type: "用語", title: "ことば図鑑(用語一覧)", url: "/terms/" },
    ],
    "あわせて読みたい"
  )}
  ${AuthorProfile(true)}
</article>`;

  return renderPage({
    title: "キャリアコンサルタント資格取得後の働き方",
    description:
      "キャリアコンサルタント資格取得後の働き方を整理。企業・学校・公的機関・独立・副業・在宅での可能性と、更新講習・子育てへの活用まで初学者向けに解説します。",
    path: "/careers/",
    activeNav: "/careers/",
    ogType: "article",
    crumbs: [{ name: "ホーム", url: "/" }, { name: "資格取得後の働き方" }],
    structuredData: [
      {
        "@context": "https://schema.org",
        "@type": "Article",
        headline: "キャリアコンサルタント資格取得後の働き方",
        description:
          "資格取得後の働き方の選択肢を、煽らず現実的に整理した記事。",
        dateModified: "2026-07-11",
        author: { "@type": "Person", name: SITE.author.name },
        mainEntityOfPage: `${SITE.baseUrl}/careers/`,
      },
    ],
    body,
  });
}
