import { renderPage } from "../components/Layout";
import { InfoLabel, InfoBlock } from "../components/InfoLabel";
import { DisclosureBox } from "../components/PrLabel";
import { UpdatedDate } from "../components/UpdatedDate";
import { RelatedContents } from "../components/RelatedContents";
import { AuthorProfile } from "../components/AuthorProfile";
import { esc } from "../lib/html";
import { SITE } from "../lib/site";
import {
  chiikiReview,
  reviewOutline,
  TODO,
} from "../data/school-reviews/chiiki-renkei-platform";
import { getSchool } from "../data/schools/index";

const RELATIONSHIP_LABEL: Record<string, string> = {
  "currently-enrolled": "受講中",
  completed: "修了",
  "passed-exam": "試験合格",
  other: "その他",
};

/**
 * 地域連携プラットフォーム受講体験のひな型ページ。
 * 本文(body)はAIで創作せず、運営者の実体験メモだけを表示する。
 * 未記入の見出しには「準備中」と表示する。
 */
export function chiikiReviewPage(): string {
  const school = getSchool(chiikiReview.schoolSlug);
  const isDraft = chiikiReview.publicationStatus !== "published";

  const outlineHtml = reviewOutline
    .map((section) => {
      const filled = section.body !== TODO && section.body.trim() !== "";
      return `<section class="review-section" id="${esc(section.id)}">
      <h2>${esc(section.heading)}</h2>
      ${
        filled
          ? `<p>${esc(section.body)}</p>`
          : `<p class="review-section__placeholder">この項目は現在執筆中です。運営者の実体験のみを掲載するため、体験が整理でき次第公開します。</p>`
      }
    </section>`;
    })
    .join("");

  const body = `
<article class="container container--article review-article">
  <header class="article-header">
    <p class="article-header__meta">
      <span class="article-card__category">受講体験</span>
      ${InfoLabel("experience")}
    </p>
    <h1>一般社団法人地域連携プラットフォーム 受講体験記</h1>
    <p class="article-header__lede">${esc(SITE.author.name)}(${esc(
      RELATIONSHIP_LABEL[chiikiReview.relationship] ?? ""
    )})が、実際に受講して感じたことを記録しています。</p>
    ${UpdatedDate({ updatedAt: chiikiReview.reviewUpdatedAt })}
  </header>

  ${DisclosureBox({
    isPr: false,
    receivedCompensation: false,
    containsAffiliateLinks: false,
    paidByAuthor: true,
  })}

  ${
    isDraft
      ? `<aside class="notice-box">
    <p>この体験記は現在、運営者が受講しながら執筆している途中です。体験談の本文はAIで作らず、運営者本人の記録だけを掲載する方針のため、順次公開していきます。</p>
  </aside>`
      : ""
  }

  ${InfoBlock(
    "official",
    `<p>この学校の料金・期間・制度などの公式情報は、<a href="/schools/chiiki-renkei-platform/">学校情報ページ</a>にまとめています(公式サイトへのリンク・情報確認日つき)。</p>
    ${school ? `<p><a href="${esc(school.officialUrl)}" rel="noopener nofollow" target="_blank">公式サイトはこちら</a></p>` : ""}`
  )}

  <nav class="review-toc" aria-label="この記事の目次">
    <h2>この記事でわかること</h2>
    <ol>
      ${reviewOutline
        .map((s) => `<li><a href="#${esc(s.id)}">${esc(s.heading)}</a></li>`)
        .join("")}
    </ol>
  </nav>

  ${outlineHtml}

  <aside class="notice-box">
    <p>この記事では、個人名・他の受講生の発言・授業内の秘密情報は掲載しません。受講生専用ページ・教材・課題・講師資料・オンライン授業画面などの転載も行いません。</p>
  </aside>

  ${RelatedContents(
    [
      {
        type: "学校",
        title: "地域連携プラットフォームの講座情報",
        url: "/schools/chiiki-renkei-platform/",
        description: "公式情報・料金・給付金・出典はこちら",
      },
      { type: "比較", title: "養成学校を比較する", url: "/schools/compare/" },
      {
        type: "ガイド",
        title: "子育て中の学校選び",
        url: "/school-guides/working-mothers/",
      },
    ],
    "あわせて読みたい"
  )}
  ${AuthorProfile(true)}
</article>`;

  return renderPage({
    title: "地域連携プラットフォーム受講体験記(運営者本人)",
    description:
      "国家資格キャリアコンサルタント養成講習(一般社団法人地域連携プラットフォーム)を、サイト運営者本人が受講して感じたことの記録。公式情報と体験を分けて掲載しています。",
    path: "/school-reviews/chiiki-renkei-platform/",
    activeNav: "/schools/",
    ogType: "article",
    crumbs: [
      { name: "ホーム", url: "/" },
      { name: "養成学校一覧", url: "/schools/" },
      { name: "地域連携プラットフォーム受講体験" },
    ],
    structuredData: [
      {
        "@context": "https://schema.org",
        "@type": "Article",
        headline: "一般社団法人地域連携プラットフォーム 受講体験記",
        description:
          "サイト運営者本人による受講体験の記録。公式情報と体験を分けて掲載。",
        dateModified: chiikiReview.reviewUpdatedAt,
        author: { "@type": "Person", name: SITE.author.name },
        mainEntityOfPage: `${SITE.baseUrl}/school-reviews/chiiki-renkei-platform/`,
      },
    ],
    body,
  });
}
