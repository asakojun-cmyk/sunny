// TypeScript ファイル(lib/components/data/pages/build.ts)は `npm run typecheck` (tsc --noEmit)
// で検査する。ESLint はブラウザ用のプレーン JS (public/js) を対象にする。
// (この環境では @eslint/js が利用できないため、コアルールを直接指定している)

const coreRules = {
  "no-unused-vars": [
    "error",
    { argsIgnorePattern: "^_", caughtErrorsIgnorePattern: "^_" },
  ],
  "no-undef": "error",
  "no-redeclare": "error",
  "no-dupe-keys": "error",
  "no-dupe-args": "error",
  "no-unreachable": "error",
  "no-constant-condition": "error",
  "no-empty": ["error", { allowEmptyCatch: true }],
  eqeqeq: ["error", "smart"],
  "no-var": "off",
  "prefer-const": "off",
};

const browserGlobals = {
  window: "readonly",
  document: "readonly",
  IntersectionObserver: "readonly",
  localStorage: "readonly",
  fetch: "readonly",
  URLSearchParams: "readonly",
  URL: "readonly",
  location: "readonly",
  history: "readonly",
  console: "readonly",
  navigator: "readonly",
  setTimeout: "readonly",
  clearTimeout: "readonly",
};

export default [
  {
    ignores: ["dist/**", "node_modules/**", "**/*.ts"],
  },
  {
    files: ["public/js/**/*.js"],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: "script",
      globals: browserGlobals,
    },
    rules: coreRules,
  },
  {
    files: ["eslint.config.mjs"],
    languageOptions: { ecmaVersion: 2022, sourceType: "module" },
    rules: coreRules,
  },
];
