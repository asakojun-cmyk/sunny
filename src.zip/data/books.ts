/**
 * さらに学べる本棚。
 * - amazonUrl は「書名での検索リンク」を基本にする(版・ASINの間違い防止)。
 *   運営者が実物のURLを確認したら url を商品ページに差し替えてよい。
 * - AFFILIATE_TAG が空文字の間は、ただの紹介リンク(収益なし・PR表記なし)。
 *   Amazonアソシエイト等の審査に通ったらタグを設定する。
 *   タグを設定すると、全リンクに自動でタグが付き、PR表記と開示文が表示される。
 */

/** アソシエイト審査通過後にここへタグを入れる(例: "sunny-22")。空なら通常リンク */
export const AFFILIATE_TAG = "";

/** タグ設定時にサイトに表示する開示文(Amazonアソシエイト規約の必須文言) */
export const AFFILIATE_DISCLOSURE =
  "Amazonのアソシエイトとして、当サイトは適格販売により収入を得ています。";

export type Book = {
  id: string;
  title: string;
  author: string;
  publisher?: string;
  /** サニー先生のひとこと(どんな人に、なぜおすすめか) */
  note: string;
  /** だれ向けか */
  audience: "受験生の定番" | "理論の原典" | "読みものとして";
  amazonUrl: string;
  theoristSlugs?: string[];
  termSlugs?: string[];
};

function search(q: string): string {
  return `https://www.amazon.co.jp/s?k=${encodeURIComponent(q)}`;
}

export const books: Book[] = [
  /* ===== 受験生の定番テキスト ===== */
  {
    id: "watanabe-shinri",
    title: "新版 キャリアの心理学",
    author: "渡辺三枝子(編著)",
    publisher: "ナカニシヤ出版",
    note: "理論家ごとに章が分かれた、キャリア理論の定番教科書。このサイトの理論家図鑑で全体像をつかんでから読むと、すらすら入ってくるよ。",
    audience: "受験生の定番",
    amazonUrl: search("新版 キャリアの心理学 渡辺三枝子"),
    theoristSlugs: ["super", "schein", "krumboltz", "savickas", "holland", "schlossberg", "hall", "gelatt"],
  },
  {
    id: "kimura-riron-jissai",
    title: "キャリアコンサルティング 理論と実際",
    author: "木村周・下村英雄",
    publisher: "雇用問題研究会",
    note: "「キャリコンのバイブル」と呼ばれる分厚い1冊。試験範囲をほぼ網羅していて、養成講座の副読本としても定番。辞書のように使うのがコツ。",
    audience: "受験生の定番",
    amazonUrl: search("キャリアコンサルティング 理論と実際 木村周"),
  },
  {
    id: "kakomon-mondaishu",
    title: "学科試験の過去問題集・対策本(最新年度版)",
    author: "各社",
    note: "過去問集と一問一答は毎年新しい年度版が出るから、必ず「最新版」を選んでね。検索結果の発行年月をチェック!",
    audience: "受験生の定番",
    amazonUrl: search("国家資格キャリアコンサルタント 学科試験 過去問"),
  },
  /* ===== 理論の原典・理論家の本 ===== */
  {
    id: "schein-anchor",
    title: "キャリア・アンカー ― 自分のほんとうの価値を発見しよう",
    author: "エドガー・H・シャイン",
    publisher: "白桃書房",
    note: "「キャリア・アンカー」の本人による解説書。自己診断もできるから、自分のアンカー探しにも使えるよ。",
    audience: "理論の原典",
    amazonUrl: search("キャリア・アンカー シャイン 白桃書房"),
    theoristSlugs: ["schein"],
    termSlugs: ["career-anchor"],
  },
  {
    id: "krumboltz-guuzen",
    title: "その幸運は偶然ではないんです!",
    author: "J.D.クランボルツ / A.S.レヴィン",
    publisher: "ダイヤモンド社",
    note: "「計画された偶発性」を、実話たっぷりで語る読みやすい1冊。理論書というよりエッセイ感覚。勉強に疲れた夜にもおすすめ。",
    audience: "理論の原典",
    amazonUrl: search("その幸運は偶然ではないんです クランボルツ"),
    theoristSlugs: ["krumboltz"],
    termSlugs: ["planned-happenstance"],
  },
  {
    id: "savickas-riron",
    title: "サビカス キャリア・カウンセリング理論",
    author: "マーク・L・サビカス",
    publisher: "福村出版",
    note: "キャリア構築理論を本人の言葉で。ナラティブ・アプローチの空気感が伝わる、論述対策にも効く1冊。",
    audience: "理論の原典",
    amazonUrl: search("サビカス キャリアカウンセリング理論"),
    theoristSlugs: ["savickas"],
    termSlugs: ["career-kochiku-riron", "narrative-approach"],
  },
  {
    id: "bridges-transition",
    title: "トランジション ― 人生の転機を活かすために",
    author: "ウィリアム・ブリッジズ",
    publisher: "パンローリング",
    note: "「終わり→中立圏→始まり」の原典。転機のまっただ中にいる人が読むと、自分の今地点に名前がついて、ふっと楽になる本。",
    audience: "理論の原典",
    amazonUrl: search("トランジション 人生の転機を活かすために ブリッジズ"),
    theoristSlugs: ["bridges"],
    termSlugs: ["transition-riron"],
  },
  {
    id: "frankl-yoru",
    title: "夜と霧",
    author: "ヴィクトール・E・フランクル",
    publisher: "みすず書房",
    note: "ロゴセラピーの背景にある体験そのもの。試験のためというより、人を支える仕事につく人の一生ものの1冊として。",
    audience: "読みものとして",
    amazonUrl: search("夜と霧 フランクル みすず書房"),
    termSlugs: ["logotherapy"],
  },
  {
    id: "kirawareru-yuki",
    title: "嫌われる勇気",
    author: "岸見一郎・古賀史健",
    publisher: "ダイヤモンド社",
    note: "アドラー心理学を対話形式で。目的論・課題の分離・共同体感覚が物語で腹落ちする大ベストセラー。コラム好きの人にぴったり。",
    audience: "読みものとして",
    amazonUrl: search("嫌われる勇気 岸見一郎"),
    termSlugs: ["adler-shinrigaku"],
  },
  {
    id: "kokubu-counseling",
    title: "カウンセリングの理論",
    author: "國分康孝",
    publisher: "誠信書房",
    note: "コーヒーカップ・モデルの國分先生による、各カウンセリング理論のやさしい見取り図。流派の整理に迷ったらこれ。",
    audience: "受験生の定番",
    amazonUrl: search("カウンセリングの理論 國分康孝"),
    theoristSlugs: ["kokubu"],
    termSlugs: ["coffee-cup-model"],
  },
];

/** タグ付きURLを返す(タグ未設定ならそのまま) */
export function bookUrl(b: Book): string {
  if (!AFFILIATE_TAG) return b.amazonUrl;
  const sep = b.amazonUrl.includes("?") ? "&" : "?";
  return `${b.amazonUrl}${sep}tag=${AFFILIATE_TAG}`;
}

export function booksForTheorist(slug: string): Book[] {
  return books.filter((b) => b.theoristSlugs?.includes(slug));
}

export function booksForTerm(slug: string): Book[] {
  return books.filter((b) => b.termSlugs?.includes(slug));
}
