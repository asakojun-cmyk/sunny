import type { School } from "../../lib/types";

const OFFICIAL_URL = "https://careerjp.work/cc1/";
const CHECKED_AT = "2026-07-11";

/**
 * 一般社団法人地域連携プラットフォーム
 * 運営者が実際に受講している学校。
 *
 * ※ officialFacts は公式サイトの記載を転記したもの。
 *   公開前・更新時に必ず公式サイトを再確認し、checkedAt を更新すること。
 *   料金・日程・給付金・特典は変更される可能性がある。
 */
export const chiikiRenkeiPlatform: School = {
  id: "school-chiiki-renkei-platform",
  slug: "chiiki-renkei-platform",
  name: "一般社団法人地域連携プラットフォーム",
  operatorName: "一般社団法人地域連携プラットフォーム",
  officialUrl: OFFICIAL_URL,

  informationStatus: "partially_verified",

  deliveryModes: ["online-live", "hybrid"],

  courseDuration: "約0.5〜3ヶ月(コースにより異なる)",
  liveLessonHours: 80,

  tuition: 297000,
  admissionFee: 0,
  materialFee: 0,
  displayedTotalCost: 297000,

  educationBenefitAvailable: true,
  benefitNotes:
    "専門実践教育訓練給付金の指定講座(指定番号は公式サイト記載)。給付額・自己負担額は個人の雇用保険加入状況などの条件によって異なるため、申込み前に必ずハローワークと公式サイトで確認してください。",

  scheduleOptions: [
    "土曜・日曜・祝日コース",
    "平日コース",
    "午前・午後・夜間コース",
  ],
  classSize: "1コース20名(公式サイト記載)",
  makeupPolicy: "Zoom講習80時間のうち16時間まで無料で振替可(公式サイト記載)",

  assignmentFormat: "通信添削課題(すべて提出・合格が修了要件)",
  completionRequirements: [
    "習得度確認試験に合格すること",
    "出席時間が規定を満たしていること",
    "通信添削課題をすべて提出し合格すること",
  ],

  roleplayTraining:
    "Zoomでのライブ講習内で実施(詳細な時間配分は未確認)",
  examPreparationIncluded: false,
  examPreparationNotes:
    "国家試験対策講座は養成講習とは別講座。受講生・卒業生価格で受講できる(公式サイト記載)。",

  postQualificationSupport: [
    "懇親会・情報交換会",
    "就業支援",
    "独立開業支援",
    "上位資格講座",
    "アシスタント参加の機会",
  ],

  /** 「運営者の考察」ラベルで表示する */
  recommendedFor: [
    "オンライン(Zoom)中心で受講を完結させたい人",
    "平日・土日祝・夜間などライフスタイルに合わせて日程を選びたい人",
    "振替制度を使いながら家庭や仕事と両立したい人",
  ],
  cautions: [
    "国家試験対策講座は別料金なので、総費用は試験対策も含めて見積もる必要がある",
    "コースにより期間が大きく異なるため、自分の学習ペースに合うコースかを確認する",
  ],

  officialFacts: [
    {
      label: "講習名",
      value: "キャリアコンサルタント養成講習(厚生労働大臣認定)",
      sourceUrl: OFFICIAL_URL,
      checkedAt: CHECKED_AT,
    },
    {
      label: "受講形式",
      value:
        "オンライン(Zoom)。通学5日間+オンライン5日間のハイブリッドコースも選択可",
      sourceUrl: OFFICIAL_URL,
      checkedAt: CHECKED_AT,
    },
    {
      label: "受講期間",
      value:
        "通常コース約3ヶ月/最短最速コース約1.5ヶ月/集中コース約0.5ヶ月",
      sourceUrl: OFFICIAL_URL,
      checkedAt: CHECKED_AT,
    },
    {
      label: "講習時間",
      value: "Zoom講習80時間(このほかに通信学習あり。内訳の詳細は未確認)",
      sourceUrl: OFFICIAL_URL,
      checkedAt: CHECKED_AT,
    },
    {
      label: "受講料",
      value: "297,000円(税込)",
      sourceUrl: OFFICIAL_URL,
      checkedAt: CHECKED_AT,
      note: "キャンペーン・特典により変わる場合があります。申込み前に公式サイトで最新の料金を確認してください。",
    },
    {
      label: "入学金・教材費",
      value: "入学金なし・テキスト代込み",
      sourceUrl: OFFICIAL_URL,
      checkedAt: CHECKED_AT,
    },
    {
      label: "定員",
      value: "1コース20名",
      sourceUrl: OFFICIAL_URL,
      checkedAt: CHECKED_AT,
    },
    {
      label: "振替制度",
      value: "Zoom講習80時間のうち16時間まで無料で振替可",
      sourceUrl: OFFICIAL_URL,
      checkedAt: CHECKED_AT,
    },
    {
      label: "修了要件",
      value:
        "習得度確認試験合格/出席時間が規定を満たすこと/通信添削課題すべて提出・合格",
      sourceUrl: OFFICIAL_URL,
      checkedAt: CHECKED_AT,
    },
    {
      label: "教育訓練給付",
      value:
        "専門実践教育訓練給付金の対象講座(給付割合・条件は公式サイトとハローワークで要確認)",
      sourceUrl: OFFICIAL_URL,
      checkedAt: CHECKED_AT,
    },
    {
      label: "試験対策講座",
      value:
        "養成講習とは別講座。受講生・卒業生価格で受講可能",
      sourceUrl: OFFICIAL_URL,
      checkedAt: CHECKED_AT,
    },
    {
      label: "卒業後のサポート",
      value:
        "懇親会・情報交換会・就業支援・独立開業支援・上位資格講座・アシスタント参加の機会",
      sourceUrl: OFFICIAL_URL,
      checkedAt: CHECKED_AT,
    },
    {
      label: "割引・特典",
      value:
        "給付金対象外特典、ペア特典、シニア特典、紹介特典、子育て特典、学生特典などの記載あり(適用条件は要確認)",
      sourceUrl: OFFICIAL_URL,
      checkedAt: CHECKED_AT,
      note: "特典の内容・金額は変更される可能性があります。",
    },
  ],

  sources: [
    {
      label: "地域連携プラットフォーム キャリアコンサルタント養成講習(公式サイト)",
      url: OFFICIAL_URL,
      sourceType: "official-school",
      checkedAt: CHECKED_AT,
    },
  ],

  highlights: [
    "オンライン(Zoom)中心で完結できる",
    "入学金なし・テキスト代込み",
    "80時間中16時間まで無料振替",
  ],
  filterTags: [
    "online",
    "weekend",
    "weekday",
    "evening",
    "short-term",
    "benefit",
    "makeup",
    "after-support",
  ],
  isPr: false,

  verifiedAt: CHECKED_AT,
  updatedAt: CHECKED_AT,
};
