import type { School } from "../../lib/types";
import { chiikiRenkeiPlatform } from "./chiiki-renkei-platform";
import {
  nipponManpower,
  lec,
  recurrent,
  humanAcademy,
  pasona,
} from "./other-schools";

/**
 * 学校を追加する手順:
 * 1. data/schools/ に新しいファイルを作り、School 型のデータを export する
 * 2. この配列に追加する
 * 3. 公式サイトで確認できた項目のみ埋める(確認できない項目は undefined のまま = 「未確認」表示)
 */
export const schools: School[] = [
  chiikiRenkeiPlatform,
  nipponManpower,
  lec,
  recurrent,
  humanAcademy,
  pasona,
];

export function getSchool(slug: string): School | undefined {
  return schools.find((s) => s.slug === slug);
}
