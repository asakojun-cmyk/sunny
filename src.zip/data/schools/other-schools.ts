import type { School } from "../../lib/types";

const CHECKED_AT = "2026-07-11";

/**
 * 地域連携プラットフォーム以外の学校のひな型。
 * informationStatus: "unverified" のあいだ、詳細ページには「調査中」と表示される。
 * 詳細を追記するときは、公式サイトを確認したうえで officialFacts と
 * sources の checkedAt を更新すること。推測で埋めない。
 */

export const nipponManpower: School = {
  id: "school-nippon-manpower",
  slug: "nippon-manpower",
  name: "日本マンパワー キャリアコンサルタント養成講座",
  operatorName: "株式会社日本マンパワー",
  officialUrl: "https://www.nipponmanpower.co.jp/cc/",
  informationStatus: "unverified",
  deliveryModes: [],
  sources: [
    {
      label: "日本マンパワー キャリアコンサルタント養成講座(公式サイト)",
      url: "https://www.nipponmanpower.co.jp/cc/",
      sourceType: "official-school",
      checkedAt: CHECKED_AT,
    },
  ],
  highlights: [],
  filterTags: [],
  isPr: false,
  updatedAt: CHECKED_AT,
};

export const lec: School = {
  id: "school-lec",
  slug: "lec",
  name: "LEC東京リーガルマインド キャリアコンサルタント養成講座",
  operatorName: "株式会社東京リーガルマインド",
  officialUrl: "https://www.lec-jp.com/caricon/",
  informationStatus: "unverified",
  deliveryModes: [],
  sources: [
    {
      label: "LEC東京リーガルマインド キャリアコンサルタント(公式サイト)",
      url: "https://www.lec-jp.com/caricon/",
      sourceType: "official-school",
      checkedAt: CHECKED_AT,
    },
  ],
  highlights: [],
  filterTags: [],
  isPr: false,
  updatedAt: CHECKED_AT,
};

export const recurrent: School = {
  id: "school-recurrent",
  slug: "recurrent",
  name: "リカレント キャリアコンサルタント養成講座",
  operatorName: "リカレント株式会社",
  officialUrl: "https://www.recurrent.co.jp/",
  informationStatus: "unverified",
  deliveryModes: [],
  sources: [
    {
      label: "リカレント(公式サイト)",
      url: "https://www.recurrent.co.jp/",
      sourceType: "official-school",
      checkedAt: CHECKED_AT,
    },
  ],
  highlights: [],
  filterTags: [],
  isPr: false,
  updatedAt: CHECKED_AT,
};

export const humanAcademy: School = {
  id: "school-human-academy",
  slug: "human-academy",
  name: "ヒューマンアカデミー キャリアコンサルタント養成講座",
  operatorName: "ヒューマンアカデミー株式会社",
  officialUrl: "https://haa.athuman.com/",
  informationStatus: "unverified",
  deliveryModes: [],
  sources: [
    {
      label: "ヒューマンアカデミー(公式サイト)",
      url: "https://haa.athuman.com/",
      sourceType: "official-school",
      checkedAt: CHECKED_AT,
    },
  ],
  highlights: [],
  filterTags: [],
  isPr: false,
  updatedAt: CHECKED_AT,
};

export const pasona: School = {
  id: "school-pasona",
  slug: "pasona",
  name: "パソナ キャリアコンサルタント養成講座",
  operatorName: "株式会社パソナ",
  officialUrl: "https://www.pasona.co.jp/",
  informationStatus: "unverified",
  deliveryModes: [],
  sources: [
    {
      label: "パソナグループ(公式サイト)",
      url: "https://www.pasona.co.jp/",
      sourceType: "official-school",
      checkedAt: CHECKED_AT,
    },
  ],
  highlights: [],
  filterTags: [],
  isPr: false,
  updatedAt: CHECKED_AT,
};
