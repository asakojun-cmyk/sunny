import type { ArticleMeta } from "../lib/types";

/**
 * ガイド記事・体験記のメタ情報(一覧・最新記事・注目記事に使用)。
 * editorsPick: true の記事が「はじめに読みたい記事」に表示される。
 * 閲覧数に基づくランキングは、実データが取れるようになってから導入する。
 */
export const articles: ArticleMeta[] = [
  {
    slug: "terms/jiko-gainen",
    title: "小学生でもわかる「自己概念」— スーパー理論の入口",
    description:
      "テキストの1ページ目でつまずきがちな「自己概念」を、心の中の紹介カードにたとえて解説します。",
    category: "ことば図鑑",
    categoryEn: "WORDS",
    publishedAt: "2026-07-11",
    updatedAt: "2026-07-11",
    isPr: false,
    beginnerFriendly: true,
    readingMinutes: 3,
    editorsPick: true,
  },
  {
    slug: "school-guides/working-mothers",
    title: "子育て中・仕事をしながら通いやすい養成講座の選び方",
    description:
      "振替制度・オンライン・夜間土日・課題量。両立のために申込み前に確認したい条件を整理しました。",
    category: "養成講座",
    categoryEn: "SCHOOLS",
    publishedAt: "2026-07-11",
    updatedAt: "2026-07-11",
    infoCheckedAt: "2026-07-11",
    isPr: false,
    beginnerFriendly: true,
    readingMinutes: 6,
    editorsPick: true,
  },
  {
    slug: "careers",
    title: "キャリアコンサルタント資格取得後の働き方",
    description:
      "企業・学校・公的機関・副業・独立。資格を取ったあとの選択肢を、煽らずに現実的に整理します。",
    category: "資格取得後",
    categoryEn: "FUTURE",
    publishedAt: "2026-07-11",
    updatedAt: "2026-07-11",
    isPr: false,
    readingMinutes: 5,
    editorsPick: true,
  },
  {
    slug: "school-reviews/chiiki-renkei-platform",
    title: "【受講記録】地域連携プラットフォームの養成講習を受講中",
    description:
      "運営者本人が受講中の養成講習の記録。公式情報と本人の体験を分けて書いています。",
    category: "受講体験",
    categoryEn: "MY STUDY JOURNAL",
    publishedAt: "2026-07-11",
    updatedAt: "2026-07-11",
    infoCheckedAt: "2026-07-11",
    isPr: false,
    readingMinutes: 8,
  },
  {
    slug: "school-guides/how-to-choose",
    title: "養成学校の選び方 — 比べる前に決めておく3つのこと",
    description:
      "「どこが一番いいか」ではなく「自分の暮らしに合うのはどこか」。学校選びの手順をまとめました。",
    category: "養成講座",
    categoryEn: "SCHOOLS",
    publishedAt: "2026-07-11",
    updatedAt: "2026-07-11",
    infoCheckedAt: "2026-07-11",
    isPr: false,
    beginnerFriendly: true,
    readingMinutes: 7,
  },
  {
    slug: "school-guides/online",
    title: "オンライン養成講座の選び方 — 自宅で学ぶ前に確認すること",
    description:
      "ライブ型とオンデマンド型の違い、通信環境、ロールプレイのやり方など、オンライン特有の確認ポイント。",
    category: "養成講座",
    categoryEn: "SCHOOLS",
    publishedAt: "2026-07-11",
    updatedAt: "2026-07-11",
    infoCheckedAt: "2026-07-11",
    isPr: false,
    readingMinutes: 5,
  },
  {
    slug: "school-guides/training-and-exam-preparation",
    title: "養成講習と試験対策講座の違い — 費用計画の前に知っておく",
    description:
      "「養成講習を修了すれば合格できる」とは限りません。2つの講座の役割の違いを整理します。",
    category: "養成講座",
    categoryEn: "SCHOOLS",
    publishedAt: "2026-07-11",
    updatedAt: "2026-07-11",
    infoCheckedAt: "2026-07-11",
    isPr: false,
    readingMinutes: 5,
  },
  {
    slug: "theorists/rogers",
    title: "ロジャーズの「受容」は、子どもを何でも許すこと?",
    description:
      "来談者中心療法の「無条件の肯定的配慮」を、子育ての場面から誤解なく理解します。",
    category: "理論家図鑑",
    categoryEn: "THEORISTS",
    publishedAt: "2026-07-11",
    updatedAt: "2026-07-11",
    isPr: false,
    beginnerFriendly: true,
    readingMinutes: 4,
  },
];

export const editorsPicks = articles.filter((a) => a.editorsPick);
export const latestArticles = [...articles].sort((a, b) =>
  b.publishedAt.localeCompare(a.publishedAt)
);
