/**
 * ミニゲームのデータ。
 * matchPairs: 「理論家カードあわせ」の組札。
 * theory は HTML 可(試験に出やすい数値・キーワードは <em> で赤字強調)。
 */

export type MatchPair = {
  /** 理論家 slug(似顔絵と理論家ページへのリンクに使用) */
  slug: string;
  name: string;
  /** 結びつける理論(赤字強調 <em> 入りHTML) */
  theory: string;
};

export const matchPairs: MatchPair[] = [
  { slug: "super", name: "スーパー", theory: "ライフ・キャリア・レインボー<em>(5つの発達段階)</em>" },
  { slug: "rogers", name: "ロジャーズ", theory: "来談者中心療法<em>(3条件)</em>" },
  { slug: "krumboltz", name: "クランボルツ", theory: "計画された偶発性<em>(5つのスキル)</em>" },
  { slug: "schein", name: "シャイン", theory: "キャリア・アンカー<em>(8つ)</em>" },
  { slug: "bandura", name: "バンデューラ", theory: "自己効力感<em>(4つの情報源)</em>" },
  { slug: "holland", name: "ホランド", theory: "六角形モデル<em>(RIASEC)</em>" },
  { slug: "schlossberg", name: "シュロスバーグ", theory: "転機を<em>4S</em>で点検" },
  { slug: "savickas", name: "サビカス", theory: "キャリア構築理論<em>(ライフテーマ)</em>" },
  { slug: "gelatt", name: "ジェラット", theory: "<em>肯定的不確実性</em>(意思決定)" },
  { slug: "parsons", name: "パーソンズ", theory: "特性因子理論<em>(丸いくぎは丸い穴に)</em>" },
  { slug: "erikson", name: "エリクソン", theory: "<em>8段階</em>の発達理論(アイデンティティ)" },
  { slug: "levinson", name: "レビンソン", theory: "人生の<em>四季</em>(中年の危機)" },
  { slug: "hall", name: "ホール", theory: "プロティアン・キャリア<em>(心理的成功)</em>" },
  { slug: "bridges", name: "ブリッジス", theory: "トランジション<em>(終焉→中立圏→開始)</em>" },
  { slug: "ivey", name: "アイビイ", theory: "マイクロカウンセリング<em>(かかわり行動)</em>" },
  { slug: "kokubu", name: "國分康孝", theory: "コーヒーカップ・モデル<em>(3段階)</em>" },
  { slug: "ellis", name: "エリス", theory: "論理療法<em>(ABC理論)</em>" },
  { slug: "hansen", name: "ハンセン", theory: "統合的人生設計<em>(4L)</em>" },
];
