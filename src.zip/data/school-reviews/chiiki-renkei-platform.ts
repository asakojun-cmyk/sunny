import type { SchoolReview } from "../../lib/types";

/**
 * 一般社団法人地域連携プラットフォームの受講体験。
 *
 * 【重要】体験談の本文はAIで作らない。
 * 運営者本人が実際に感じたこと・メモした内容だけを記入する。
 * 「(※運営者記入予定)」の箇所を実体験で置き換えたら、
 * publicationStatus を "published" に変更する。
 */
export const TODO = "(※運営者記入予定)";

export const chiikiReview: SchoolReview = {
  id: "review-chiiki-renkei-platform-001",
  schoolSlug: "chiiki-renkei-platform",

  authorName: "このサイトの運営者",
  relationship: "currently-enrolled",

  attendancePeriod: TODO,
  courseName: TODO,
  reviewUpdatedAt: "2026-07-11",

  reasonForChoosing: TODO,
  expectationsBeforeEnrollment: TODO,
  firstImpression: TODO,

  goodPoints: [{ title: "良かった点", body: TODO }],
  concerns: [{ title: "気になった点", body: TODO }],
  unexpectedPoints: [{ title: "予想外だった点", body: TODO }],

  lessonStyle: TODO,
  teacherImpression: TODO,
  roleplayExperience: TODO,
  assignmentExperience: TODO,

  weeklyStudyLoad: TODO,
  childcareCompatibility: TODO,
  workCompatibility: TODO,
  onlineLearningExperience: TODO,

  examPreparationExperience: TODO,
  communityExperience: TODO,
  postQualificationSupportExperience: TODO,

  recommendedFor: [],
  notRecommendedFor: [],

  adviceBeforeEnrollment: [],
  overallSummary: TODO,

  disclosure:
    "この記事は広告・PRではありません。学校から報酬や無償提供は受けていません。紹介リンクは含みません。運営者自身が受講料を支払って受講しています。",
  publicationStatus: "draft",
};

/** 体験記事の見出し構成(22項目)。本文はすべて運営者が記入する。 */
export const reviewOutline: { id: string; heading: string; body: string }[] = [
  { id: "why-career-consultant", heading: "私がキャリアコンサルタントを目指した理由", body: TODO },
  { id: "why-this-school", heading: "この養成学校を選んだ理由", body: TODO },
  { id: "worries-before", heading: "申込み前に不安だったこと", body: TODO },
  { id: "first-impression", heading: "実際に受講して感じた第一印象", body: TODO },
  { id: "day-flow", heading: "1日の授業の流れ", body: TODO },
  { id: "lecture-clarity", heading: "講義の分かりやすさ", body: TODO },
  { id: "group-work", heading: "グループワークについて", body: TODO },
  { id: "roleplay", heading: "ロールプレイについて", body: TODO },
  { id: "homework-time", heading: "課題と復習に必要だった時間", body: TODO },
  { id: "balance", heading: "仕事・家事・育児との両立", body: TODO },
  { id: "online-good", heading: "オンライン受講で良かったこと", body: TODO },
  { id: "online-hard", heading: "オンライン受講で困ったこと", body: TODO },
  { id: "teachers", heading: "講師やアシスタントについて", body: TODO },
  { id: "class-atmosphere", heading: "クラスの雰囲気", body: TODO },
  { id: "wish-i-knew", heading: "受講前に知っておきたかったこと", body: TODO },
  { id: "good-points", heading: "良かった点", body: TODO },
  { id: "concerns", heading: "気になった点", body: TODO },
  { id: "suits", heading: "どのような人に向いているか", body: TODO },
  { id: "not-suits", heading: "どのような人には合わない可能性があるか", body: TODO },
  { id: "exam-prep", heading: "試験対策は別に必要か", body: TODO },
  { id: "after-qualification", heading: "資格取得後の働き方をどう考えているか", body: TODO },
  { id: "advice", heading: "これから受講する人へのアドバイス", body: TODO },
];
