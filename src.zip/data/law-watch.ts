/**
 * 法律・統計・制度など「改正・更新で変わりうる用語」の管理台帳。
 * - checkedAt: 内容を最後に確認した日
 * - sources: 最新情報を確認できる一次資料
 * ここに載っている用語のページには、確認日と一次資料リンクの
 * 注意ボックスが自動で表示される。
 * 毎月の自動チェック(見張り番)もこの台帳を対象にする。
 */

export type LawSource = { label: string; url: string };

export const lawWatch: Record<
  string,
  { checkedAt: string; watchWords: string[]; sources: LawSource[] }
> = {
  "rodo-kijun-ho": {
    checkedAt: "2026-07-12",
    watchWords: ["労働基準法 改正", "労働時間 法改正"],
    sources: [
      { label: "e-Gov法令検索(労働基準法)", url: "https://laws.e-gov.go.jp/" },
      { label: "厚生労働省(労働基準)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/roudoukijun/index.html" },
    ],
  },
  "rodo-keiyaku-ho": {
    checkedAt: "2026-07-12",
    watchWords: ["労働契約法 改正", "無期転換ルール 見直し"],
    sources: [
      { label: "e-Gov法令検索(労働契約法)", url: "https://laws.e-gov.go.jp/" },
      { label: "厚生労働省(無期転換ルール)", url: "https://muki.mhlw.go.jp/" },
    ],
  },
  "ikuji-kaigo-kyugyo-ho": {
    checkedAt: "2026-07-12",
    watchWords: ["育児介護休業法 改正", "育児休業 制度 変更"],
    sources: [
      { label: "厚生労働省(育児・介護休業法)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kodomo/shokuba_kosodate/jigyou_ryouritsu/ryouritsu.html" },
    ],
  },
  "koyo-hoken": {
    checkedAt: "2026-07-12",
    watchWords: ["雇用保険法 改正", "基本手当 給付 変更"],
    sources: [
      { label: "厚生労働省(雇用保険制度)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/koyou/koyouhoken/index_00003.html" },
      { label: "ハローワークインターネットサービス", url: "https://www.hellowork.mhlw.go.jp/" },
    ],
  },
  "rodosha-haken-ho": {
    checkedAt: "2026-07-12",
    watchWords: ["労働者派遣法 改正"],
    sources: [
      { label: "厚生労働省(労働者派遣)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/koyou/haken-shoukai/index.html" },
    ],
  },
  "danjo-koyo-kikai-kinto-ho": {
    checkedAt: "2026-07-12",
    watchWords: ["男女雇用機会均等法 改正", "ハラスメント防止 法改正"],
    sources: [
      { label: "厚生労働省(雇用における男女の均等な機会と待遇)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/koyoukintou/danjokintou/index.html" },
    ],
  },
  "shogaisha-koyo": {
    checkedAt: "2026-07-12",
    watchWords: ["障害者雇用促進法 改正", "法定雇用率 引き上げ"],
    sources: [
      { label: "厚生労働省(障害者雇用対策)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/koyou/shougaishakoyou/index.html" },
    ],
  },
  "konenrei-sha-koyo-antei-ho": {
    checkedAt: "2026-07-12",
    watchWords: ["高年齢者雇用安定法 改正", "70歳 就業確保"],
    sources: [
      { label: "厚生労働省(高年齢者雇用対策)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/koyou/koureisha/index.html" },
    ],
  },
  "stress-check": {
    checkedAt: "2026-07-12",
    watchWords: ["ストレスチェック制度 改正", "労働安全衛生法 改正 メンタル"],
    sources: [
      { label: "厚生労働省(ストレスチェック制度)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000041959.html" },
    ],
  },
  "hello-work": {
    checkedAt: "2026-07-12",
    watchWords: ["求職者支援制度 変更", "ハローワーク 制度 変更"],
    sources: [
      { label: "ハローワークインターネットサービス", url: "https://www.hellowork.mhlw.go.jp/" },
    ],
  },
  "kyoiku-kunren-kyufu": {
    checkedAt: "2026-07-12",
    watchWords: ["教育訓練給付 拡充", "教育訓練給付 給付率 変更"],
    sources: [
      { label: "厚生労働省(教育訓練給付制度)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/jinzaikaihatsu/kyouiku.html" },
    ],
  },
  "shokugyo-nouryoku-kaihatsu-sokushin-ho": {
    checkedAt: "2026-07-12",
    watchWords: ["職業能力開発促進法 改正", "キャリアコンサルタント 制度 変更"],
    sources: [
      { label: "e-Gov法令検索(職業能力開発促進法)", url: "https://laws.e-gov.go.jp/" },
      { label: "厚生労働省(キャリアコンサルタント)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000198698.html" },
    ],
  },
  "job-card": {
    checkedAt: "2026-07-12",
    watchWords: ["ジョブカード 制度 変更"],
    sources: [
      { label: "マイジョブ・カード(公式サイト)", url: "https://www.job-card.mhlw.go.jp/" },
    ],
  },
  "self-career-dock": {
    checkedAt: "2026-07-12",
    watchWords: ["セルフキャリアドック 施策"],
    sources: [
      { label: "厚生労働省(セルフ・キャリアドック)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000192530.html" },
    ],
  },
  "mental-health-care": {
    checkedAt: "2026-07-12",
    watchWords: ["労働者の心の健康の保持増進のための指針 改正"],
    sources: [
      { label: "こころの耳(厚生労働省)", url: "https://kokoro.mhlw.go.jp/" },
    ],
  },
  "shitsugyoritsu-kyujinbairitsu": {
    checkedAt: "2026-07-12",
    watchWords: ["完全失業率 最新", "有効求人倍率 最新"],
    sources: [
      { label: "総務省統計局(労働力調査)", url: "https://www.stat.go.jp/data/roudou/" },
      { label: "厚生労働省(一般職業紹介状況)", url: "https://www.mhlw.go.jp/toukei/list/114-1.html" },
    ],
  },
  "rodoryoku-chosa": {
    checkedAt: "2026-07-12",
    watchWords: ["労働力調査 最新 結果"],
    sources: [
      { label: "総務省統計局(労働力調査)", url: "https://www.stat.go.jp/data/roudou/" },
    ],
  },
  "chingin-kozo-kihon-tokei": {
    checkedAt: "2026-07-12",
    watchWords: ["賃金構造基本統計調査 最新 結果"],
    sources: [
      { label: "厚生労働省(賃金構造基本統計調査)", url: "https://www.mhlw.go.jp/toukei/list/chinginkouzou.html" },
    ],
  },
  "noryoku-kaihatsu-kihon-chosa": {
    checkedAt: "2026-07-12",
    watchWords: ["能力開発基本調査 最新 結果"],
    sources: [
      { label: "厚生労働省(能力開発基本調査)", url: "https://www.mhlw.go.jp/toukei/list/104-1.html" },
    ],
  },
  "rinri-koryo": {
    checkedAt: "2026-07-12",
    watchWords: ["キャリアコンサルタント 倫理綱領 改正", "キャリアコンサルタント 更新講習 変更"],
    sources: [
      { label: "キャリアコンサルティング協議会", url: "https://new.career-cc.org/" },
      { label: "厚生労働省(キャリアコンサルタント)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000198698.html" },
    ],
  },
  "rodo-shisaku-suishin-ho": {
    checkedAt: "2026-07-12",
    watchWords: ["パワハラ防止法 改正", "労働施策総合推進法 改正"],
    sources: [
      { label: "厚生労働省(職場におけるハラスメント防止)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/koyoukintou/seisaku06/index.html" },
    ],
  },
  "shokugyo-antei-ho": {
    checkedAt: "2026-07-12",
    watchWords: ["職業安定法 改正"],
    sources: [
      { label: "e-Gov法令検索", url: "https://laws.e-gov.go.jp/" },
    ],
  },
  "part-yuki-ho": {
    checkedAt: "2026-07-12",
    watchWords: ["同一労働同一賃金 見直し", "パートタイム有期雇用労働法 改正"],
    sources: [
      { label: "厚生労働省(同一労働同一賃金)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000144972.html" },
    ],
  },
  "josei-katsuyaku": {
    checkedAt: "2026-07-12",
    watchWords: ["女性活躍推進法 改正", "男女賃金差 公表 義務"],
    sources: [
      { label: "厚生労働省(女性活躍推進法)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000091025.html" },
    ],
  },
  "wakamono-koyo": {
    checkedAt: "2026-07-12",
    watchWords: ["若者雇用促進法 改正", "ユースエール認定 要件"],
    sources: [
      { label: "厚生労働省(若者雇用促進法)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000098679.html" },
    ],
  },
  "shakai-hoken": {
    checkedAt: "2026-07-12",
    watchWords: ["社会保険 適用拡大", "短時間労働者 厚生年金"],
    sources: [
      { label: "厚生労働省(社会保険適用拡大)", url: "https://www.mhlw.go.jp/tekiyoukakudai/" },
    ],
  },
  "rosai-hoken": {
    checkedAt: "2026-07-12",
    watchWords: ["労災保険 制度 変更"],
    sources: [
      { label: "厚生労働省(労災補償)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/roudoukijun/rousai/index.html" },
    ],
  },
  "trial-koyo": {
    checkedAt: "2026-07-12",
    watchWords: ["トライアル雇用助成金 変更"],
    sources: [
      { label: "厚生労働省(トライアル雇用助成金)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/koyou/kyufukin/trial_koyou.html" },
    ],
  },
  "job-tag": {
    checkedAt: "2026-07-12",
    watchWords: ["job tag 職業情報提供サイト 更新"],
    sources: [
      { label: "job tag(職業情報提供サイト)", url: "https://shigoto.mhlw.go.jp/User" },
    ],
  },
  "kyushokusha-shien": {
    checkedAt: "2026-07-12",
    watchWords: ["求職者支援制度 改正", "職業訓練受講給付金 変更"],
    sources: [
      { label: "厚生労働省(求職者支援制度)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/koyou/kyushokusha_shien/index.html" },
    ],
  },
  "hello-training": {
    checkedAt: "2026-07-12",
    watchWords: ["ハロートレーニング 制度 変更", "公共職業訓練 改正"],
    sources: [
      { label: "厚生労働省(ハロートレーニング)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/jinzaikaihatsu/hellotraining_top.html" },
    ],
  },
  "jinzai-kaihatsu-josei": {
    checkedAt: "2026-07-12",
    watchWords: ["人材開発支援助成金 改正", "キャリアアップ助成金 変更"],
    sources: [
      { label: "厚生労働省(人材開発支援助成金)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/koyou/kyufukin/d01-1.html" },
    ],
  },
  "saburoku-kyotei": {
    checkedAt: "2026-07-12",
    watchWords: ["時間外労働 上限規制 改正", "36協定 変更"],
    sources: [
      { label: "厚生労働省(時間外労働の上限規制)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000148322_00001.html" },
    ],
  },
  "hatarakikata-kaikaku": {
    checkedAt: "2026-07-12",
    watchWords: ["働き方改革関連法 改正", "同一労働同一賃金 最新"],
    sources: [
      { label: "厚生労働省(働き方改革)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000148322.html" },
    ],
  },
  "saitei-chingin-ho": {
    checkedAt: "2026-07-12",
    watchWords: ["最低賃金 改定", "地域別最低賃金 引き上げ"],
    sources: [
      { label: "厚生労働省(最低賃金制度)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/roudoukijun/minimumichiran/index.html" },
    ],
  },
  "rodo-anzen-eisei-ho": {
    checkedAt: "2026-07-12",
    watchWords: ["労働安全衛生法 改正", "ストレスチェック 義務 拡大"],
    sources: [
      { label: "厚生労働省(労働安全衛生)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/roudoukijun/anzen/index.html" },
    ],
  },
  "jisedai-ikusei": {
    checkedAt: "2026-07-12",
    watchWords: ["次世代育成支援対策推進法 改正", "くるみん 認定基準 変更"],
    sources: [
      { label: "厚生労働省(くるみんマーク)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kodomo/shokuba_kosodate/kurumin/index.html" },
    ],
  },
  "freelance-shinpo": {
    checkedAt: "2026-07-12",
    watchWords: ["フリーランス法 改正", "特定受託事業者 制度 変更"],
    sources: [
      { label: "厚生労働省(フリーランス法)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000186725_00001.html" },
    ],
  },
  "shuro-shien": {
    checkedAt: "2026-07-12",
    watchWords: ["就労移行支援 制度 改正", "就労継続支援 報酬 変更"],
    sources: [
      { label: "厚生労働省(障害者の就労支援)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/hukushi_kaigo/shougaishahukushi/service/shurou.html" },
    ],
  },
  "muki-tenkan": {
    checkedAt: "2026-07-12",
    watchWords: ["無期転換ルール 改正", "労働契約法 18条 見直し"],
    sources: [
      { label: "厚生労働省(無期転換ポータル)", url: "https://muki.mhlw.go.jp/" },
    ],
  },
  "sabetsu-kaisho": {
    checkedAt: "2026-07-12",
    watchWords: ["障害者差別解消法 改正", "合理的配慮 義務 変更"],
    sources: [
      { label: "内閣府(障害者差別解消法)", url: "https://www8.cao.go.jp/shougai/suishin/sabekai.html" },
    ],
  },
  "fukugyo-kengyo": {
    checkedAt: "2026-07-12",
    watchWords: ["副業・兼業 ガイドライン 改定"],
    sources: [
      { label: "厚生労働省(副業・兼業)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000192188.html" },
    ],
  },
  "gaikokujin-koyo": {
    checkedAt: "2026-07-12",
    watchWords: ["育成就労 施行", "特定技能 分野 追加"],
    sources: [
      { label: "出入国在留管理庁(育成就労制度)", url: "https://www.moj.go.jp/isa/ikuseishuro_01.html" },
    ],
  },
  "internship-sanshogoi": {
    checkedAt: "2026-07-12",
    watchWords: ["インターンシップ 三省合意 改正"],
    sources: [
      { label: "厚生労働省(インターンシップ)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000053131.html" },
    ],
  },
  "karoshi-boshi": {
    checkedAt: "2026-07-12",
    watchWords: ["過労死等防止対策大綱 変更"],
    sources: [
      { label: "厚生労働省(過労死等防止対策)", url: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000053725.html" },
    ],
  },
};
