import { SunnySvg } from "../components/Characters";
import { writeFileSync } from "node:fs";
const raw = SunnySvg(512);
const body = raw.replace(/<svg[^>]*>/, "").replace("</svg>", "");
const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 120 120"><circle cx="60" cy="60" r="60" fill="#fffdf8"/>${body}</svg>`;
writeFileSync("/tmp/sunny-icon.svg", svg);
console.log("svg ok");
