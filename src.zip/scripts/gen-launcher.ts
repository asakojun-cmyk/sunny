/* リリースごとの「デスクトップボタン」と「バージョン別アーカイブ」を作る。
 *
 * 1. kyarikon-site/ の中身を kyarikon-site/v/<version>/ にも複製する。
 *    → GitHub にアップすると、その版が
 *      https://asakojun-cmyk.github.io/sunny/v/<version>/ にずっと残る。
 *      (GitHub のドラッグ&ドロップは追加・上書きのみで削除はしないので、
 *       過去の版のフォルダはリポジトリに残り続け、見比べられる)
 * 2. デスクトップに置ける「サニー先生ボタン」の HTML を2種類つくる。
 *    - キャリコンことば図鑑(最新版).html → サイトのトップ(常に最新)
 *    - キャリコンことば図鑑_<version>.html → その版のアーカイブ URL
 *
 * 使い方: tsx scripts/gen-launcher.ts  (make-portable.mjs のあとに実行)
 */
import {
  cpSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  rmSync,
  writeFileSync,
  existsSync,
} from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { SITE } from "../lib/site";
import { SunnySvg } from "../components/Characters";

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const SITE_DIR = join(root, "..", "kyarikon-site");
const LAUNCHER_DIR = join(root, "..", "launchers");

const version = readFileSync(join(SITE_DIR, "version.txt"), "utf8").trim();
const liveTop = `${SITE.baseUrl}/`;
const liveArchive = `${SITE.baseUrl}/v/${version}/`;

/* ---------- 1. バージョン別アーカイブを複製 ----------
 * 今回の版を保管庫(version-archives)に保存し、
 * 直近3つの版を kyarikon-site/v/ に同梱する(古い版のボタン対策)。 */
const STORE_DIR = join(root, "..", "version-archives");
const archiveDir = join(STORE_DIR, version);
const tmpDir = join(root, "..", `.archive-tmp-${version}`);
rmSync(join(SITE_DIR, "v"), { recursive: true, force: true });
rmSync(tmpDir, { recursive: true, force: true });
cpSync(SITE_DIR, tmpDir, { recursive: true });
mkdirSync(STORE_DIR, { recursive: true });
rmSync(archiveDir, { recursive: true, force: true });
cpSync(tmpDir, archiveDir, { recursive: true });
rmSync(tmpDir, { recursive: true, force: true });

// 保管庫から新しい順に3つを v/ へ
const kept = readdirSync(STORE_DIR).sort().reverse().slice(0, 3);
for (const v of kept) {
  cpSync(join(STORE_DIR, v), join(SITE_DIR, "v", v), { recursive: true });
}
console.log(`✔ v/ に同梱した版: ${kept.join(", ")}`);

/* ---------- 2. デスクトップ用ランチャー ---------- */
function launcherHtml(opts: {
  heading: string;
  sub: string;
  url: string;
  extra?: string;
}): string {
  return `<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${opts.heading}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Zen+Maru+Gothic:wght@500;700&display=swap" rel="stylesheet">
<style>
  body {
    margin: 0;
    min-height: 100vh;
    display: grid;
    place-items: center;
    background: linear-gradient(180deg, #dfe9ee 0%, #f5f2eb 100%);
    font-family: "Zen Maru Gothic", "Hiragino Maru Gothic ProN", sans-serif;
    color: #3f4652;
    text-align: center;
  }
  .card { padding: 40px 24px; }
  a.sunny-button {
    display: inline-block;
    text-decoration: none;
    color: inherit;
    transition: transform 0.25s ease;
  }
  a.sunny-button:hover { transform: scale(1.06) rotate(3deg); }
  a.sunny-button:active { transform: scale(0.97); }
  .sunny-button svg { filter: drop-shadow(0 10px 24px rgba(120, 100, 40, 0.28)); }
  h1 { font-size: 22px; margin: 20px 0 6px; letter-spacing: 0.05em; }
  p { margin: 4px 0; font-size: 14px; color: #6b7280; }
  .hint {
    margin-top: 18px;
    display: inline-block;
    background: #fff;
    border-radius: 999px;
    padding: 8px 20px;
    font-size: 13px;
    box-shadow: 0 4px 14px rgba(63, 70, 82, 0.08);
  }
  .version {
    margin-top: 14px;
    font-size: 12px;
    color: #9aa1ad;
    letter-spacing: 0.06em;
  }
  .alt { margin-top: 10px; font-size: 12px; }
  .alt a { color: #6b7280; }
</style>
</head>
<body>
  <main class="card">
    <a class="sunny-button" href="${opts.url}" aria-label="${opts.heading}をひらく">
      ${SunnySvg(180)}
    </a>
    <h1>${opts.heading}</h1>
    <p>${opts.sub}</p>
    <p class="hint">☀️ サニー先生をクリックするとサイトがひらくよ</p>
    <p class="version">${version}</p>
    ${opts.extra ?? ""}
  </main>
</body>
</html>`;
}

mkdirSync(LAUNCHER_DIR, { recursive: true });

// 常に最新版をひらくボタン
writeFileSync(
  join(LAUNCHER_DIR, "キャリコンことば図鑑(最新版).html"),
  launcherHtml({
    heading: "キャリコンことば図鑑",
    sub: "いつでも最新版がひらきます",
    url: liveTop,
  }),
  "utf8"
);

// この版だけをひらくボタン(リリースごとに増えていく)
writeFileSync(
  join(LAUNCHER_DIR, `キャリコンことば図鑑_${version}.html`),
  launcherHtml({
    heading: `キャリコンことば図鑑 ${version}`,
    sub: "この版のすがたを、そのまま保存したページがひらきます",
    url: liveArchive,
    extra: `<p class="alt"><a href="${liveTop}">最新版をひらく場合はこちら →</a></p>`,
  }),
  "utf8"
);

if (!existsSync(join(archiveDir, "index.html"))) {
  throw new Error("アーカイブ複製に失敗: index.html が見つかりません");
}
console.log(`✔ archive: v/${version}/ を作成`);
console.log(`✔ launcher: ${LAUNCHER_DIR} に2つのボタンを作成`);
