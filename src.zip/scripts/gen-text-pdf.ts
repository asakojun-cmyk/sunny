/**
 * 販売用「学科対策テキスト」を2形式で生成する。
 *  1) 印刷用PDFの元HTML(text-print.html):
 *     重要語を〔①〕の穴埋みにし、○×の答えも本文から外して巻末「解答編」にまとめる
 *  2) スマホ用インタラクティブ版(単一HTML商品):
 *     重要語が⛅️で隠れ、タップで表示。○×は「答えを見る」を押すまで非表示
 * 使い方: tsx scripts/gen-text-pdf.ts
 * 方針: サイトのオリジナルデータのみ使用(過去問の転載なし)
 */
import { mkdirSync, writeFileSync } from "node:fs";
import { terms } from "../data/terms";
import { theorists } from "../data/theorists";
import { termExamAdvice, theoristExamAdvice } from "../data/exam-advice";
import { termFrequency, theoristFrequency } from "../data/frequency";
import { CATEGORY_WEATHER } from "../lib/site";

function esc(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

const CIRCLED = ["①", "②", "③", "④", "⑤", "⑥", "⑦", "⑧"];

/**
 * 本文中の重要語(keywords)を穴埋めにする。
 * - 長いキーワード優先・各語は最初の1回だけ・1項目最大4か所
 * - mode "print": 〔①〕形式(答えは解答編へ)
 * - mode "tap":   タップで開く⛅️スパン
 */
function cloze(
  text: string,
  keywords: string[],
  mode: "print" | "tap"
): { html: string; answers: string[] } {
  const answers: string[] = [];
  let html = esc(text);
  const sorted = [...new Set(keywords)]
    .filter((k) => k.length >= 2 && !/^[0-9]+$/.test(k))
    .sort((a, b) => b.length - a.length);
  for (const kw of sorted) {
    if (answers.length >= 4) break;
    const e = esc(kw);
    const pos = html.indexOf(e);
    if (pos === -1) continue;
    // 既存のタグ内は避ける(単純チェック: 直前の < と > の位置)
    const lastLt = html.lastIndexOf("<", pos);
    const lastGt = html.lastIndexOf(">", pos);
    if (lastLt > lastGt) continue;
    const idx = answers.length;
    answers.push(kw);
    const rep =
      mode === "print"
        ? `<span class="blank">〔${CIRCLED[idx]}　　　〕</span>`
        : `<span class="tap" data-tap><span class="tap__mask" aria-hidden="true">⛅️</span><span class="tap__word" hidden>${e}</span></span>`;
    html = html.slice(0, pos) + rep + html.slice(pos + e.length);
  }
  return { html, answers };
}

const catOrder = Object.keys(CATEGORY_WEATHER);
const today = "2026年7月12日";

type AnswerRow = { label: string; blanks: string[]; quiz?: { mark: string; exp: string } };
const answerBook: { chapter: string; rows: AnswerRow[] }[] = [];

function buildTermSections(mode: "print" | "tap"): string {
  return catOrder
    .map((cat) => {
      const list = terms.filter((t) => t.category === cat);
      if (list.length === 0) return "";
      const rows: AnswerRow[] = [];
      const items = list
        .map((t) => {
          const advice = termExamAdvice[t.slug] ?? [];
          const c = cloze(t.formalExplanation, t.keywords, mode);
          const label = `TERM ${String(t.number).padStart(3, "0")}`;
          rows.push({
            label: `${label} ${t.name}`,
            blanks: c.answers,
            quiz: t.quiz
              ? {
                  mark: t.quiz.answer ? "○" : "×",
                  exp: t.quiz.explanation.replace(/^[○×]。?\s*/, ""),
                }
              : undefined,
          });
          const quizHtml = t.quiz
            ? mode === "print"
              ? `<div class="quiz"><span class="lbl">○×チェック</span><p class="q">Q. ${esc(t.quiz.question)}</p><p class="goto">▶ 答えと解説は巻末の「解答編」へ</p></div>`
              : `<div class="quiz" data-quiz><span class="lbl">○×チェック</span><p class="q">Q. ${esc(t.quiz.question)}</p><button type="button" class="reveal" data-reveal>答えを見る</button><p class="a" hidden><b>${t.quiz.answer ? "○" : "×"}</b> ${esc(t.quiz.explanation)}</p></div>`
            : "";
          return `<article class="term">
          <header>
            <span class="num">${label}</span>
            <h3>${esc(t.name)}<small>${esc(t.reading)}</small></h3>
            ${freqDots(termFrequency[t.slug])}
          </header>
          <p class="one">${esc(t.oneLiner)}</p>
          <div class="formal"><span class="lbl">試験で必要な説明${mode === "print" ? "(穴埋め)" : "(⛅️をタップ)"}</span><p>${c.html}</p></div>
          ${
            advice.length
              ? `<div class="advice"><span class="lbl">試験ではこう出る</span><ul>${advice.map((a) => `<li>${esc(a)}</li>`).join("")}</ul></div>`
              : ""
          }
          ${quizHtml}
        </article>`;
        })
        .join("");
      if (mode === "print") answerBook.push({ chapter: `${cat}のことば`, rows });
      return `<section class="chapter"><h2>${esc(cat)}のことば(${list.length}語)</h2>${items}</section>`;
    })
    .join("");
}

function freqDots(level: number | undefined): string {
  if (!level) return "";
  const label = level === 3 ? "よく出る" : level === 2 ? "ときどき出る" : "おさえて安心";
  return `<span class="freq f${level}" title="${label}"><i></i><i></i><i></i><b>${label}</b></span>`;
}

function buildTheoristSection(mode: "print" | "tap"): string {
  const rows: AnswerRow[] = [];
  const html = `<section class="chapter"><h2>理論家18人 総まとめ</h2>${theorists
    .map((th) => {
      const advice = theoristExamAdvice[th.slug] ?? [];
      const kcText = th.keyConcepts.map((c) => `${c.name} — ${c.description}`).join("/");
      const c = cloze(kcText, [...th.keyConcepts.map((k) => k.name), ...th.keywords], mode);
      const label = `No.${String(th.number).padStart(2, "0")}`;
      rows.push({ label: `${label} ${th.name}`, blanks: c.answers });
      return `<article class="term theorist">
      <header>
        <span class="num">${label}</span>
        <h3>${esc(th.name)}<small>${esc(th.nameEn)} / ${esc(th.field)}</small></h3>
        ${freqDots(theoristFrequency[th.slug])}
      </header>
      <p class="one">${esc(th.oneLiner)}</p>
      <div class="formal"><span class="lbl">おもな理論・キーワード${mode === "print" ? "(穴埋め)" : "(⛅️をタップ)"}</span><p>${c.html}</p></div>
      <div class="advice"><span class="lbl">試験でのポイント</span><ul>${[...th.examPoints, ...advice].map((p) => `<li>${esc(p)}</li>`).join("")}</ul></div>
    </article>`;
    })
    .join("")}</section>`;
  if (mode === "print") answerBook.push({ chapter: "理論家18人 総まとめ", rows });
  return html;
}

function buildAnswerSection(): string {
  return `<section class="chapter answers"><h2>解答編</h2>
  ${answerBook
    .map(
      (ch) => `<h3 class="answers__chapter">${esc(ch.chapter)}</h3>
      ${ch.rows
        .map((r) => {
          const blanks = r.blanks.map((b, i) => `${CIRCLED[i]}${esc(b)}`).join("  ");
          const quiz = r.quiz ? `<span class="answers__quiz"><b>${r.quiz.mark}</b> ${esc(r.quiz.exp)}</span>` : "";
          if (!blanks && !quiz) return "";
          return `<p class="answers__row"><b>${esc(r.label)}</b><br>${blanks ? `穴埋め: ${blanks}<br>` : ""}${quiz ? `○×: ${quiz}` : ""}</p>`;
        })
        .join("")}`
    )
    .join("")}
  </section>`;
}

const BASE_CSS = `
* { box-sizing: border-box; margin: 0; padding: 0; }
.cover .badge { color: #b86f55; letter-spacing: .3em; font-weight: 700; }
.term header { display: flex; align-items: baseline; gap: 10px; flex-wrap: wrap; }
.freq { margin-left: auto; display: inline-flex; align-items: center; gap: 3px; }
.freq i { width: 9px; height: 9px; border-radius: 50%; background: #e2ddd3; display: inline-block; }
.freq b { font-size: 10px; color: #6f6b63; font-weight: 400; margin-left: 3px; }
.freq.f3 i { background: #c99a2e; }
.freq.f2 i:nth-child(-n+2) { background: #4f93c4; }
.freq.f1 i:nth-child(1) { background: #8f8a7e; }
`;

/* ---------- 1) 印刷用(穴埋め+巻末解答編) ---------- */
answerBook.length = 0;
const printTerms = buildTermSections("print");
const printTheorists = buildTheoristSection("print");
const printAnswers = buildAnswerSection();

const printHtml = `<!doctype html><html lang="ja"><head><meta charset="utf-8"><style>
@page { size: A4; margin: 16mm 14mm 18mm; }
${BASE_CSS}
body { font-family: "Noto Sans CJK JP", sans-serif; font-size: 9.5pt; line-height: 1.75; color: #272722; }
.cover { height: 250mm; display: flex; flex-direction: column; justify-content: center; text-align: center; page-break-after: always; }
.cover .badge { font-size: 10pt; margin-bottom: 10mm; }
.cover h1 { font-size: 25pt; line-height: 1.5; margin-bottom: 6mm; }
.cover .sub { font-size: 12pt; color: #6f6b63; margin-bottom: 14mm; }
.cover .meta { font-size: 9pt; color: #6f6b63; }
.intro { page-break-after: always; }
.intro h2, .chapter h2 { font-size: 15pt; border-left: 5px solid #b86f55; padding-left: 4mm; margin: 8mm 0 5mm; page-break-after: avoid; }
.intro li { font-size: 9.5pt; margin-bottom: 2mm; }
.intro ul { padding-left: 5mm; margin: 2mm 0 4mm; }
.notice { background: #f5efd9; border-radius: 3mm; padding: 4mm 5mm; margin: 4mm 0; font-size: 8.5pt; }
.term { border: .4pt solid #d8d2c7; border-radius: 2.5mm; padding: 3.5mm 4mm; margin-bottom: 3.5mm; page-break-inside: avoid; }
.term header { margin-bottom: 1.5mm; }
.term .num { font-size: 7.5pt; color: #b86f55; font-weight: 700; letter-spacing: .08em; }
.term h3 { font-size: 11.5pt; }
.term h3 small { font-weight: 400; font-size: 7.5pt; color: #6f6b63; margin-left: 2mm; }
.one { font-size: 9.5pt; font-weight: 700; margin-bottom: 2mm; }
.lbl { display: inline-block; font-size: 7pt; font-weight: 700; color: #fff; background: #758679; border-radius: 999px; padding: 0 2.5mm; margin-bottom: 1mm; }
.advice .lbl { background: #b86f55; }
.quiz .lbl { background: #4f93c4; }
.formal, .advice, .quiz { margin-bottom: 2mm; }
.formal p, .advice li, .quiz p { font-size: 8.8pt; }
.advice ul { padding-left: 5mm; }
.quiz .q { font-weight: 700; }
.quiz .goto { font-size: 8pt; color: #4f93c4; font-weight: 700; }
.blank { font-weight: 700; color: #b86f55; letter-spacing: .04em; border-bottom: .5pt solid #b86f55; }
.chapter { page-break-before: always; }
.answers__chapter { font-size: 11pt; margin: 5mm 0 3mm; color: #758679; }
.answers__row { font-size: 8.2pt; border-bottom: .3pt solid #e2ddd3; padding: 1.6mm 0; }
.answers__quiz b { color: #b86f55; }
footer.colophon { page-break-before: always; font-size: 8.5pt; color: #6f6b63; }
</style></head><body>
<div class="cover">
  <p class="badge">CAREER CONSULTANT STUDY TEXT</p>
  <h1>キャリコンことば図鑑<br>学科試験 直前対策テキスト<br><small style="font-size:13pt">〜穴埋めドリル式・解答編つき〜</small></h1>
  <p class="sub">${terms.length}用語+理論家${theorists.length}人を「思い出す練習」ができる形に凝縮</p>
  <p class="meta">${today}版(印刷用)<br>もやもやモヤンとさんさんサニー先生の たのしいキャリアコンサルタント試験対策室<br>https://asakojun-cmyk.github.io/sunny/</p>
</div>
<section class="intro">
  <h2>このテキストの使い方</h2>
  <ul>
    <li><b>穴埋め式</b>: 本文の重要語は〔①〕〔②〕の空欄になっています。まず自分で思い出してから、巻末の「解答編」で確かめてください。「読む」より「思い出す」ほうが、記憶は数倍定着します(想起練習)。</li>
    <li><b>○×チェック</b>: 答えは本文には載せていません。解答編で答え合わせをしてください。</li>
    <li><b>頻出度</b>: 右上の●3つ=よく出る/2つ=ときどき/1つ=おさえて安心。時間がない日は●3つだけ。</li>
    <li>スマホ学習には、セットの「タップで答えが出るインタラクティブ版(HTML)」をどうぞ。</li>
  </ul>
  <div class="notice">
    <p><b>ご利用にあたって</b></p>
    <p>・本書は運営者のオリジナル教材です。実際の過去問題文の転載は行っていません。頻出度は運営者調べの目安であり、出題を保証するものではありません。</p>
    <p>・法令・統計・制度は${today}時点の情報に基づきます。受験前に一次資料で最新情報をご確認ください。</p>
    <p>・本書は購入者個人の学習用です。無断複製・再配布・転売はご遠慮ください。</p>
  </div>
</section>
${printTerms}
${printTheorists}
${printAnswers}
<footer class="colophon">
  <p>キャリコンことば図鑑 学科試験 直前対策テキスト 穴埋めドリル式(${today}版)</p>
  <p>発行: キャリコンことば図鑑 運営者 / https://asakojun-cmyk.github.io/sunny/</p>
  <p>&copy; 2026 キャリコンことば図鑑. All rights reserved.</p>
</footer>
</body></html>`;

/* ---------- 2) スマホ用インタラクティブ版(単一HTML商品) ---------- */
const tapTerms = buildTermSections("tap");
const tapTheorists = buildTheoristSection("tap");

const tapHtml = `<!doctype html><html lang="ja"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>キャリコン学科 直前対策テキスト(タップで答え)</title>
<style>
${BASE_CSS}
body { font-family: "Zen Maru Gothic", "Hiragino Maru Gothic ProN", "Noto Sans CJK JP", sans-serif; font-size: 15px; line-height: 1.9; color: #272722; background: #f5f2eb; padding: 16px 14px 60px; }
.wrap { max-width: 720px; margin: 0 auto; }
h1 { font-size: 20px; margin: 18px 0 6px; }
.sub { color: #6f6b63; font-size: 13px; margin-bottom: 14px; }
.howto { background: #fffdf8; border: 1.5px solid #e7d49a; border-radius: 14px; padding: 14px 16px; font-size: 13px; margin-bottom: 18px; }
.howto b { color: #b86f55; }
.toolbar { position: sticky; top: 0; background: #f5f2ebee; padding: 8px 0; z-index: 5; display: flex; gap: 8px; flex-wrap: wrap; }
.toolbar button { font: inherit; font-size: 12px; font-weight: 700; border: 1.5px solid #d8d2c7; background: #fffdf8; border-radius: 999px; padding: 6px 14px; }
.toolbar button[aria-pressed="true"] { background: #b86f55; border-color: #b86f55; color: #fff; }
.chapter h2 { font-size: 17px; border-left: 5px solid #b86f55; padding-left: 10px; margin: 26px 0 12px; }
.term { background: #fffdf8; border: 1px solid #d8d2c7; border-radius: 14px; padding: 14px 16px; margin-bottom: 12px; }
.term .num { font-size: 11px; color: #b86f55; font-weight: 700; letter-spacing: .08em; }
.term h3 { font-size: 16.5px; }
.term h3 small { font-weight: 400; font-size: 11px; color: #6f6b63; margin-left: 6px; }
.one { font-weight: 700; margin: 6px 0; font-size: 14.5px; }
.lbl { display: inline-block; font-size: 10px; font-weight: 700; color: #fff; background: #758679; border-radius: 999px; padding: 1px 10px; margin-bottom: 4px; }
.advice .lbl { background: #b86f55; }
.quiz .lbl { background: #4f93c4; }
.formal p, .advice li, .quiz p { font-size: 13.5px; }
.advice ul { padding-left: 18px; }
.formal, .advice, .quiz { margin-bottom: 8px; }
.quiz .q { font-weight: 700; }
.quiz .a b { color: #b86f55; font-size: 17px; }
.tap { display: inline-block; cursor: pointer; }
.tap__mask { display: inline-block; background: #e8f0f1; border: 1.5px dashed #7fa8b8; border-radius: 8px; padding: 0 10px; }
.tap__word { font-weight: 700; color: #b86f55; border-bottom: 2px solid #b86f55; }
.reveal { font: inherit; font-size: 12.5px; font-weight: 700; color: #fff; background: #4f93c4; border: none; border-radius: 999px; padding: 6px 16px; margin: 4px 0; }
.foot { font-size: 11px; color: #6f6b63; margin-top: 30px; }
</style></head><body><div class="wrap">
<h1>⛅ キャリコン学科 直前対策テキスト<br><small>タップで答えが出るインタラクティブ版</small></h1>
<p class="sub">${today}版 / ${terms.length}用語+理論家${theorists.length}人 / キャリコンことば図鑑</p>
<div class="howto">
  <p><b>使い方</b>: 本文の <span class="tap"><span class="tap__mask">⛅️</span></span> をタップすると重要語が表示されます(もう一度タップで隠す)。○×は「答えを見る」を押すまで出ません。まず自分で思い出す——それが最強の暗記法です。</p>
</div>
<div class="toolbar">
  <button type="button" data-all="hide" aria-pressed="true">ぜんぶ隠す</button>
  <button type="button" data-all="show" aria-pressed="false">ぜんぶ表示(確認モード)</button>
</div>
${tapTerms}
${tapTheorists}
<p class="foot">本書は運営者のオリジナル教材です(過去問の転載なし)。頻出度は運営者調べの目安です。法令等は${today}時点。購入者個人の学習用につき、複製・再配布・転売はご遠慮ください。<br>&copy; 2026 キャリコンことば図鑑 https://asakojun-cmyk.github.io/sunny/</p>
</div>
<script>
document.addEventListener("click", function (e) {
  var tap = e.target.closest("[data-tap]");
  if (tap) {
    var w = tap.querySelector(".tap__word");
    var m = tap.querySelector(".tap__mask");
    var shown = !w.hidden;
    w.hidden = shown;
    m.hidden = !shown;
    return;
  }
  var btn = e.target.closest("[data-reveal]");
  if (btn) {
    var a = btn.parentElement.querySelector(".a");
    a.hidden = !a.hidden;
    btn.textContent = a.hidden ? "答えを見る" : "答えを隠す";
    return;
  }
  var all = e.target.closest("[data-all]");
  if (all) {
    var show = all.getAttribute("data-all") === "show";
    document.querySelectorAll("[data-tap]").forEach(function (t) {
      t.querySelector(".tap__word").hidden = !show;
      t.querySelector(".tap__mask").hidden = show;
    });
    document.querySelectorAll("[data-quiz] .a").forEach(function (a) { a.hidden = !show; });
    document.querySelectorAll("[data-reveal]").forEach(function (b) { b.textContent = show ? "答えを隠す" : "答えを見る"; });
    document.querySelectorAll("[data-all]").forEach(function (b) { b.setAttribute("aria-pressed", b === all ? "true" : "false"); });
  }
});
</script>
</body></html>`;

mkdirSync("/home/claude/kyarikon-text", { recursive: true });
writeFileSync("/home/claude/kyarikon-text/text-print.html", printHtml);
writeFileSync(
  "/home/claude/kyarikon-text/キャリコン学科_直前対策テキスト_タップで答えが出る版.html",
  tapHtml
);
console.log(`✔ 印刷用+インタラクティブ版を生成(用語${terms.length}語+理論家${theorists.length}人)`);
