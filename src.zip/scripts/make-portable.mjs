/* dist/ を「どのサブパスでも動く」持ち運び版に変換する。
 * 絶対パス(/css/... や /terms/)を相対パス(../css/...、../terms/index.html)に
 * 書き換えるので、GitHub Pages のプロジェクトサイト(例: /sunny/)や
 * ローカルでのダブルクリックでもそのまま表示できる。
 *
 * 使い方: node scripts/make-portable.mjs [出力先]  (既定: ../kyarikon-site)
 */
import { cpSync, rmSync, readFileSync, writeFileSync, readdirSync, statSync } from "node:fs";
import { join, dirname, relative, sep } from "node:path";
import { fileURLToPath } from "node:url";

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const SRC = join(root, "dist");
const OUT = process.argv[2] || join(root, "..", "kyarikon-site");

rmSync(OUT, { recursive: true, force: true });
cpSync(SRC, OUT, { recursive: true });

const htmls = [];
(function walk(dir) {
  for (const f of readdirSync(dir)) {
    const p = join(dir, f);
    if (statSync(p).isDirectory()) walk(p);
    else if (f.endsWith(".html")) htmls.push(p);
  }
})(OUT);

for (const file of htmls) {
  const depth = relative(OUT, dirname(file)).split(sep).filter(Boolean).length;
  const rel = depth === 0 ? "./" : "../".repeat(depth);
  let src = readFileSync(file, "utf8");
  src = src.replace(/(href|src|action)="\/(?!\/)([^"]*)"/g, (_m, attr, rest) => {
    if (rest.startsWith("#")) return `${attr}="${rel}index.html#${rest.slice(1)}"`;
    let [p, hashq] = rest.split(/(?=[#?])/, 2);
    hashq = hashq || "";
    if (p === "" || p.endsWith("/")) p += "index.html";
    return `${attr}="${rel}${p}${hashq}"`;
  });
  writeFileSync(file, src);
}
console.log(`✔ portable copy: ${htmls.length} pages → ${OUT}`);
