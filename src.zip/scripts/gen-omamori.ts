/* お守りスマホ待ち受け(2パターン)を public/img/ に生成する。
 * 実行: tsx scripts/gen-omamori.ts && node scripts/render-omamori.mjs
 * (このスクリプトはSVGを書き出し、render-omamori.mjs が sharp でPNG化する)
 */
import { writeFileSync } from "node:fs";
import { MoyanSvg, MoyanIdeaSvg, SunnySvg, SunnyHappySvg } from "../components/Characters";

const W = 1179;
const H = 2556;
const FONT = "Noto Sans CJK JP";

/** キャラSVG(viewBox 0 0 120 120)を任意位置に埋め込む */
function place(svg: string, x: number, y: number, size: number): string {
  const inner = svg.replace(/<svg[^>]*>/, "").replace("</svg>", "");
  const scale = size / 120;
  return `<g transform="translate(${x},${y}) scale(${scale})">${inner}</g>`;
}

function cloud(cx: number, cy: number, s: number, opacity: number): string {
  return `<g fill="#ffffff" opacity="${opacity}">
    <ellipse cx="${cx}" cy="${cy}" rx="${s * 1.6}" ry="${s}"/>
    <ellipse cx="${cx - s * 1.2}" cy="${cy + s * 0.3}" rx="${s}" ry="${s * 0.7}"/>
    <ellipse cx="${cx + s * 1.2}" cy="${cy + s * 0.3}" rx="${s}" ry="${s * 0.7}"/>
  </g>`;
}

function star(cx: number, cy: number, r: number, fill: string, op = 1): string {
  return `<path d="M ${cx} ${cy - r} l ${r * 0.28} ${r * 0.72} ${r * 0.72} ${r * 0.28} -${r * 0.72} ${r * 0.28} -${r * 0.28} ${r * 0.72} -${r * 0.28} -${r * 0.72} -${r * 0.72} -${r * 0.28} ${r * 0.72} -${r * 0.28} Z" fill="${fill}" opacity="${op}"/>`;
}

/* ---------- パターン1: 試験に向けて(いっぽずつ) ---------- */
const svg1 = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <defs>
    <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#aec4d0"/>
      <stop offset="55%" stop-color="#dfe7e6"/>
      <stop offset="100%" stop-color="#f7f2e6"/>
    </linearGradient>
  </defs>
  <rect width="${W}" height="${H}" fill="url(#sky)"/>
  ${cloud(220, 420, 90, 0.5)}
  ${cloud(950, 640, 120, 0.45)}
  ${cloud(320, 1050, 70, 0.4)}
  ${cloud(880, 1950, 100, 0.35)}
  ${star(180, 780, 16, "#f4d64f", 0.7)}
  ${star(1000, 1150, 20, "#f4d64f", 0.6)}
  ${star(150, 1700, 14, "#ffffff", 0.8)}

  <text x="${W / 2}" y="1020" text-anchor="middle" font-family="${FONT}" font-weight="700" font-size="76" fill="#3f4652" letter-spacing="6">いっぽずつで、</text>
  <text x="${W / 2}" y="1140" text-anchor="middle" font-family="${FONT}" font-weight="700" font-size="76" fill="#3f4652" letter-spacing="6">だいじょうぶ。</text>

  ${place(MoyanSvg(120), W / 2 - 340, 1300, 330)}
  ${place(SunnySvg(120), W / 2 + 30, 1290, 340)}

  <text x="${W / 2}" y="1850" text-anchor="middle" font-family="${FONT}" font-weight="700" font-size="44" fill="#8a7a55" letter-spacing="4">きょうの がんばりは</text>
  <text x="${W / 2}" y="1925" text-anchor="middle" font-family="${FONT}" font-weight="700" font-size="44" fill="#8a7a55" letter-spacing="4">ちゃんと つもっていくよ</text>

  <text x="${W / 2}" y="2400" text-anchor="middle" font-family="${FONT}" font-weight="700" font-size="34" fill="#9aa1ad" letter-spacing="6">⛅ キャリコンことば図鑑</text>
</svg>`;

/* ---------- パターン2: 試験まぢか(あとはうかるだけ) ---------- */
const svg2 = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <defs>
    <linearGradient id="dawn" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#fdf3c9"/>
      <stop offset="60%" stop-color="#fbe3b2"/>
      <stop offset="100%" stop-color="#f6cfa5"/>
    </linearGradient>
  </defs>
  <rect width="${W}" height="${H}" fill="url(#dawn)"/>
  <circle cx="${W / 2}" cy="1500" r="560" fill="#fff3c0" opacity="0.55"/>
  <circle cx="${W / 2}" cy="1500" r="420" fill="#fff8d8" opacity="0.6"/>
  ${cloud(240, 500, 90, 0.55)}
  ${cloud(940, 760, 110, 0.5)}
  ${star(170, 900, 18, "#e8a94a", 0.8)}
  ${star(1010, 1120, 22, "#e8a94a", 0.7)}
  ${star(220, 2000, 16, "#ffffff", 0.9)}
  ${star(960, 1980, 14, "#e8a94a", 0.7)}

  <text x="${W / 2}" y="980" text-anchor="middle" font-family="${FONT}" font-weight="700" font-size="88" fill="#7a5b2a" letter-spacing="8">あとは、</text>
  <text x="${W / 2}" y="1120" text-anchor="middle" font-family="${FONT}" font-weight="700" font-size="88" fill="#7a5b2a" letter-spacing="8">うかるだけ。</text>

  ${place(SunnyHappySvg(120), W / 2 - 200, 1280, 400)}
  ${place(MoyanIdeaSvg(120), W / 2 - 380, 1500, 260)}

  <text x="${W / 2}" y="1950" text-anchor="middle" font-family="${FONT}" font-weight="700" font-size="44" fill="#9a7a3f" letter-spacing="4">ここまで きたきみは</text>
  <text x="${W / 2}" y="2025" text-anchor="middle" font-family="${FONT}" font-weight="700" font-size="44" fill="#9a7a3f" letter-spacing="4">もう じゅうぶん つよい</text>

  <text x="${W / 2}" y="2400" text-anchor="middle" font-family="${FONT}" font-weight="700" font-size="34" fill="#b09159" letter-spacing="6">☀️ キャリコンことば図鑑</text>
</svg>`;

writeFileSync("/tmp/omamori-1.svg", svg1, "utf8");
writeFileSync("/tmp/omamori-2.svg", svg2, "utf8");
console.log("svg ok");
