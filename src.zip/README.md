# キャリコンことば図鑑

**CAREER CONSULTANT STUDY GUIDE**
小学生でもわかるほどやさしい国家資格キャリアコンサルタント試験対策サイト。

コンセプト: **「知らない言葉」で、勉強を止めない。**
デザインコンセプト: **忙しい人が、静かに学べる小さな図書室**

## 技術構成

- TypeScript 製の自作静的サイトジェネレータ(`build.ts`)
  - コンポーネント(`components/`)は HTML 文字列を返す型付き関数
  - React や Next.js などの外部フレームワークに依存しない(npm レジストリが使えない環境でもビルド可能)
- コンテンツはすべて TypeScript データファイル(`data/`)で管理。UI コンポーネントに直接書かない
- クライアント側の動き(検索・比較・絞り込み・○×クイズ・メニュー)はプレーン JS(`public/js/`)
- 出力は `dist/` 配下の純粋な静的 HTML/CSS/JS(どの静的ホスティングにも置ける)

## コマンド

```bash
npm install        # 通常環境では devDependencies を導入
npm run lint       # ESLint (public/js のプレーンJSが対象)
npm run typecheck  # tsc --noEmit (TypeScript全体の型検査)
npm run build      # dist/ に静的サイトを生成
npm run check      # lint + typecheck + build
npm run serve      # dist/ をローカル配信 (http://localhost:8080)
```

> 開発時のサンドボックス環境では npm レジストリが使えなかったため、
> グローバルの `tsx` / `tsc` / `eslint` と、`node_modules/@types/node` への
> シンボリックリンクで動かしている。通常の環境では `npm install` すればよい。

### デプロイ前に必ず変更すること

`lib/site.ts` の `SITE.baseUrl` を実際の公開 URL に変更する
(canonical・OGP・sitemap に使われる)。

## ディレクトリ構成

```
build.ts              # ビルドスクリプト(全ページ生成・検索インデックス・sitemap)
lib/
  types.ts            # School / SchoolReview / Term / Theorist などの型定義
  site.ts             # サイト名・ナビ・カテゴリー等の共通設定
  html.ts             # esc() などのHTMLユーティリティ
components/           # 再利用コンポーネント(HTML文字列を返す関数)
  Layout.ts           # ページ全体(head/ヘッダー/フッター/下部ナビ/SEO)
  EditorialSectionHeader.ts  InfoLabel.ts  PrLabel.ts  SourceList.ts
  UpdatedDate.ts  Breadcrumbs.ts  ArticleCard.ts  SchoolCard.ts
  RelatedContents.ts  HeroSection.ts  SiteSearch.ts  LearningPath.ts
  CategoryFeature.ts  DailyStudy.ts  StudyJournalFeature.ts
  SchoolComparisonFeature.ts  AuthorProfile.ts
data/
  terms.ts            # 用語(ことば図鑑)
  theorists.ts        # 理論家図鑑
  articles.ts         # ガイド記事などのメタ情報
  schools/            # 学校データ(1校1ファイル)
  school-reviews/     # 受講体験(運営者本人の記録のみ)
pages/                # 各ページの組み立て
public/
  css/style.css       # デザイントークン+全スタイル
  js/                 # 検索・比較・絞り込み・クイズ・ナビ
dist/                 # ビルド出力(git管理外)
```

## 実装済みページ

| パス | 内容 |
|---|---|
| `/` | トップ(ヒーロー/検索/3本柱/学習ルート/カテゴリー/今日の3分学習/受講記録/学校比較/注目・最新・はじめに読みたい記事/暮らし特集/資格取得後/プロフィール) |
| `/terms/`, `/terms/[slug]/` | 用語一覧・詳細(8語収録。3段階解説+1問1答) |
| `/theorists/`, `/theorists/[slug]/` | 理論家一覧・詳細(6人収録) |
| `/schools/`, `/schools/[slug]/` | 学校一覧(絞り込み付き)・詳細(6校) |
| `/schools/compare/` | 最大3校の比較(項目別カード表示・URLクエリ/ローカルストレージで保持) |
| `/school-reviews/chiiki-renkei-platform/` | 受講体験(22見出しのひな型・本文は運営者記入待ち) |
| `/school-guides/how-to-choose/` ほか3本 | 選び方/オンライン/子育て両立/養成講習と試験対策の違い |
| `/start/` | 初学者の学習ルート(試験対策の入口) |
| `/careers/` | 資格取得後の働き方 |
| `/search/` | サイト内検索(用語・読み・理論家・学校・運営会社・記事横断) |
| `/about/` | このサイトについて(編集方針・免責) |
| `/404.html` | 404ページ |

## 情報の信頼性ルール(重要)

- 学校情報は **「公式情報」(青) / 「受講者本人の体験」(緑) / 「運営者の考察」(黄) / 「未確認・調査中」(グレー)** のラベルで必ず区別する。色だけに頼らず文字でも表示する
- 確認できない項目は推測で埋めず `undefined` のままにする → 画面には自動で「未確認」「調査中」と表示される
- 受講していない学校に「受講体験」とは書かない(未受講校の詳細ページには自動で注意書きが入る)
- **体験談の本文は AI で作らない。** `data/school-reviews/` には運営者本人の記録だけを書く
- 合格率・就職率・収入・「人気」「一番」「最安」などは一次資料がない限り書かない
- 料金・日程・給付金は変更されうるため、全学校ページに情報確認日・公式リンク・注意書きを表示する

## 学校情報の追加・更新方法

1. `data/schools/` に新しいファイルを作る(`chiiki-renkei-platform.ts` が記入例)
2. **公式サイトで確認できた項目だけ**埋める。`officialFacts` には出典URLと `checkedAt`(確認日)を必ず入れる
3. `data/schools/index.ts` の配列に追加する
4. 一覧カードの特徴(`highlights` 最大3つ)と絞り込みタグ(`filterTags`)を設定する
5. `npm run check` → 学校詳細・一覧・比較ページに自動反映される

既存校の情報を更新したら `verifiedAt` / `updatedAt` / 各 `checkedAt` を更新すること。

## 受講体験記事の更新方法

1. `data/school-reviews/chiiki-renkei-platform.ts` を開く
2. `reviewOutline` の各見出しの `body`(現在 `(※運営者記入予定)`)を、実際の体験メモで置き換える
3. `chiikiReview` の各フィールド(受講期間・コース名など)も実体験で埋める
4. 書けた項目から公開してよい(未記入の見出しは自動で「執筆中」と表示される)
5. 全体が整ったら `publicationStatus` を `"published"` に変更 → 「執筆中」の注意書きが消える
6. `reviewUpdatedAt` を更新して `npm run build`

掲載禁止: 個人名・他の受講生の発言・授業内の秘密情報・教材や授業画面の転載。

## 用語・理論家の追加方法

- 用語: `data/terms.ts` の配列にオブジェクトを追加(3段階の説明+1問1答)
- 理論家: `data/theorists.ts` に追加
- 検索インデックス・一覧・「今日の3分学習」へは自動反映される

## 広告・PR を導入する場合

- 学校: `School.isPr` を `true` に → カード・比較に「PR」ラベルが自動表示
- 記事: `DisclosureBox()` の引数を実態に合わせて変更(報酬の有無・紹介リンクの有無など)
- 広告校だけを先頭に固定しない・煽り表現を使わない方針は `pages/compare.ts` 冒頭のコメント参照

## デザイントークン

配色・フォントは `public/css/style.css` の `:root` で一元管理。
生成り背景 `#f5f2eb` / 本文面 `#fffdf8` / 文字 `#272722` / 空色 `#c8dce1` /
やさしい補足の黄 `#e7d49a` / 主要CTAのテラコッタ `#b86f55` / PR `#72584d`。
フォントはサイト全体を Zen Maru Gothic(やわらかい丸ゴシック)で統一(16px以上・行間1.8)。

## 今回実装していないもの

会員登録 / 有料課金 / AIチャット / 外部APIによる自動情報収集 / スクレイピング /
自動ランキング / 口コミ投稿 / 実在しないレビュー / 管理画面 / 給付金の自動判定 /
学校への自動申込み / メルマガ登録フォーム / 閲覧数ベースの人気記事(データ取得後に切替予定)
