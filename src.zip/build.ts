/* 静的サイトビルドスクリプト
 * 実行: npm run build (tsx build.ts)
 * 出力: dist/
 */
import { mkdirSync, writeFileSync, rmSync, cpSync } from "node:fs";
import { dirname, join } from "node:path";

import { homePage } from "./pages/home";
import { lawWatch } from "./data/law-watch";
import { termsIndexPage, termDetailPage } from "./pages/terms";
import { theoristsIndexPage, theoristDetailPage } from "./pages/theorists";
import { schoolsIndexPage, schoolDetailPage } from "./pages/schools";
import { comparePage } from "./pages/compare";
import { chiikiReviewPage } from "./pages/review";
import {
  howToChoosePage,
  onlineGuidePage,
  workingMothersGuidePage,
  trainingVsExamPrepPage,
} from "./pages/guides";
import { startPage } from "./pages/start";
import { lawsPage, examPage } from "./pages/hubs";
import { careersPage } from "./pages/careers";
import { gamesHubPage, matchGamePage } from "./pages/games";
import { searchPage } from "./pages/search";
import { aboutPage, notFoundPage } from "./pages/about";

import { terms } from "./data/terms";
import { theorists } from "./data/theorists";
import { schools } from "./data/schools/index";
import { articles } from "./data/articles";
import type { SearchDoc, School } from "./lib/types";
import { SITE } from "./lib/site";
import { deliveryModesLabel } from "./components/SchoolCard";

const DIST = join(process.cwd(), "dist");

function writePage(path: string, html: string): void {
  // path 例: "/" → dist/index.html, "/terms/xxx/" → dist/terms/xxx/index.html
  const file =
    path === "/404.html"
      ? join(DIST, "404.html")
      : join(DIST, path.replace(/^\//, ""), "index.html");
  mkdirSync(dirname(file), { recursive: true });
  writeFileSync(file, html, "utf8");
}

/* ---------- 検索インデックス ---------- */
function buildSearchIndex(): SearchDoc[] {
  const docs: SearchDoc[] = [];

  for (const t of terms) {
    docs.push({
      type: "用語",
      title: t.name,
      reading: t.reading,
      description: t.oneLiner,
      url: `/terms/${t.slug}/`,
      keywords: [...t.keywords, t.category],
    });
  }
  for (const t of theorists) {
    docs.push({
      type: "理論家",
      title: t.name,
      reading: t.nameEn,
      description: t.oneLiner,
      url: `/theorists/${t.slug}/`,
      keywords: [...t.keywords, t.field],
    });
  }
  for (const s of schools) {
    docs.push({
      type: "学校",
      title: s.name,
      description: `運営: ${s.operatorName}`,
      url: `/schools/${s.slug}/`,
      keywords: [s.operatorName, "養成講座", "養成学校", "キャリアコンサルタント"],
    });
  }
  docs.push(
    {
      type: "ガイド",
      title: "労働法・統計・制度",
      description: "一次資料(厚労省・e-Gov・統計局)への入口と制度用語",
      url: "/laws/",
      keywords: ["労働法", "統計", "制度", "法律", "一次資料"],
    },
    {
      type: "ガイド",
      title: "学科・論述・面接(試験の全体像と公式過去問)",
      description: "試験の全体像と、試験機関の公式過去問ページへの入口",
      url: "/exam/",
      keywords: ["過去問", "学科試験", "論述", "面接", "ロールプレイ"],
    }
  );
  for (const a of articles) {
    const type =
      a.categoryEn === "MY STUDY JOURNAL"
        ? "受講体験"
        : a.categoryEn === "SCHOOLS"
          ? "ガイド"
          : a.categoryEn === "FUTURE"
            ? "働き方"
            : "記事";
    // 用語・理論家の個別記事は上で登録済みのため、重複を避ける
    if (a.slug.startsWith("terms/") || a.slug.startsWith("theorists/")) continue;
    docs.push({
      type,
      title: a.title,
      description: a.description,
      url: `/${a.slug}/`,
      keywords: [a.category],
    });
  }
  return docs;
}

/* ---------- 比較用の学校データ(クライアントJSが使用) ---------- */
type CompareEntry = {
  slug: string;
  name: string;
  officialUrl: string;
  informationStatus: School["informationStatus"];
  checkedAt: string;
  isPr: boolean;
  items: Record<string, string>;
};

const UNCONFIRMED = "未確認・調査中";

function yenOr(v: number | undefined): string {
  return v === undefined ? UNCONFIRMED : `${v.toLocaleString("ja-JP")}円`;
}

function buildCompareData(): { itemOrder: string[]; schools: CompareEntry[] } {
  const itemOrder = [
    "受講形式",
    "オンライン完結の可否",
    "通学拠点",
    "受講期間",
    "総学習時間",
    "受講料金",
    "入学金",
    "教材費",
    "給付金対象の有無",
    "平日・土日・夜間コース",
    "振替制度",
    "クラス規模",
    "グループワーク",
    "ロールプレイ",
    "課題の提出方法",
    "修了条件",
    "試験対策(学科・論述・面接)",
    "試験対策が料金に含まれるか",
    "資格取得後の支援",
    "卒業生コミュニティ",
    "就職支援",
    "独立・副業支援",
    "子育て中の通いやすさ(振替・録画など)",
    "情報確認日",
  ];

  const entries: CompareEntry[] = schools.map((s) => {
    const support = s.postQualificationSupport ?? [];
    const has = (kw: string) =>
      support.some((x) => x.includes(kw))
        ? support.filter((x) => x.includes(kw)).join("・")
        : s.informationStatus === "unverified"
          ? UNCONFIRMED
          : "公式サイトの記載では未確認";
    const items: Record<string, string> = {
      受講形式: s.deliveryModes.length > 0 ? deliveryModesLabel(s) : UNCONFIRMED,
      "オンライン完結の可否":
        s.deliveryModes.length === 0
          ? UNCONFIRMED
          : s.deliveryModes.includes("online-live") ||
              s.deliveryModes.includes("online-on-demand")
            ? "可(コースによる。要確認)"
            : "要確認",
      通学拠点: s.deliveryModes.includes("classroom") || s.deliveryModes.includes("hybrid")
        ? "あり(場所は公式サイトで確認)"
        : s.deliveryModes.length === 0
          ? UNCONFIRMED
          : "オンライン中心",
      受講期間: s.courseDuration ?? UNCONFIRMED,
      総学習時間:
        s.totalHours !== undefined
          ? `${s.totalHours}時間`
          : s.liveLessonHours !== undefined
            ? `ライブ講習${s.liveLessonHours}時間(総時間は未確認)`
            : UNCONFIRMED,
      受講料金: yenOr(s.tuition),
      入学金:
        s.admissionFee === undefined
          ? UNCONFIRMED
          : s.admissionFee === 0
            ? "なし"
            : yenOr(s.admissionFee),
      教材費:
        s.materialFee === undefined
          ? UNCONFIRMED
          : s.materialFee === 0
            ? "受講料に込み"
            : yenOr(s.materialFee),
      給付金対象の有無:
        s.educationBenefitAvailable === undefined
          ? UNCONFIRMED
          : s.educationBenefitAvailable
            ? "対象講座あり(自己負担額は個人の条件により異なる)"
            : "対象外",
      "平日・土日・夜間コース":
        (s.scheduleOptions ?? []).length > 0
          ? (s.scheduleOptions ?? []).join(" / ")
          : UNCONFIRMED,
      振替制度: s.makeupPolicy ?? UNCONFIRMED,
      クラス規模: s.classSize ?? UNCONFIRMED,
      グループワーク:
        s.roleplayTraining !== undefined
          ? "講習内で実施(形式は公式サイトで確認)"
          : UNCONFIRMED,
      ロールプレイ: s.roleplayTraining ?? UNCONFIRMED,
      課題の提出方法: s.assignmentFormat ?? UNCONFIRMED,
      修了条件:
        (s.completionRequirements ?? []).length > 0
          ? (s.completionRequirements ?? []).join(" / ")
          : UNCONFIRMED,
      "試験対策(学科・論述・面接)": s.examPreparationNotes ?? UNCONFIRMED,
      試験対策が料金に含まれるか:
        s.examPreparationIncluded === undefined
          ? UNCONFIRMED
          : s.examPreparationIncluded
            ? "含まれる"
            : "別講座・別料金",
      資格取得後の支援: support.length > 0 ? support.join(" / ") : UNCONFIRMED,
      卒業生コミュニティ: support.some(
        (x) =>
          x.includes("懇親") || x.includes("情報交換") || x.includes("コミュニティ")
      )
        ? support
            .filter(
              (x) =>
                x.includes("懇親") ||
                x.includes("情報交換") ||
                x.includes("コミュニティ")
            )
            .join("・")
        : s.informationStatus === "unverified"
          ? UNCONFIRMED
          : "公式サイトの記載では未確認",
      就職支援: has("就業"),
      "独立・副業支援": has("独立"),
      "子育て中の通いやすさ(振替・録画など)":
        s.makeupPolicy !== undefined || (s.scheduleOptions ?? []).length > 0
          ? [s.makeupPolicy, (s.scheduleOptions ?? []).join("・")]
              .filter(Boolean)
              .join(" / ")
          : UNCONFIRMED,
      情報確認日: s.verifiedAt ?? "未確認",
    };
    return {
      slug: s.slug,
      name: s.name,
      officialUrl: s.officialUrl,
      informationStatus: s.informationStatus,
      checkedAt: s.verifiedAt ?? s.updatedAt,
      isPr: s.isPr ?? false,
      items,
    };
  });

  return { itemOrder, schools: entries };
}

/* ---------- サイトマップ ---------- */
function buildSitemap(paths: string[]): string {
  const urls = paths
    .filter((p) => p !== "/404.html")
    .map(
      (p) => `  <url><loc>${SITE.baseUrl}${p}</loc></url>`
    )
    .join("\n");
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`;
}

/* ---------- メイン ---------- */
function main(): void {
  rmSync(DIST, { recursive: true, force: true });
  mkdirSync(DIST, { recursive: true });

  const pages: Array<[string, string]> = [
    ["/", homePage()],
    ["/terms/", termsIndexPage()],
    ...terms.map(
      (t): [string, string] => [`/terms/${t.slug}/`, termDetailPage(t)]
    ),
    ["/theorists/", theoristsIndexPage()],
    ...theorists.map(
      (t): [string, string] => [`/theorists/${t.slug}/`, theoristDetailPage(t)]
    ),
    ["/schools/", schoolsIndexPage()],
    ...schools.map(
      (s): [string, string] => [`/schools/${s.slug}/`, schoolDetailPage(s)]
    ),
    ["/schools/compare/", comparePage()],
    ["/school-reviews/chiiki-renkei-platform/", chiikiReviewPage()],
    ["/school-guides/how-to-choose/", howToChoosePage()],
    ["/school-guides/online/", onlineGuidePage()],
    ["/school-guides/working-mothers/", workingMothersGuidePage()],
    ["/school-guides/training-and-exam-preparation/", trainingVsExamPrepPage()],
    ["/start/", startPage()],
    ["/laws/", lawsPage()],
    ["/exam/", examPage()],
    ["/careers/", careersPage()],
    ["/games/", gamesHubPage()],
    ["/games/match/", matchGamePage()],
    ["/search/", searchPage()],
    ["/about/", aboutPage()],
    ["/404.html", notFoundPage()],
  ];

  for (const [path, html] of pages) {
    writePage(path, html);
  }

  // 静的アセット
  cpSync(join(process.cwd(), "public"), DIST, { recursive: true });

  // 検索インデックス
  writeFileSync(
    join(DIST, "search-index.json"),
    JSON.stringify(buildSearchIndex()),
    "utf8"
  );

  // 比較用学校データ
  mkdirSync(join(DIST, "data"), { recursive: true });
  writeFileSync(
    join(DIST, "data", "schools.json"),
    JSON.stringify(buildCompareData()),
    "utf8"
  );

  // バージョン記録(持ち運び版・ランチャー生成で使用)
  writeFileSync(join(DIST, "version.txt"), SITE.version, "utf8");

  // 法改正の見張り番用データ(毎月の自動チェックが読む)
  writeFileSync(
    join(DIST, "law-watch.json"),
    JSON.stringify(
      Object.entries(lawWatch).map(([slug, v]) => ({
        slug,
        name: terms.find((t) => t.slug === slug)?.name ?? slug,
        url: `${SITE.baseUrl}/terms/${slug}/`,
        ...v,
      })),
      null,
      1
    ),
    "utf8"
  );

  // sitemap / robots
  writeFileSync(
    join(DIST, "sitemap.xml"),
    buildSitemap(pages.map(([p]) => p)),
    "utf8"
  );
  writeFileSync(
    join(DIST, "robots.txt"),
    `User-agent: *\nAllow: /\nSitemap: ${SITE.baseUrl}/sitemap.xml\n`,
    "utf8"
  );

  console.log(`✔ ${pages.length} pages generated in dist/`);
}

main();
